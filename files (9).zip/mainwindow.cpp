#include "mainwindow.h"
#include "expectedvdialog.h"

// Include the UI header generated from mainwindow.ui
// This provides Ui::Dialog with all widget pointers
#include "ui_mainwindow.h"

#include <QDateTime>
#include <QTextCharFormat>
#include <QTextCursor>
#include <QFont>
#include <QMessageBox>

// ============================================================================
//  Log Color Constants
// ============================================================================
static const QColor COLOR_SEND  ("#2E86C1");   // Blue — outgoing commands
static const QColor COLOR_RECV  ("#27AE60");   // Green — incoming data
static const QColor COLOR_ACK   ("#1E8449");   // Dark green — acknowledgment
static const QColor COLOR_NACK  ("#C0392B");   // Dark red — rejection
static const QColor COLOR_ERROR ("#E74C3C");   // Red — timeouts, errors
static const QColor COLOR_RAW   ("#7F8C8D");   // Gray — raw hex bytes
static const QColor COLOR_INFO  ("#2C3E50");   // Dark gray — status info

// ============================================================================
//  Constructor
// ============================================================================
MainWindow::MainWindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
    , m_serial(new SerialComm(this))
    , m_connectionStatusLabel(nullptr)
    , m_systemStateLabel(nullptr)
    , m_systemState(Protocol::SystemState::IDLE)
{
    ui->setupUi(this);

    // Set proper window title
    setWindowTitle("Velocity Radar");

    // Setup programmatic widgets (status labels, log config)
    setupProgrammaticWidgets();

    // Wire all button signals and serial signals
    setupConnections();

    // Populate COM port list with real ports
    onRefreshPorts();

    // Set initial button states
    updateButtonStates();
    updateConnectionStatus(false);

    log("Application started", LogType::INFO);
    log(QString("System state: %1").arg(Protocol::stateName(m_systemState)), LogType::INFO);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ============================================================================
//  Setup: Programmatic Widgets
// ============================================================================
void MainWindow::setupProgrammaticWidgets()
{
    // --- Connection status indicator (green/red circle + text) ---
    m_connectionStatusLabel = new QLabel(this);
    m_connectionStatusLabel->setGeometry(460, 75, 240, 20);
    m_connectionStatusLabel->setText(QString::fromUtf8("⚫ Disconnected"));
    m_connectionStatusLabel->setStyleSheet("font-size: 10pt;");

    // --- System state label ---
    m_systemStateLabel = new QLabel(this);
    m_systemStateLabel->setGeometry(40, 120, 350, 20);
    m_systemStateLabel->setText("State: IDLE");
    m_systemStateLabel->setStyleSheet("font-weight: bold; font-size: 10pt; color: #2C3E50;");

    // --- Configure the QPlainTextEdit log widget from .ui ---
    // Widget name in your .ui: plainTextEdit
    ui->plainTextEdit->setReadOnly(true);
    ui->plainTextEdit->setMaximumBlockCount(2000);  // Keep last 2000 lines
    ui->plainTextEdit->setFont(QFont("Courier New", 9));
    ui->plainTextEdit->setPlaceholderText("Log messages will appear here...");

    // --- Hide the QTextBrowser widgets we don't need ---
    // textBrowser_3 was the old "logs" label — replaced by log widget header
    ui->textBrowser_3->hide();
}

// ============================================================================
//  Setup: Signal/Slot Connections
// ============================================================================
void MainWindow::setupConnections()
{
    // --- Button → Command handlers ---
    // Widget names match your mainwindow.ui exactly

    // pushButton = "Expected Value"
    connect(ui->pushButton, &QPushButton::clicked,
            this, &MainWindow::onExpectedValueClicked);

    // enterMeasureMode
    connect(ui->enterMeasureMode, &QPushButton::clicked,
            this, &MainWindow::onEnterMeasureModeClicked);

    // stopMeasure
    connect(ui->stopMeasure, &QPushButton::clicked,
            this, &MainWindow::onStopMeasureClicked);

    // transmitLastMode (maps to TXMT_LAST_V)
    connect(ui->transmitLastMode, &QPushButton::clicked,
            this, &MainWindow::onTransmitLastVClicked);

    // parallax (STUB for now)
    connect(ui->parallax, &QPushButton::clicked,
            this, &MainWindow::onParallaxClicked);

    // transmitParameters
    connect(ui->transmitParameters, &QPushButton::clicked,
            this, &MainWindow::onTransmitParametersClicked);

    // enterSystemTestMode
    connect(ui->enterSystemTestMode, &QPushButton::clicked,
            this, &MainWindow::onEnterSystemTestModeClicked);

    // performSystemTest
    connect(ui->performSystemTest, &QPushButton::clicked,
            this, &MainWindow::onPerformSystemTestClicked);

    // exitSystemTestMode
    connect(ui->exitSystemTestMode, &QPushButton::clicked,
            this, &MainWindow::onExitSystemTestModeClicked);

    // performMVPTest
    connect(ui->performMVPTest, &QPushButton::clicked,
            this, &MainWindow::onPerformMVPTestClicked);

    // transmitTestResults (maps to TXMT_MVP_TEST_RESULTS)
    connect(ui->transmitTestResults, &QPushButton::clicked,
            this, &MainWindow::onTransmitMVPTestResultsClicked);

    // --- Connect / Disconnect buttons ---
    // pushButton_2 = "Connect", pushButton_3 = "Disconnect"
    connect(ui->pushButton_2, &QPushButton::clicked,
            this, &MainWindow::onConnectClicked);
    connect(ui->pushButton_3, &QPushButton::clicked,
            this, &MainWindow::onDisconnectClicked);

    // --- SerialComm signals ---
    connect(m_serial, &SerialComm::messageReceived,
            this, &MainWindow::onMessageReceived);
    connect(m_serial, &SerialComm::responseTimeout,
            this, &MainWindow::onResponseTimeout);
    connect(m_serial, &SerialComm::portOpened,
            this, &MainWindow::onPortOpened);
    connect(m_serial, &SerialComm::portClosed,
            this, &MainWindow::onPortClosed);
    connect(m_serial, &SerialComm::portError,
            this, &MainWindow::onPortError);
    connect(m_serial, &SerialComm::rawDataSent,
            this, &MainWindow::onRawDataSent);
    connect(m_serial, &SerialComm::rawDataReceived,
            this, &MainWindow::onRawDataReceived);
    connect(m_serial, &SerialComm::parseError,
            this, &MainWindow::onParseError);
}

// ============================================================================
//  Button Click Handlers
// ============================================================================

// CMD 102: EXPECTED_V — Open dialog, get value, send command
void MainWindow::onExpectedValueClicked()
{
    ExpectedVDialog dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        uint16_t velocity = dlg.velocity();
        QByteArray msg = MessageBuilder::buildExpectedV(velocity);
        sendCommand(msg, Protocol::CMD_EXPECTED_V,
                    QString("EXPECTED_V = %1").arg(velocity));
    }
}

// CMD 103: MEASURE — Enter Measure Mode
void MainWindow::onEnterMeasureModeClicked()
{
    QByteArray msg = MessageBuilder::buildMeasure();
    sendCommand(msg, Protocol::CMD_MEASURE, "MEASURE (enter measure mode)");
}

// CMD 104: STOP_MEASURE — Exit Measure Mode
void MainWindow::onStopMeasureClicked()
{
    QByteArray msg = MessageBuilder::buildStopMeasure();
    sendCommand(msg, Protocol::CMD_STOP_MEASURE, "STOP_MEASURE (exit measure mode)");
}

// CMD 105: TXMT_LAST_V — Request last velocity
void MainWindow::onTransmitLastVClicked()
{
    QByteArray msg = MessageBuilder::buildTxmtLastV();
    sendCommand(msg, Protocol::CMD_TXMT_LAST_V, "TXMT_LAST_V (request last velocity)");
}

// CMD 106: PARALLAX — STUB (not implemented yet)
void MainWindow::onParallaxClicked()
{
    log("PARALLAX: Not yet implemented (hardware not ready)", LogType::INFO);
}

// CMD 107: TXMT_PARAMS — Request current parameters
void MainWindow::onTransmitParametersClicked()
{
    QByteArray msg = MessageBuilder::buildTxmtParams();
    sendCommand(msg, Protocol::CMD_TXMT_PARAMS, "TXMT_PARAMS (request parameters)");
}

// CMD 108: ENTER_SYSTEM_TEST — Enter System Test Mode
void MainWindow::onEnterSystemTestModeClicked()
{
    QByteArray msg = MessageBuilder::buildEnterSystemTest();
    sendCommand(msg, Protocol::CMD_ENTER_SYSTEM_TEST, "ENTER_SYSTEM_TEST");
}

// CMD 109: PERFORM_SYSTEM_TEST — Run system test (~5 second response)
void MainWindow::onPerformSystemTestClicked()
{
    QByteArray msg = MessageBuilder::buildPerformSystemTest();
    sendCommand(msg, Protocol::CMD_PERFORM_SYSTEM_TEST,
                "PERFORM_SYSTEM_TEST (awaiting ~5s for results)");
}

// CMD 110: EXIT_SYSTEM_TEST — Exit System Test Mode
void MainWindow::onExitSystemTestModeClicked()
{
    QByteArray msg = MessageBuilder::buildExitSystemTest();
    sendCommand(msg, Protocol::CMD_EXIT_SYSTEM_TEST, "EXIT_SYSTEM_TEST");
}

// CMD 111: PERFORM_MVP_TEST
void MainWindow::onPerformMVPTestClicked()
{
    QByteArray msg = MessageBuilder::buildPerformMVPTest();
    sendCommand(msg, Protocol::CMD_PERFORM_MVP_TEST, "PERFORM_MVP_TEST");
}

// CMD 112: TXMT_MVP_TEST_RESULTS
void MainWindow::onTransmitMVPTestResultsClicked()
{
    QByteArray msg = MessageBuilder::buildTxmtMVPTestResults();
    sendCommand(msg, Protocol::CMD_TXMT_MVP_TEST_RESULTS, "TXMT_MVP_TEST_RESULTS");
}

// ============================================================================
//  Connection Control
// ============================================================================

void MainWindow::onConnectClicked()
{
    if (m_serial->isOpen()) {
        log("Already connected", LogType::INFO);
        return;
    }

    // Get selected port and baud rate from combo boxes
    QString portName = ui->comboBox->currentText();
    QString baudText = ui->comboBox_2->currentText();

    if (portName.isEmpty() || portName == "No ports found") {
        log("No COM port selected", LogType::ERROR);
        return;
    }

    bool ok;
    int baudRate = baudText.toInt(&ok);
    if (!ok) {
        baudRate = Protocol::DEFAULT_BAUD_RATE;
    }

    log(QString("Connecting to %1 @ %2...").arg(portName).arg(baudRate), LogType::INFO);
    m_serial->openPort(portName, baudRate);
}

void MainWindow::onDisconnectClicked()
{
    if (!m_serial->isOpen()) {
        log("Not connected", LogType::INFO);
        return;
    }

    m_serial->closePort();
}

void MainWindow::onRefreshPorts()
{
    // Save current selection
    QString currentPort = ui->comboBox->currentText();

    ui->comboBox->clear();

    QStringList ports = SerialComm::availablePorts();
    if (ports.isEmpty()) {
        ui->comboBox->addItem("No ports found");
    } else {
        ui->comboBox->addItems(ports);

        // Restore previous selection if still available
        int idx = ui->comboBox->findText(currentPort);
        if (idx >= 0) {
            ui->comboBox->setCurrentIndex(idx);
        }
    }
}

// ============================================================================
//  SerialComm Signal Handlers
// ============================================================================

void MainWindow::onMessageReceived(const ParsedMessage &msg)
{
    switch (msg.code) {
    case Protocol::RSP_ACK:
        handleAck(msg);
        break;
    case Protocol::RSP_NACK:
        handleNack(msg);
        break;
    case Protocol::RSP_LAST_V:
        handleLastV(msg);
        break;
    case Protocol::RSP_PARAMS:
        handleParams(msg);
        break;
    case Protocol::RSP_SYSTEM_TEST_RESULTS:
        handleSystemTestResults(msg);
        break;
    default:
        log(QString("Unknown response code: %1").arg(msg.code), LogType::ERROR);
        break;
    }
}

void MainWindow::onResponseTimeout(uint8_t commandCode)
{
    int timeoutMs = Protocol::responseTimeout(commandCode);
    log(QString("TIMEOUT: No response to %1 (code %2) after %3s")
            .arg(Protocol::commandName(commandCode))
            .arg(commandCode)
            .arg(timeoutMs / 1000.0, 0, 'f', 1),
        LogType::ERROR);
}

void MainWindow::onPortOpened(const QString &portName, int baudRate)
{
    log(QString("Connected to %1 @ %2 baud").arg(portName).arg(baudRate), LogType::INFO);
    updateConnectionStatus(true, QString("%1 @ %2").arg(portName).arg(baudRate));
    updateButtonStates();

    // Reset system state to IDLE on new connection
    setSystemState(Protocol::SystemState::IDLE);
}

void MainWindow::onPortClosed()
{
    log("Disconnected", LogType::INFO);
    updateConnectionStatus(false);
    updateButtonStates();
}

void MainWindow::onPortError(const QString &error)
{
    log(QString("PORT ERROR: %1").arg(error), LogType::ERROR);
}

void MainWindow::onRawDataSent(const QByteArray &data)
{
    log(QString("TX: %1").arg(bytesToHex(data)), LogType::RAW);
}

void MainWindow::onRawDataReceived(const QByteArray &data)
{
    log(QString("RX: %1").arg(bytesToHex(data)), LogType::RAW);
}

void MainWindow::onParseError(const QString &error)
{
    log(QString("PARSE ERROR: %1").arg(error), LogType::ERROR);
}

// ============================================================================
//  Response Handlers
// ============================================================================

void MainWindow::handleAck(const ParsedMessage &msg)
{
    AckData ack = MessageParser::decodeAck(msg);
    if (!ack.valid) {
        log("Received ACK but failed to decode", LogType::ERROR);
        return;
    }

    log(QString("ACK for %1 (code %2)")
            .arg(Protocol::commandName(ack.acknowledgedCode))
            .arg(ack.acknowledgedCode),
        LogType::ACK);

    // Update system state based on which command was acknowledged
    switch (ack.acknowledgedCode) {
    case Protocol::CMD_MEASURE:
        setSystemState(Protocol::SystemState::MEASURING);
        break;
    case Protocol::CMD_STOP_MEASURE:
        setSystemState(Protocol::SystemState::IDLE);
        break;
    case Protocol::CMD_ENTER_SYSTEM_TEST:
        setSystemState(Protocol::SystemState::SYSTEM_TEST);
        break;
    case Protocol::CMD_EXIT_SYSTEM_TEST:
        setSystemState(Protocol::SystemState::IDLE);
        break;
    default:
        // Other commands don't change state (EXPECTED_V, PARALLAX, etc.)
        break;
    }
}

void MainWindow::handleNack(const ParsedMessage &msg)
{
    NackData nack = MessageParser::decodeNack(msg);
    if (!nack.valid) {
        log("Received NACK but failed to decode", LogType::ERROR);
        return;
    }

    log(QString("NACK: %1 (code %2) was REJECTED")
            .arg(Protocol::commandName(nack.rejectedCode))
            .arg(nack.rejectedCode),
        LogType::NACK);
}

void MainWindow::handleLastV(const ParsedMessage &msg)
{
    LastVData lastV = MessageParser::decodeLastV(msg);
    if (!lastV.valid) {
        log("Received LAST_V but failed to decode", LogType::ERROR);
        return;
    }

    if (lastV.result == Protocol::LAST_V_RESULT_OK) {
        log(QString("LAST_V: %1 m/s (raw=%2)")
                .arg(lastV.realVelocity, 0, 'f', 1)
                .arg(lastV.rawVelocity),
            LogType::RECV);
    } else {
        log("LAST_V: Measurement error (no valid velocity)", LogType::ERROR);
    }
}

void MainWindow::handleParams(const ParsedMessage &msg)
{
    ParamsData params = MessageParser::decodeParams(msg);
    if (!params.valid) {
        log("Received PARAMS but failed to decode", LogType::ERROR);
        return;
    }

    QString tripodStr = (params.tripod == Protocol::TRIPOD_TRIPOD) ? "Tripod" : "Bracket";
    double xReal = params.x / 16.0;
    double yReal = params.y / 16.0;
    double zReal = params.z / 16.0;

    log(QString("PARAMS: Expected V=%1, Mount=%2, X=%3m, Y=%4m, Z=%5m")
            .arg(params.expectedV)
            .arg(tripodStr)
            .arg(xReal, 0, 'f', 2)
            .arg(yReal, 0, 'f', 2)
            .arg(zReal, 0, 'f', 2),
        LogType::RECV);
}

void MainWindow::handleSystemTestResults(const ParsedMessage &msg)
{
    SystemTestData testData = MessageParser::decodeSystemTestResults(msg);
    if (!testData.valid) {
        log("Received SYSTEM_TEST_RESULTS but failed to decode", LogType::ERROR);
        return;
    }

    QStringList flagDescriptions = Protocol::decodeTestFlags(testData.flags);

    if (testData.flags == 0x0000) {
        log(QString("SYSTEM TEST: ALL PASSED (flags=0x%1)")
                .arg(testData.flags, 4, 16, QChar('0')),
            LogType::RECV);
    } else {
        log(QString("SYSTEM TEST: FAILURES DETECTED (flags=0x%1)")
                .arg(testData.flags, 4, 16, QChar('0')),
            LogType::ERROR);
        for (const QString &flag : flagDescriptions) {
            log(QString("  - %1").arg(flag), LogType::ERROR);
        }
    }
}

// ============================================================================
//  State Machine
// ============================================================================

void MainWindow::setSystemState(Protocol::SystemState newState)
{
    m_systemState = newState;
    QString stateStr = Protocol::stateName(newState);

    m_systemStateLabel->setText(QString("State: %1").arg(stateStr));
    log(QString("State changed to %1").arg(stateStr), LogType::INFO);

    updateButtonStates();
}

void MainWindow::updateButtonStates()
{
    bool connected = m_serial->isOpen();

    // Connection controls
    ui->pushButton_2->setEnabled(!connected);   // Connect
    ui->pushButton_3->setEnabled(connected);    // Disconnect
    ui->comboBox->setEnabled(!connected);       // COM port
    ui->comboBox_2->setEnabled(!connected);     // Baud rate

    // All command buttons require connection
    if (!connected) {
        ui->pushButton->setEnabled(false);             // Expected Value
        ui->enterMeasureMode->setEnabled(false);
        ui->stopMeasure->setEnabled(false);
        ui->transmitLastMode->setEnabled(false);
        ui->parallax->setEnabled(false);
        ui->transmitParameters->setEnabled(false);
        ui->enterSystemTestMode->setEnabled(false);
        ui->performSystemTest->setEnabled(false);
        ui->exitSystemTestMode->setEnabled(false);
        ui->performMVPTest->setEnabled(false);
        ui->transmitTestResults->setEnabled(false);
        return;
    }

    // State-dependent button enable/disable
    switch (m_systemState) {

    case Protocol::SystemState::IDLE:
        // IDLE: All commands available
        ui->pushButton->setEnabled(true);              // Expected Value
        ui->enterMeasureMode->setEnabled(true);
        ui->stopMeasure->setEnabled(false);            // No measure to stop
        ui->transmitLastMode->setEnabled(true);
        ui->parallax->setEnabled(true);
        ui->transmitParameters->setEnabled(true);
        ui->enterSystemTestMode->setEnabled(true);
        ui->performSystemTest->setEnabled(false);      // Must enter test mode first
        ui->exitSystemTestMode->setEnabled(false);     // Not in test mode
        ui->performMVPTest->setEnabled(true);
        ui->transmitTestResults->setEnabled(true);
        break;

    case Protocol::SystemState::MEASURING:
        // MEASURING: Only STOP_MEASURE accepted; all others → NACK
        ui->pushButton->setEnabled(false);
        ui->enterMeasureMode->setEnabled(false);
        ui->stopMeasure->setEnabled(true);             // Only valid command
        ui->transmitLastMode->setEnabled(false);
        ui->parallax->setEnabled(false);
        ui->transmitParameters->setEnabled(false);
        ui->enterSystemTestMode->setEnabled(false);
        ui->performSystemTest->setEnabled(false);
        ui->exitSystemTestMode->setEnabled(false);
        ui->performMVPTest->setEnabled(false);
        ui->transmitTestResults->setEnabled(false);
        break;

    case Protocol::SystemState::SYSTEM_TEST:
        // SYSTEM_TEST: Only PERFORM_SYSTEM_TEST and EXIT_SYSTEM_TEST
        ui->pushButton->setEnabled(false);
        ui->enterMeasureMode->setEnabled(false);
        ui->stopMeasure->setEnabled(false);
        ui->transmitLastMode->setEnabled(false);
        ui->parallax->setEnabled(false);
        ui->transmitParameters->setEnabled(false);
        ui->enterSystemTestMode->setEnabled(false);
        ui->performSystemTest->setEnabled(true);       // Allowed in test mode
        ui->exitSystemTestMode->setEnabled(true);      // Allowed in test mode
        ui->performMVPTest->setEnabled(false);
        ui->transmitTestResults->setEnabled(false);
        break;
    }
}

// ============================================================================
//  Logging
// ============================================================================

void MainWindow::log(const QString &message, LogType type)
{
    // Determine color based on log type
    QColor color;
    QString prefix;

    switch (type) {
    case LogType::SEND:   color = COLOR_SEND;   prefix = "[SEND]";   break;
    case LogType::RECV:   color = COLOR_RECV;   prefix = "[RECV]";   break;
    case LogType::ACK:    color = COLOR_ACK;    prefix = "[ACK]";    break;
    case LogType::NACK:   color = COLOR_NACK;   prefix = "[NACK]";   break;
    case LogType::ERROR:  color = COLOR_ERROR;  prefix = "[ERROR]";  break;
    case LogType::RAW:    color = COLOR_RAW;    prefix = "[RAW]";    break;
    case LogType::INFO:   color = COLOR_INFO;   prefix = "[INFO]";   break;
    }

    // Format: "HH:MM:SS [TYPE] message"
    QString timestamp = QDateTime::currentDateTime().toString("HH:mm:ss");
    QString fullMessage = QString("%1 %2 %3").arg(timestamp, prefix, message);

    // Insert colored text at end of log
    QTextCursor cursor = ui->plainTextEdit->textCursor();
    cursor.movePosition(QTextCursor::End);

    QTextCharFormat format;
    format.setForeground(color);
    cursor.insertText(fullMessage + "\n", format);

    // Auto-scroll to bottom
    ui->plainTextEdit->setTextCursor(cursor);
    ui->plainTextEdit->ensureCursorVisible();
}

// ============================================================================
//  Helpers
// ============================================================================

void MainWindow::sendCommand(const QByteArray &message, uint8_t commandCode,
                              const QString &description)
{
    if (!m_serial->isOpen()) {
        log("Cannot send: not connected", LogType::ERROR);
        return;
    }

    log(QString("Sending %1 (code %2)").arg(description).arg(commandCode), LogType::SEND);
    m_serial->sendMessage(message, commandCode);
}

void MainWindow::updateConnectionStatus(bool connected, const QString &detail)
{
    if (connected) {
        m_connectionStatusLabel->setText(
            QString::fromUtf8("🟢 Connected (%1)").arg(detail));
        m_connectionStatusLabel->setStyleSheet("font-size: 10pt; color: #27AE60;");
    } else {
        m_connectionStatusLabel->setText(QString::fromUtf8("⚫ Disconnected"));
        m_connectionStatusLabel->setStyleSheet("font-size: 10pt; color: #E74C3C;");
    }
}

QString MainWindow::bytesToHex(const QByteArray &data) const
{
    QStringList hexParts;
    for (int i = 0; i < data.size(); ++i) {
        hexParts << QString("%1").arg(
            static_cast<uint8_t>(data.at(i)), 2, 16, QChar('0')).toUpper();
    }
    return hexParts.join(" ");
}
