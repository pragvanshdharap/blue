#ifndef SERIALCOMM_H
#define SERIALCOMM_H

#include <QObject>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTimer>
#include <QByteArray>
#include <QString>
#include <QStringList>
#include <cstdint>

#include "messageparser.h"

// ============================================================================
//  VELOCITY RADAR — Serial Communication (Layer 4)
//
//  Wraps QSerialPort for async serial I/O over RS-422.
//  Feeds incoming bytes to MessageParser automatically.
//  Manages response timeout timer (2s normal, 5s for PERFORM_SYSTEM_TEST).
//
//  Signals emitted:
//    messageReceived  — fully parsed & checksum-valid message from embedded system
//    responseTimeout  — no response within deadline after sending a command
//    portOpened       — serial port opened successfully
//    portClosed       — serial port closed (user-initiated or error)
//    portError        — serial port error (descriptive string)
//    rawDataSent      — raw bytes written to wire (for hex logging)
//    rawDataReceived  — raw bytes read from wire (for hex logging)
//    parseError       — parser detected bad checksum or invalid frame
// ============================================================================

class SerialComm : public QObject
{
    Q_OBJECT

public:
    explicit SerialComm(QObject *parent = nullptr);
    ~SerialComm();

    // --- Port Control ---

    // Open serial port with given name and baud rate
    // portName: e.g. "COM3", "COM4"
    // baudRate: e.g. 9600, 115200
    // Returns true on success
    bool openPort(const QString &portName, int baudRate);

    // Close serial port gracefully
    void closePort();

    // Is the port currently open?
    bool isOpen() const;

    // Get current port name (empty if not open)
    QString currentPortName() const;

    // Get current baud rate
    int currentBaudRate() const;

    // --- Sending ---

    // Send a pre-built message (from MessageBuilder) and start response timeout.
    // commandCode: the CMD code (used for timeout duration and logging)
    void sendMessage(const QByteArray &message, uint8_t commandCode);

    // --- Port Discovery ---

    // Get list of available serial port names
    static QStringList availablePorts();

signals:
    // Fully parsed message from embedded system (checksum validated)
    void messageReceived(const ParsedMessage &msg);

    // No response received within timeout after sending a command
    void responseTimeout(uint8_t pendingCommandCode);

    // Port lifecycle signals
    void portOpened(const QString &portName, int baudRate);
    void portClosed();
    void portError(const QString &errorDescription);

    // Raw byte signals (for hex logging in UI)
    void rawDataSent(const QByteArray &data);
    void rawDataReceived(const QByteArray &data);

    // Parser error (bad checksum, invalid frame)
    void parseError(const QString &errorDescription);

private slots:
    // QSerialPort::readyRead → read bytes and feed to parser
    void onReadyRead();

    // QSerialPort::errorOccurred → handle port errors
    void onSerialError(QSerialPort::SerialPortError error);

    // Response timeout timer fired
    void onResponseTimeout();

    // MessageParser found a valid message
    void onParserMessageReceived(const ParsedMessage &msg);

    // MessageParser detected an error
    void onParserError(const QString &errorDescription);

private:
    QSerialPort   *m_serialPort;
    MessageParser *m_parser;
    QTimer        *m_responseTimer;

    uint8_t m_pendingCommandCode;   // Command code we're waiting for a response to
    bool    m_waitingForResponse;   // True if we've sent a command and haven't received response
};

#endif // SERIALCOMM_H
