#include "messagebuilder.h"
#include "protocol.h"

// ============================================================================
//  VELOCITY RADAR — Message Builder Implementation (Layer 2)
//
//  Checksum Algorithm:
//    Step 1: sum = SIZE + CODE + DATA_1 + ... + DATA_M
//    Step 2: CHECKSUM = (-sum) & 0xFF   (two's complement mod 256)
//    Verify: (sum + CHECKSUM) mod 256 == 0
//
//  Frame on wire:
//    [0x41][0x42][SIZE][CODE][DATA...][CHECKSUM]
//     'A'   'B'
// ============================================================================

// ----------------------------------------------------------------------------
//  Private: Compute checksum over payload bytes [SIZE, CODE, DATA...]
// ----------------------------------------------------------------------------
uint8_t MessageBuilder::computeChecksum(const QByteArray &payload)
{
    uint8_t sum = 0;
    for (int i = 0; i < payload.size(); ++i) {
        sum += static_cast<uint8_t>(payload.at(i));
    }
    return static_cast<uint8_t>((-sum) & 0xFF);
}

// ----------------------------------------------------------------------------
//  Private: Build complete frame = HEADER + payload + CHECKSUM
// ----------------------------------------------------------------------------
QByteArray MessageBuilder::buildFrame(const QByteArray &payload)
{
    QByteArray frame;
    frame.reserve(2 + payload.size() + 1);

    frame.append(static_cast<char>(Protocol::HEADER_1));   // 'A'
    frame.append(static_cast<char>(Protocol::HEADER_2));   // 'B'
    frame.append(payload);                                  // [SIZE][CODE][DATA...]
    frame.append(static_cast<char>(computeChecksum(payload)));  // CHECKSUM

    return frame;
}

// ============================================================================
//  Command Builders
// ============================================================================

// CMD 102: EXPECTED_V — Set Expected Velocity
// Payload: [SIZE=5][CODE=102][V_LO][V_HI]
// Wire:    ['A']['B'][05][66][V_LO][V_HI][CHECKSUM]  → 7 bytes total
QByteArray MessageBuilder::buildExpectedV(uint16_t velocity)
{
    QByteArray payload;
    payload.append(static_cast<char>(5));                          // SIZE = 5
    payload.append(static_cast<char>(Protocol::CMD_EXPECTED_V));   // CODE = 102
    payload.append(static_cast<char>(velocity & 0xFF));            // V_LO (LSB first)
    payload.append(static_cast<char>((velocity >> 8) & 0xFF));     // V_HI

    return buildFrame(payload);
}

// CMD 103: MEASURE — Enter Measure Mode
// Payload: [SIZE=3][CODE=103]
// Wire:    ['A']['B'][03][67][CHECKSUM]  → 5 bytes total
QByteArray MessageBuilder::buildMeasure()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                       // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_MEASURE));   // CODE = 103

    return buildFrame(payload);
}

// CMD 104: STOP_MEASURE — Exit Measure Mode
// Payload: [SIZE=3][CODE=104]
// Wire:    ['A']['B'][03][68][CHECKSUM]  → 5 bytes total
QByteArray MessageBuilder::buildStopMeasure()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                            // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_STOP_MEASURE));   // CODE = 104

    return buildFrame(payload);
}

// CMD 105: TXMT_LAST_V — Transmit Last Velocity
// Payload: [SIZE=2][CODE=105]
// Wire:    ['A']['B'][02][69][CHECKSUM]  → 5 bytes total
// NOTE: SIZE=2 per spec (SIZE + CODE only; checksum still appended outside SIZE count?
//       Following spec literally: SIZE field = 2)
QByteArray MessageBuilder::buildTxmtLastV()
{
    QByteArray payload;
    payload.append(static_cast<char>(2));                           // SIZE = 2 (per spec)
    payload.append(static_cast<char>(Protocol::CMD_TXMT_LAST_V));   // CODE = 105

    return buildFrame(payload);
}

// CMD 106: PARALLAX — Set Parallax Parameters
// Payload: [SIZE=7][CODE=106][TRIPOD][X][Y][Z]
// Wire:    ['A']['B'][07][6A][TRIPOD][X][Y][Z][CHECKSUM]  → 9 bytes total
QByteArray MessageBuilder::buildParallax(uint8_t tripod, uint8_t x, uint8_t y, uint8_t z)
{
    QByteArray payload;
    payload.append(static_cast<char>(7));                         // SIZE = 7
    payload.append(static_cast<char>(Protocol::CMD_PARALLAX));    // CODE = 106
    payload.append(static_cast<char>(tripod));                    // TRIPOD: 0=bracket, 1=tripod
    payload.append(static_cast<char>(x));                         // X offset
    payload.append(static_cast<char>(y));                         // Y offset
    payload.append(static_cast<char>(z));                         // Z offset

    return buildFrame(payload);
}

// CMD 107: TXMT_PARAMS — Transmit Parameters
// Payload: [SIZE=3][CODE=107]
// Wire:    ['A']['B'][03][6B][CHECKSUM]  → 5 bytes total
QByteArray MessageBuilder::buildTxmtParams()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                           // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_TXMT_PARAMS));   // CODE = 107

    return buildFrame(payload);
}

// CMD 108: ENTER_SYSTEM_TEST — Enter System Test Mode
// Payload: [SIZE=3][CODE=108]
// Wire:    ['A']['B'][03][6C][CHECKSUM]  → 5 bytes total
QByteArray MessageBuilder::buildEnterSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                                // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_ENTER_SYSTEM_TEST));  // CODE = 108

    return buildFrame(payload);
}

// CMD 109: PERFORM_SYSTEM_TEST — Perform System Test
// Payload: [SIZE=3][CODE=109]
// Wire:    ['A']['B'][03][6D][CHECKSUM]  → 5 bytes total
// NOTE: Allow ~5 seconds for response (internal diagnostics)
QByteArray MessageBuilder::buildPerformSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                                  // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_PERFORM_SYSTEM_TEST));  // CODE = 109

    return buildFrame(payload);
}

// CMD 110: EXIT_SYSTEM_TEST — Exit System Test Mode
// Payload: [SIZE=3][CODE=110]
// Wire:    ['A']['B'][03][6E][CHECKSUM]  → 5 bytes total
QByteArray MessageBuilder::buildExitSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                                // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_EXIT_SYSTEM_TEST));   // CODE = 110

    return buildFrame(payload);
}

// CMD 111: PERFORM_MVP_TEST — Perform MVP Test
// Payload: [SIZE=3][CODE=111]
// Wire:    ['A']['B'][03][6F][CHECKSUM]  → 5 bytes total
QByteArray MessageBuilder::buildPerformMVPTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                                // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_PERFORM_MVP_TEST));   // CODE = 111

    return buildFrame(payload);
}

// CMD 112: TXMT_MVP_TEST_RESULTS — Transmit MVP Test Results
// Payload: [SIZE=3][CODE=112]
// Wire:    ['A']['B'][03][70][CHECKSUM]  → 5 bytes total
QByteArray MessageBuilder::buildTxmtMVPTestResults()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));                                      // SIZE = 3
    payload.append(static_cast<char>(Protocol::CMD_TXMT_MVP_TEST_RESULTS));    // CODE = 112

    return buildFrame(payload);
}
