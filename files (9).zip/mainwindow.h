#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
#include <QPlainTextEdit>
#include <QLabel>
#include <QTimer>
#include <QComboBox>
#include <QPushButton>
#include <cstdint>

#include "protocol.h"
#include "serialcomm.h"
#include "messagebuilder.h"
#include "messageparser.h"

// Forward-declare the UI class (generated from mainwindow.ui)
namespace Ui {
class Dialog;
}

// ============================================================================
//  VELOCITY RADAR — Main Window (Layer 5)
//
//  Top-level GUI controller:
//  • Wires all .ui buttons to protocol command handlers
//  • Manages GUI state machine: IDLE / MEASURING / SYSTEM_TEST
//  • Enables/disables buttons per current state
//  • Handles all incoming responses (ACK, NACK, LAST_V, PARAMS, TEST_RESULTS)
//  • Color-coded log panel (QPlainTextEdit, monospace, read-only)
//  • Connection status indicator (QLabel, green/red circle)
//  • Auto-refresh COM port list
//  • Programmatically added widgets (not in .ui):
//      m_connectionStatusLabel, m_systemStateLabel, m_logWidget
// ============================================================================

class MainWindow : public QDialog
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // --- Button click handlers (one per command) ---
    void onExpectedValueClicked();
    void onEnterMeasureModeClicked();
    void onStopMeasureClicked();
    void onTransmitLastVClicked();
    void onParallaxClicked();
    void onTransmitParametersClicked();
    void onEnterSystemTestModeClicked();
    void onPerformSystemTestClicked();
    void onExitSystemTestModeClicked();
    void onPerformMVPTestClicked();
    void onTransmitMVPTestResultsClicked();

    // --- Connection control ---
    void onConnectClicked();
    void onDisconnectClicked();
    void onRefreshPorts();

    // --- SerialComm signal handlers ---
    void onMessageReceived(const ParsedMessage &msg);
    void onResponseTimeout(uint8_t commandCode);
    void onPortOpened(const QString &portName, int baudRate);
    void onPortClosed();
    void onPortError(const QString &error);
    void onRawDataSent(const QByteArray &data);
    void onRawDataReceived(const QByteArray &data);
    void onParseError(const QString &error);

private:
    Ui::Dialog *ui;       // Auto-generated from mainwindow.ui

    // --- Core objects ---
    SerialComm *m_serial;

    // --- Programmatically added widgets ---
    QLabel *m_connectionStatusLabel;   // Green/red circle
    QLabel *m_systemStateLabel;        // "State: IDLE" etc.

    // --- GUI State Machine ---
    Protocol::SystemState m_systemState;

    // --- State management ---
    void setSystemState(Protocol::SystemState newState);
    void updateButtonStates();

    // --- Logging ---
    // Log types for color coding
    enum class LogType { SEND, RECV, ACK, NACK, ERROR, RAW, INFO };
    void log(const QString &message, LogType type);

    // --- Helpers ---
    void sendCommand(const QByteArray &message, uint8_t commandCode,
                     const QString &description);
    void setupConnections();
    void setupProgrammaticWidgets();
    QString bytesToHex(const QByteArray &data) const;

    // --- Response handlers ---
    void handleAck(const ParsedMessage &msg);
    void handleNack(const ParsedMessage &msg);
    void handleLastV(const ParsedMessage &msg);
    void handleParams(const ParsedMessage &msg);
    void handleSystemTestResults(const ParsedMessage &msg);

    // --- Connection status ---
    void updateConnectionStatus(bool connected, const QString &detail = QString());
};

#endif // MAINWINDOW_H
