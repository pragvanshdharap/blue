#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <QString>
#include <cstdint>

// ============================================================================
//  VELOCITY RADAR — Protocol Definition (Layer 1)
//
//  All message codes, timing constants, data ranges, and bit flag definitions
//  in one place. Every other file includes this — change a constant here,
//  it propagates everywhere.
//
//  Reference: Interface Specification Document
// ============================================================================

namespace Protocol {

// --------------------------------------------------------------------------
//  Frame Structure
// --------------------------------------------------------------------------
//  Byte:  1        2        3       4       5...N    N+1
//  Field: HEADER_1 HEADER_2 SIZE    CODE    DATA     CHECKSUM
//  Value: 'A'      'B'      2-255   varies  varies   computed

constexpr uint8_t HEADER_1 = 0x41;   // 'A'
constexpr uint8_t HEADER_2 = 0x42;   // 'B'

constexpr int HEADER_LENGTH = 2;     // 'A' + 'B'
constexpr int MIN_PAYLOAD   = 2;     // SIZE + CODE (no data, no checksum counted in min)
constexpr int MAX_SIZE_FIELD = 255;
constexpr int MAX_DATA_BYTES = 253;  // SIZE=255 → 255 - 1(SIZE) - 1(CODE) - 1(CHECKSUM) = 252... actually 255-3=252

// SIZE = 1(SIZE) + 1(CODE) + M(data) + 1(CHECKSUM) = M + 3
// So M = SIZE - 3

// --------------------------------------------------------------------------
//  Command Codes (PC → Embedded System)
// --------------------------------------------------------------------------
constexpr uint8_t CMD_EXPECTED_V           = 102;
constexpr uint8_t CMD_MEASURE              = 103;
constexpr uint8_t CMD_STOP_MEASURE         = 104;
constexpr uint8_t CMD_TXMT_LAST_V          = 105;
constexpr uint8_t CMD_PARALLAX             = 106;
constexpr uint8_t CMD_TXMT_PARAMS          = 107;
constexpr uint8_t CMD_ENTER_SYSTEM_TEST    = 108;
constexpr uint8_t CMD_PERFORM_SYSTEM_TEST  = 109;
constexpr uint8_t CMD_EXIT_SYSTEM_TEST     = 110;
constexpr uint8_t CMD_PERFORM_MVP_TEST     = 111;
constexpr uint8_t CMD_TXMT_MVP_TEST_RESULTS = 112;

// --------------------------------------------------------------------------
//  Response Codes (Embedded System → PC)
// --------------------------------------------------------------------------
constexpr uint8_t RSP_LAST_V              = 200;
constexpr uint8_t RSP_PARAMS              = 201;
constexpr uint8_t RSP_SYSTEM_TEST_RESULTS = 212;
constexpr uint8_t RSP_ACK                 = 254;
constexpr uint8_t RSP_NACK                = 255;

// --------------------------------------------------------------------------
//  Timing Constants (milliseconds)
// --------------------------------------------------------------------------
constexpr int TIMEOUT_RESPONSE_MS      = 2000;   // 2 seconds for normal commands
constexpr int TIMEOUT_SYSTEM_TEST_MS   = 5000;   // 5 seconds for PERFORM_SYSTEM_TEST
constexpr int TIMEOUT_INTER_BYTE_MS    = 1000;   // 1 second max between consecutive bytes

// --------------------------------------------------------------------------
//  Data Ranges
// --------------------------------------------------------------------------
constexpr int EXPECTED_V_MIN = 150;
constexpr int EXPECTED_V_MAX = 1500;

constexpr int PARALLAX_XYZ_MIN = 0;
constexpr int PARALLAX_XYZ_MAX = 160;   // wire value; real = wire / 16.0
constexpr int PARALLAX_SCALE   = 16;    // multiply real meters by 16 for wire value

constexpr int LAST_V_SCALE = 16;        // wire value / 16.0 = real velocity
constexpr int LAST_V_MAX_RAW = 24000;   // max raw value (24000/16 = 1500.0 m/s)

constexpr int8_t LAST_V_RESULT_OK    =  0;
constexpr int8_t LAST_V_RESULT_ERROR = -1;   // 0xFF as signed byte

constexpr uint8_t TRIPOD_BRACKET = 0;
constexpr uint8_t TRIPOD_TRIPOD  = 1;

// --------------------------------------------------------------------------
//  System Test Result Bit Flags (SYSTEM_TEST_RESULTS, code 212)
//
//  Bit raised to 1 = failure occurred
//  If RESULTS == 0x0000, all tests passed
// --------------------------------------------------------------------------
constexpr uint16_t TEST_FLAG_RAM          = (1 << 0);   // Bit 0: RAM failure
constexpr uint16_t TEST_FLAG_PORTS        = (1 << 1);   // Bit 1: I/O ports failure
constexpr uint16_t TEST_FLAG_SYNT_DOPP    = (1 << 2);   // Bit 2: Synthesizer/Doppler
constexpr uint16_t TEST_FLAG_RF_TEST      = (1 << 3);   // Bit 3: RF subsystem
constexpr uint16_t TEST_FLAG_ACCELEROMETER = (1 << 4);  // Bit 4: Accelerometer
constexpr uint16_t TEST_FLAG_RF_NOISE     = (1 << 5);   // Bit 5: RF noise

// Bits 6–15 are spare/reserved

// --------------------------------------------------------------------------
//  Serial Port Defaults
// --------------------------------------------------------------------------
constexpr int DEFAULT_BAUD_RATE = 9600;

// --------------------------------------------------------------------------
//  System States (tracked by GUI, not part of wire protocol)
// --------------------------------------------------------------------------
enum class SystemState {
    IDLE,
    MEASURING,
    SYSTEM_TEST
};

// --------------------------------------------------------------------------
//  Helper: Human-readable command name from code
// --------------------------------------------------------------------------
inline QString commandName(uint8_t code)
{
    switch (code) {
    case CMD_EXPECTED_V:            return "EXPECTED_V";
    case CMD_MEASURE:               return "MEASURE";
    case CMD_STOP_MEASURE:          return "STOP_MEASURE";
    case CMD_TXMT_LAST_V:           return "TXMT_LAST_V";
    case CMD_PARALLAX:              return "PARALLAX";
    case CMD_TXMT_PARAMS:           return "TXMT_PARAMS";
    case CMD_ENTER_SYSTEM_TEST:     return "ENTER_SYSTEM_TEST";
    case CMD_PERFORM_SYSTEM_TEST:   return "PERFORM_SYSTEM_TEST";
    case CMD_EXIT_SYSTEM_TEST:      return "EXIT_SYSTEM_TEST";
    case CMD_PERFORM_MVP_TEST:      return "PERFORM_MVP_TEST";
    case CMD_TXMT_MVP_TEST_RESULTS: return "TXMT_MVP_TEST_RESULTS";
    case RSP_ACK:                   return "ACK";
    case RSP_NACK:                  return "NACK";
    case RSP_LAST_V:                return "LAST_V";
    case RSP_PARAMS:                return "PARAMS";
    case RSP_SYSTEM_TEST_RESULTS:   return "SYSTEM_TEST_RESULTS";
    default:                        return QString("UNKNOWN(%1)").arg(code);
    }
}

// --------------------------------------------------------------------------
//  Helper: Response timeout for a given command code
//
//  PERFORM_SYSTEM_TEST needs ~5 seconds (internal diagnostics).
//  Everything else gets the standard 2-second window.
// --------------------------------------------------------------------------
inline int responseTimeout(uint8_t commandCode)
{
    if (commandCode == CMD_PERFORM_SYSTEM_TEST)
        return TIMEOUT_SYSTEM_TEST_MS;
    return TIMEOUT_RESPONSE_MS;
}

// --------------------------------------------------------------------------
//  Helper: Does this command expect a data response (NOT ACK)?
//
//  These commands get a data message back instead of ACK:
//    TXMT_LAST_V (105)          → LAST_V (200)
//    TXMT_PARAMS (107)          → PARAMS (201)
//    PERFORM_SYSTEM_TEST (109)  → SYSTEM_TEST_RESULTS (212)
//    PERFORM_MVP_TEST (111)     → SYSTEM_TEST_RESULTS (212)
//    TXMT_MVP_TEST_RESULTS (112)→ SYSTEM_TEST_RESULTS (212)
// --------------------------------------------------------------------------
inline bool expectsDataResponse(uint8_t commandCode)
{
    switch (commandCode) {
    case CMD_TXMT_LAST_V:
    case CMD_TXMT_PARAMS:
    case CMD_PERFORM_SYSTEM_TEST:
    case CMD_PERFORM_MVP_TEST:
    case CMD_TXMT_MVP_TEST_RESULTS:
        return true;
    default:
        return false;
    }
}

// --------------------------------------------------------------------------
//  Helper: Decode system test flags into human-readable strings
// --------------------------------------------------------------------------
inline QStringList decodeTestFlags(uint16_t flags)
{
    QStringList failures;

    if (flags == 0x0000) {
        failures << "ALL TESTS PASSED";
        return failures;
    }

    if (flags & TEST_FLAG_RAM)           failures << "RAM failure";
    if (flags & TEST_FLAG_PORTS)         failures << "I/O Ports failure";
    if (flags & TEST_FLAG_SYNT_DOPP)     failures << "Synthesizer/Doppler failure";
    if (flags & TEST_FLAG_RF_TEST)       failures << "RF subsystem failure";
    if (flags & TEST_FLAG_ACCELEROMETER) failures << "Accelerometer failure";
    if (flags & TEST_FLAG_RF_NOISE)      failures << "RF noise failure";

    // Check spare bits (6–15)
    uint16_t spareMask = 0xFFC0;
    if (flags & spareMask)
        failures << QString("Unknown flags: 0x%1").arg(flags & spareMask, 4, 16, QChar('0'));

    return failures;
}

// --------------------------------------------------------------------------
//  Helper: System state name
// --------------------------------------------------------------------------
inline QString stateName(SystemState state)
{
    switch (state) {
    case SystemState::IDLE:        return "IDLE";
    case SystemState::MEASURING:   return "MEASURING";
    case SystemState::SYSTEM_TEST: return "SYSTEM_TEST";
    default:                       return "UNKNOWN";
    }
}

} // namespace Protocol

#endif // PROTOCOL_H
