#ifndef MESSAGEPARSER_H
#define MESSAGEPARSER_H

#include <QObject>
#include <QByteArray>
#include <QString>
#include <cstdint>

// ============================================================================
//  VELOCITY RADAR — Message Parser (Layer 3)
//
//  Byte-by-byte state machine that processes incoming serial bytes:
//    WAIT_HEADER_1 → WAIT_HEADER_2 → WAIT_SIZE → COLLECTING
//
//  On complete message: validates checksum, emits messageReceived(ParsedMessage)
//  On error: emits parseError(QString) and resets to WAIT_HEADER_1
//
//  Static decode functions extract typed data from ParsedMessage:
//    decodeAck()              → AckData
//    decodeNack()             → NackData
//    decodeLastV()            → LastVData
//    decodeParams()           → ParamsData
//    decodeSystemTestResults()→ SystemTestData
// ============================================================================

// --------------------------------------------------------------------------
//  ParsedMessage: Raw parsed message (code + data bytes, no headers/checksum)
// --------------------------------------------------------------------------
struct ParsedMessage
{
    uint8_t    code;      // Message code (e.g., 254=ACK, 200=LAST_V)
    QByteArray data;      // Data bytes only (excludes SIZE, CODE, CHECKSUM)
    uint8_t    size;      // Original SIZE field value
};

// --------------------------------------------------------------------------
//  Decoded Response Structs
// --------------------------------------------------------------------------

// ACK (code 254): Command acknowledged
struct AckData
{
    uint8_t acknowledgedCode;   // The command code being ACKed
    bool    valid;
};

// NACK (code 255): Command rejected
struct NackData
{
    uint8_t rejectedCode;       // The command code being NACKed
    bool    valid;
};

// LAST_V (code 200): Last measured velocity
struct LastVData
{
    int8_t   result;            // 0 = OK, -1 (0xFF) = measurement error
    uint16_t rawVelocity;       // Raw wire value (divide by 16 for real m/s)
    double   realVelocity;      // Computed: rawVelocity / 16.0
    bool     valid;
};

// PARAMS (code 201): Current operating parameters
struct ParamsData
{
    uint16_t expectedV;         // 150–1500
    uint8_t  tripod;            // 0 = bracket, 1 = tripod
    uint8_t  x;                 // 0–160 (wire value; real = x/16.0 meters)
    uint8_t  y;                 // 0–160
    uint8_t  z;                 // 0–160
    bool     valid;
};

// SYSTEM_TEST_RESULTS (code 212): Test pass/fail flags
struct SystemTestData
{
    uint16_t flags;             // Bit flags — 0x0000 = all passed
    bool     valid;
};

// ============================================================================
//  MessageParser Class
// ============================================================================

class MessageParser : public QObject
{
    Q_OBJECT

public:
    explicit MessageParser(QObject *parent = nullptr);

    // Feed raw bytes from serial port. Call this from QSerialPort::readyRead handler.
    // May emit messageReceived() or parseError() zero or more times per call.
    void processBytes(const QByteArray &bytes);

    // Reset parser state (e.g., on port close or error recovery)
    void reset();

    // --- Static Decode Functions ---
    // Each returns a struct with a 'valid' flag. If valid==false, data is corrupt.

    static AckData         decodeAck(const ParsedMessage &msg);
    static NackData        decodeNack(const ParsedMessage &msg);
    static LastVData       decodeLastV(const ParsedMessage &msg);
    static ParamsData      decodeParams(const ParsedMessage &msg);
    static SystemTestData  decodeSystemTestResults(const ParsedMessage &msg);

signals:
    // Emitted when a complete, checksum-valid message is parsed
    void messageReceived(const ParsedMessage &msg);

    // Emitted on parse errors (bad checksum, invalid size, etc.)
    void parseError(const QString &errorDescription);

private:
    // Parser state machine states
    enum class State {
        WAIT_HEADER_1,    // Scanning for 'A' (0x41)
        WAIT_HEADER_2,    // Expecting 'B' (0x42)
        WAIT_SIZE,        // Expecting SIZE byte
        COLLECTING        // Accumulating (SIZE - 1) remaining bytes (CODE + DATA + CHECKSUM)
    };

    State      m_state;
    uint8_t    m_size;              // SIZE field value
    int        m_bytesExpected;     // Remaining bytes to collect after SIZE
    QByteArray m_buffer;            // Accumulates [CODE][DATA...][CHECKSUM]

    // Process a single byte through the state machine
    void processByte(uint8_t byte);

    // Validate checksum and emit result
    // fullPayload = [SIZE][CODE][DATA...][CHECKSUM]
    void validateAndEmit();
};

#endif // MESSAGEPARSER_H
