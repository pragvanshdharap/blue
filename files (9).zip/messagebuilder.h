#ifndef MESSAGEBUILDER_H
#define MESSAGEBUILDER_H

#include <QByteArray>
#include <cstdint>

// ============================================================================
//  VELOCITY RADAR — Message Builder (Layer 2)
//
//  One static function per command. Each returns a complete QByteArray
//  ready to send over the wire:
//    ['A']['B'][SIZE][CODE][DATA...][CHECKSUM]
//
//  Checksum: Two's complement of (sum of bytes from SIZE to last DATA byte)
//            CHECKSUM = (-sum) & 0xFF
//
//  All multi-byte data fields are LITTLE-ENDIAN (LSB first).
// ============================================================================

class MessageBuilder
{
public:
    // --- Commands (PC → Embedded System) ---

    // CMD 102: Set Expected Velocity (150–1500)
    // Wire: ['A']['B'][05][66][V_LO][V_HI][CHECKSUM]
    static QByteArray buildExpectedV(uint16_t velocity);

    // CMD 103: Enter Measure Mode
    // Wire: ['A']['B'][03][67][CHECKSUM]
    static QByteArray buildMeasure();

    // CMD 104: Stop Measure (exit measure mode)
    // Wire: ['A']['B'][03][68][CHECKSUM]
    static QByteArray buildStopMeasure();

    // CMD 105: Transmit Last Velocity
    // Wire: ['A']['B'][02][69][CHECKSUM]
    // NOTE: SIZE=2 per spec (unusual — only SIZE + CODE, no checksum in size count?
    //       Actually SIZE includes itself+CODE+CHECKSUM = 2+1? No — spec says SIZE=2.
    //       Let's follow the spec exactly: SIZE=2)
    static QByteArray buildTxmtLastV();

    // CMD 106: Set Parallax Parameters
    // Wire: ['A']['B'][07][6A][TRIPOD][X][Y][Z][CHECKSUM]
    // tripod: 0=bracket, 1=tripod
    // x,y,z: 0–160 (wire value = real_meters × 16)
    static QByteArray buildParallax(uint8_t tripod, uint8_t x, uint8_t y, uint8_t z);

    // CMD 107: Transmit Parameters
    // Wire: ['A']['B'][03][6B][CHECKSUM]
    static QByteArray buildTxmtParams();

    // CMD 108: Enter System Test Mode
    // Wire: ['A']['B'][03][6C][CHECKSUM]
    static QByteArray buildEnterSystemTest();

    // CMD 109: Perform System Test
    // Wire: ['A']['B'][03][6D][CHECKSUM]
    static QByteArray buildPerformSystemTest();

    // CMD 110: Exit System Test Mode
    // Wire: ['A']['B'][03][6E][CHECKSUM]
    static QByteArray buildExitSystemTest();

    // CMD 111: Perform MVP Test
    // Wire: ['A']['B'][03][6F][CHECKSUM]
    static QByteArray buildPerformMVPTest();

    // CMD 112: Transmit MVP Test Results
    // Wire: ['A']['B'][03][70][CHECKSUM]
    static QByteArray buildTxmtMVPTestResults();

private:
    // Compute two's complement checksum over payload bytes
    // sum = SIZE + CODE + DATA_1 + ... + DATA_M
    // CHECKSUM = (-sum) & 0xFF
    static uint8_t computeChecksum(const QByteArray &payload);

    // Build complete frame: header + payload + checksum
    // payload = [SIZE][CODE][DATA...]
    static QByteArray buildFrame(const QByteArray &payload);
};

#endif // MESSAGEBUILDER_H
