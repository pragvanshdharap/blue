#include "serialcomm.h"
#include "protocol.h"

#include <QDebug>

// ============================================================================
//  VELOCITY RADAR — Serial Communication Implementation (Layer 4)
//
//  Data flow:
//    SEND: sendMessage() → QSerialPort::write() → start timeout timer
//    RECV: QSerialPort::readyRead → onReadyRead() → parser.processBytes()
//          → parser emits messageReceived → stop timer → re-emit to UI
//
//  Serial settings: 8N1, no flow control (per Interface Spec)
// ============================================================================

SerialComm::SerialComm(QObject *parent)
    : QObject(parent)
    , m_serialPort(new QSerialPort(this))
    , m_parser(new MessageParser(this))
    , m_responseTimer(new QTimer(this))
    , m_pendingCommandCode(0)
    , m_waitingForResponse(false)
{
    // Response timer is single-shot
    m_responseTimer->setSingleShot(true);

    // --- Connect QSerialPort signals ---
    connect(m_serialPort, &QSerialPort::readyRead,
            this, &SerialComm::onReadyRead);

    connect(m_serialPort, &QSerialPort::errorOccurred,
            this, &SerialComm::onSerialError);

    // --- Connect MessageParser signals ---
    connect(m_parser, &MessageParser::messageReceived,
            this, &SerialComm::onParserMessageReceived);

    connect(m_parser, &MessageParser::parseError,
            this, &SerialComm::onParserError);

    // --- Connect timeout timer ---
    connect(m_responseTimer, &QTimer::timeout,
            this, &SerialComm::onResponseTimeout);
}

SerialComm::~SerialComm()
{
    if (m_serialPort->isOpen()) {
        m_serialPort->close();
    }
}

// ============================================================================
//  Port Control
// ============================================================================

bool SerialComm::openPort(const QString &portName, int baudRate)
{
    // Close if already open
    if (m_serialPort->isOpen()) {
        closePort();
    }

    m_serialPort->setPortName(portName);
    m_serialPort->setBaudRate(baudRate);
    m_serialPort->setDataBits(QSerialPort::Data8);
    m_serialPort->setParity(QSerialPort::NoParity);
    m_serialPort->setStopBits(QSerialPort::OneStop);
    m_serialPort->setFlowControl(QSerialPort::NoFlowControl);

    if (!m_serialPort->open(QIODevice::ReadWrite)) {
        emit portError(QString("Failed to open %1: %2")
                       .arg(portName, m_serialPort->errorString()));
        return false;
    }

    // Reset parser state on new connection
    m_parser->reset();
    m_waitingForResponse = false;
    m_responseTimer->stop();

    emit portOpened(portName, baudRate);
    return true;
}

void SerialComm::closePort()
{
    m_responseTimer->stop();
    m_waitingForResponse = false;
    m_parser->reset();

    if (m_serialPort->isOpen()) {
        m_serialPort->close();
    }

    emit portClosed();
}

bool SerialComm::isOpen() const
{
    return m_serialPort->isOpen();
}

QString SerialComm::currentPortName() const
{
    return m_serialPort->portName();
}

int SerialComm::currentBaudRate() const
{
    return m_serialPort->baudRate();
}

// ============================================================================
//  Sending
// ============================================================================

void SerialComm::sendMessage(const QByteArray &message, uint8_t commandCode)
{
    if (!m_serialPort->isOpen()) {
        emit portError("Cannot send: serial port is not open");
        return;
    }

    // Write bytes to serial port
    qint64 bytesWritten = m_serialPort->write(message);
    if (bytesWritten != message.size()) {
        emit portError(QString("Write error: sent %1 of %2 bytes")
                       .arg(bytesWritten).arg(message.size()));
        return;
    }

    // Emit raw data for hex logging
    emit rawDataSent(message);

    // Start response timeout timer
    m_pendingCommandCode = commandCode;
    m_waitingForResponse = true;
    int timeout = Protocol::responseTimeout(commandCode);
    m_responseTimer->start(timeout);
}

// ============================================================================
//  Port Discovery
// ============================================================================

QStringList SerialComm::availablePorts()
{
    QStringList portNames;
    const QList<QSerialPortInfo> ports = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : ports) {
        portNames << info.portName();
    }
    return portNames;
}

// ============================================================================
//  Private Slots
// ============================================================================

// --- QSerialPort::readyRead ---
void SerialComm::onReadyRead()
{
    QByteArray data = m_serialPort->readAll();
    if (data.isEmpty())
        return;

    // Emit raw bytes for hex logging
    emit rawDataReceived(data);

    // Feed bytes to parser (may emit messageReceived or parseError)
    m_parser->processBytes(data);
}

// --- QSerialPort::errorOccurred ---
void SerialComm::onSerialError(QSerialPort::SerialPortError error)
{
    // QSerialPort::NoError is emitted on successful operations — ignore it
    if (error == QSerialPort::NoError)
        return;

    QString errorMsg;
    switch (error) {
    case QSerialPort::DeviceNotFoundError:
        errorMsg = "Device not found";
        break;
    case QSerialPort::PermissionError:
        errorMsg = "Permission denied (port may be in use)";
        break;
    case QSerialPort::OpenError:
        errorMsg = "Failed to open port";
        break;
    case QSerialPort::WriteError:
        errorMsg = "Write error";
        break;
    case QSerialPort::ReadError:
        errorMsg = "Read error";
        break;
    case QSerialPort::ResourceError:
        errorMsg = "Port disconnected (cable removed?)";
        // Port is gone — clean up
        m_responseTimer->stop();
        m_waitingForResponse = false;
        m_parser->reset();
        if (m_serialPort->isOpen()) {
            m_serialPort->close();
        }
        emit portClosed();
        break;
    default:
        errorMsg = QString("Serial error code %1").arg(static_cast<int>(error));
        break;
    }

    emit portError(errorMsg);
}

// --- Response timeout fired ---
void SerialComm::onResponseTimeout()
{
    if (m_waitingForResponse) {
        uint8_t code = m_pendingCommandCode;
        m_waitingForResponse = false;
        emit responseTimeout(code);
    }
}

// --- MessageParser found a valid message ---
void SerialComm::onParserMessageReceived(const ParsedMessage &msg)
{
    // Stop response timeout — we got a response
    m_responseTimer->stop();
    m_waitingForResponse = false;

    // Forward to UI layer
    emit messageReceived(msg);
}

// --- MessageParser detected an error ---
void SerialComm::onParserError(const QString &errorDescription)
{
    // Forward parse error to UI layer for logging
    emit parseError(errorDescription);
}
