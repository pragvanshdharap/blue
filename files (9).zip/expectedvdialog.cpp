#include "expectedvdialog.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>

// ============================================================================
//  VELOCITY RADAR — Expected Velocity Dialog Implementation (Layer 5)
//
//  Built programmatically to avoid Ui::Dialog name collision with mainwindow.ui.
//  Simple layout: title label, text input, range hint, OK/Cancel buttons.
//  Validates input is integer in range 150–1500.
// ============================================================================

ExpectedVDialog::ExpectedVDialog(QWidget *parent)
    : QDialog(parent)
    , m_velocity(0)
{
    setWindowTitle("Set Expected Velocity");
    setFixedSize(400, 200);

    // --- Title label ---
    QLabel *titleLabel = new QLabel("Enter Expected Velocity (m/s):", this);
    titleLabel->setStyleSheet("font-weight: bold; font-size: 11pt;");

    // --- Text input ---
    m_textEdit = new QTextEdit(this);
    m_textEdit->setFixedHeight(35);
    m_textEdit->setPlaceholderText("e.g. 500");
    m_textEdit->setTabChangesFocus(true);   // Tab moves to buttons, not inserts tab

    // --- Range hint ---
    QLabel *rangeLabel = new QLabel(
        QString("Range: %1 – %2")
            .arg(Protocol::EXPECTED_V_MIN)
            .arg(Protocol::EXPECTED_V_MAX),
        this);
    rangeLabel->setStyleSheet("color: #7F8C8D; font-size: 9pt;");

    // --- Buttons ---
    m_okBtn = new QPushButton("OK", this);
    m_cancelBtn = new QPushButton("Cancel", this);
    m_okBtn->setFixedWidth(90);
    m_cancelBtn->setFixedWidth(90);

    QHBoxLayout *buttonLayout = new QHBoxLayout();
    buttonLayout->addStretch();
    buttonLayout->addWidget(m_okBtn);
    buttonLayout->addWidget(m_cancelBtn);

    // --- Main layout ---
    QVBoxLayout *mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(titleLabel);
    mainLayout->addWidget(m_textEdit);
    mainLayout->addWidget(rangeLabel);
    mainLayout->addStretch();
    mainLayout->addLayout(buttonLayout);

    setLayout(mainLayout);

    // --- Connections ---
    connect(m_okBtn, &QPushButton::clicked, this, &ExpectedVDialog::onOkClicked);
    connect(m_cancelBtn, &QPushButton::clicked, this, &ExpectedVDialog::onCancelClicked);
}

uint16_t ExpectedVDialog::velocity() const
{
    return m_velocity;
}

void ExpectedVDialog::onOkClicked()
{
    QString text = m_textEdit->toPlainText().trimmed();

    // Validate: must be a valid integer
    bool ok = false;
    int value = text.toInt(&ok);

    if (!ok) {
        QMessageBox::warning(this, "Invalid Input",
            "Please enter a valid integer value.");
        m_textEdit->setFocus();
        return;
    }

    // Validate: must be in range 150–1500
    if (value < Protocol::EXPECTED_V_MIN || value > Protocol::EXPECTED_V_MAX) {
        QMessageBox::warning(this, "Out of Range",
            QString("Expected velocity must be between %1 and %2.\nYou entered: %3")
                .arg(Protocol::EXPECTED_V_MIN)
                .arg(Protocol::EXPECTED_V_MAX)
                .arg(value));
        m_textEdit->setFocus();
        return;
    }

    // Valid! Store and accept
    m_velocity = static_cast<uint16_t>(value);
    accept();
}

void ExpectedVDialog::onCancelClicked()
{
    reject();
}
