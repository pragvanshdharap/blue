#ifndef EXPECTEDVDIALOG_H
#define EXPECTEDVDIALOG_H

#include <QDialog>
#include <QTextEdit>
#include <QPushButton>
#include <QMessageBox>
#include <cstdint>

#include "protocol.h"

// ============================================================================
//  VELOCITY RADAR — Expected Velocity Input Dialog (Layer 5)
//
//  Wraps the Expected_v.ui form.
//  Uses the existing QTextEdit for user input with code-side validation.
//  Range: 150–1500 (integer only)
//
//  IMPORTANT: Both mainwindow.ui and Expected_v.ui have class="Dialog",
//  so both generate Ui::Dialog in their respective ui_*.h files.
//  To avoid collision, this dialog manually sets up widgets by finding
//  them from the .ui form, OR we rename the class in Expected_v.ui.
//
//  RECOMMENDED FIX: In Qt Designer, open Expected_v.ui and change the
//  object name from "Dialog" to "ExpectedVDialog". This produces
//  Ui::ExpectedVDialog instead of Ui::Dialog.
//
//  For now, we build this dialog programmatically (no .ui dependency)
//  since the dialog is simple: label + text input + OK/Cancel.
//
//  Usage:
//    ExpectedVDialog dlg(this);
//    if (dlg.exec() == QDialog::Accepted) {
//        uint16_t velocity = dlg.velocity();
//        // ... send EXPECTED_V command
//    }
// ============================================================================

class ExpectedVDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ExpectedVDialog(QWidget *parent = nullptr);
    ~ExpectedVDialog() = default;

    // Get the validated velocity value (only valid after Accepted)
    uint16_t velocity() const;

private slots:
    void onOkClicked();
    void onCancelClicked();

private:
    QTextEdit    *m_textEdit;
    QPushButton  *m_okBtn;
    QPushButton  *m_cancelBtn;

    uint16_t m_velocity;
};

#endif // EXPECTEDVDIALOG_H
