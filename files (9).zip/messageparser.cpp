#include "messageparser.h"
#include "protocol.h"

// ============================================================================
//  VELOCITY RADAR — Message Parser Implementation (Layer 3)
//
//  State Machine:
//    WAIT_HEADER_1 → on 'A' → WAIT_HEADER_2
//    WAIT_HEADER_2 → on 'B' → WAIT_SIZE
//                  → on 'A' → stay WAIT_HEADER_2 (could be start of new frame)
//                  → else   → back to WAIT_HEADER_1
//    WAIT_SIZE     → capture SIZE, compute bytesExpected = SIZE - 1
//                  → if SIZE < 2 → error, reset
//    COLLECTING    → accumulate bytes until bytesExpected == 0
//                  → validate checksum → emit or error
//
//  Checksum Verification:
//    (SIZE + CODE + DATA_1 + ... + DATA_M + CHECKSUM) mod 256 == 0
// ============================================================================

MessageParser::MessageParser(QObject *parent)
    : QObject(parent)
    , m_state(State::WAIT_HEADER_1)
    , m_size(0)
    , m_bytesExpected(0)
{
}

// ----------------------------------------------------------------------------
//  Reset parser to initial state
// ----------------------------------------------------------------------------
void MessageParser::reset()
{
    m_state = State::WAIT_HEADER_1;
    m_size = 0;
    m_bytesExpected = 0;
    m_buffer.clear();
}

// ----------------------------------------------------------------------------
//  Process a chunk of bytes (may contain partial/multiple messages)
// ----------------------------------------------------------------------------
void MessageParser::processBytes(const QByteArray &bytes)
{
    for (int i = 0; i < bytes.size(); ++i) {
        processByte(static_cast<uint8_t>(bytes.at(i)));
    }
}

// ----------------------------------------------------------------------------
//  Process a single byte through the state machine
// ----------------------------------------------------------------------------
void MessageParser::processByte(uint8_t byte)
{
    switch (m_state) {

    case State::WAIT_HEADER_1:
        if (byte == Protocol::HEADER_1) {
            m_state = State::WAIT_HEADER_2;
        }
        // else: ignore byte, keep scanning
        break;

    case State::WAIT_HEADER_2:
        if (byte == Protocol::HEADER_2) {
            m_state = State::WAIT_SIZE;
        } else if (byte == Protocol::HEADER_1) {
            // Could be start of a new 'A','B' sequence — stay in WAIT_HEADER_2
            // (the previous 'A' was a false start)
        } else {
            // Not 'B' and not 'A' — false header, reset
            m_state = State::WAIT_HEADER_1;
        }
        break;

    case State::WAIT_SIZE:
        m_size = byte;

        // SIZE must be at least 2 (SIZE itself + CODE; even with no data, checksum is needed)
        // Actually per spec, minimum SIZE = 2 (TXMT_LAST_V) or SIZE = 3 (most commands)
        // SIZE includes: SIZE + CODE + DATA + CHECKSUM
        // So remaining bytes after SIZE = SIZE - 1 (CODE + DATA + CHECKSUM)
        if (m_size < 2) {
            emit parseError(QString("Invalid SIZE field: %1 (minimum is 2)").arg(m_size));
            m_state = State::WAIT_HEADER_1;
            break;
        }

        m_bytesExpected = m_size - 1;  // Remaining bytes: CODE + DATA... + CHECKSUM
        m_buffer.clear();
        m_buffer.reserve(m_bytesExpected);
        m_state = State::COLLECTING;
        break;

    case State::COLLECTING:
        m_buffer.append(static_cast<char>(byte));
        m_bytesExpected--;

        if (m_bytesExpected == 0) {
            // All bytes collected — validate checksum and emit
            validateAndEmit();
            m_state = State::WAIT_HEADER_1;
        }
        break;
    }
}

// ----------------------------------------------------------------------------
//  Validate checksum and emit messageReceived or parseError
//
//  m_buffer contains: [CODE][DATA_1]...[DATA_M][CHECKSUM]
//  Full payload for checksum: [SIZE] + m_buffer
//
//  Verification: (SIZE + CODE + DATA... + CHECKSUM) mod 256 == 0
// ----------------------------------------------------------------------------
void MessageParser::validateAndEmit()
{
    // Compute checksum verification
    uint8_t sum = m_size;  // Start with SIZE byte
    for (int i = 0; i < m_buffer.size(); ++i) {
        sum += static_cast<uint8_t>(m_buffer.at(i));
    }

    if (sum != 0) {
        emit parseError(QString("Checksum validation failed (sum=%1, expected 0)").arg(sum));
        return;
    }

    // Checksum OK — extract message fields
    // m_buffer = [CODE][DATA_1]...[DATA_M][CHECKSUM]
    // CODE is first byte, CHECKSUM is last byte, DATA is everything in between

    ParsedMessage msg;
    msg.size = m_size;
    msg.code = static_cast<uint8_t>(m_buffer.at(0));

    // Data bytes = everything between CODE and CHECKSUM
    // m_buffer has (m_size - 1) bytes total
    // DATA length = (m_size - 1) - 1(CODE) - 1(CHECKSUM) = m_size - 3
    int dataLength = m_size - 3;
    if (dataLength > 0) {
        msg.data = m_buffer.mid(1, dataLength);  // Skip CODE, take dataLength bytes
    } else {
        msg.data.clear();
    }

    emit messageReceived(msg);
}

// ============================================================================
//  Static Decode Functions
// ============================================================================

// ----------------------------------------------------------------------------
//  Decode ACK (code 254)
//  Data: [MESSAGE] — 1 byte, the code of the acknowledged command
// ----------------------------------------------------------------------------
AckData MessageParser::decodeAck(const ParsedMessage &msg)
{
    AckData result;
    result.valid = false;

    if (msg.code != Protocol::RSP_ACK) return result;
    if (msg.data.size() != 1) return result;

    result.acknowledgedCode = static_cast<uint8_t>(msg.data.at(0));
    result.valid = true;
    return result;
}

// ----------------------------------------------------------------------------
//  Decode NACK (code 255)
//  Data: [MESSAGE] — 1 byte, the code of the rejected command
// ----------------------------------------------------------------------------
NackData MessageParser::decodeNack(const ParsedMessage &msg)
{
    NackData result;
    result.valid = false;

    if (msg.code != Protocol::RSP_NACK) return result;
    if (msg.data.size() != 1) return result;

    result.rejectedCode = static_cast<uint8_t>(msg.data.at(0));
    result.valid = true;
    return result;
}

// ----------------------------------------------------------------------------
//  Decode LAST_V (code 200)
//  Data: [RESULT][V_LO][V_HI] — 3 bytes
//  RESULT: 0 = OK, 0xFF (-1 signed) = measurement error
//  LAST_V: uint16 LE, raw/16.0 = real velocity
// ----------------------------------------------------------------------------
LastVData MessageParser::decodeLastV(const ParsedMessage &msg)
{
    LastVData result;
    result.valid = false;
    result.result = 0;
    result.rawVelocity = 0;
    result.realVelocity = 0.0;

    if (msg.code != Protocol::RSP_LAST_V) return result;
    if (msg.data.size() != 3) return result;

    result.result = static_cast<int8_t>(msg.data.at(0));

    uint8_t vLo = static_cast<uint8_t>(msg.data.at(1));
    uint8_t vHi = static_cast<uint8_t>(msg.data.at(2));
    result.rawVelocity = static_cast<uint16_t>(vLo | (vHi << 8));

    result.realVelocity = result.rawVelocity / 16.0;
    result.valid = true;
    return result;
}

// ----------------------------------------------------------------------------
//  Decode PARAMS (code 201)
//  Data: [V_LO][V_HI][TRIPOD][X][Y][Z] — 6 bytes
// ----------------------------------------------------------------------------
ParamsData MessageParser::decodeParams(const ParsedMessage &msg)
{
    ParamsData result;
    result.valid = false;
    result.expectedV = 0;
    result.tripod = 0;
    result.x = 0;
    result.y = 0;
    result.z = 0;

    if (msg.code != Protocol::RSP_PARAMS) return result;
    if (msg.data.size() != 6) return result;

    uint8_t vLo = static_cast<uint8_t>(msg.data.at(0));
    uint8_t vHi = static_cast<uint8_t>(msg.data.at(1));
    result.expectedV = static_cast<uint16_t>(vLo | (vHi << 8));

    result.tripod = static_cast<uint8_t>(msg.data.at(2));
    result.x      = static_cast<uint8_t>(msg.data.at(3));
    result.y      = static_cast<uint8_t>(msg.data.at(4));
    result.z      = static_cast<uint8_t>(msg.data.at(5));

    result.valid = true;
    return result;
}

// ----------------------------------------------------------------------------
//  Decode SYSTEM_TEST_RESULTS (code 212)
//  Data: [FLAGS_LO][FLAGS_HI] — 2 bytes
//  Bit raised to 1 = failure. 0x0000 = all passed.
// ----------------------------------------------------------------------------
SystemTestData MessageParser::decodeSystemTestResults(const ParsedMessage &msg)
{
    SystemTestData result;
    result.valid = false;
    result.flags = 0;

    if (msg.code != Protocol::RSP_SYSTEM_TEST_RESULTS) return result;
    if (msg.data.size() != 2) return result;

    uint8_t fLo = static_cast<uint8_t>(msg.data.at(0));
    uint8_t fHi = static_cast<uint8_t>(msg.data.at(1));
    result.flags = static_cast<uint16_t>(fLo | (fHi << 8));

    result.valid = true;
    return result;
}
