# VELOCITY RADAR — QUICK START CHECKLIST

## ✅ Pre-Build Checklist (5 minutes)

- [ ] Qt 6.9.2 installed at `C:\Qt\6.9.2\mingw_64\`
- [ ] MinGW compiler available (`g++ --version` works)
- [ ] CMake 3.16+ installed (`cmake --version` works)
- [ ] All 13 `.cpp` and `.h` files downloaded
- [ ] Files placed in correct directories (see `COMPLETE_GUIDE.md`)
- [ ] `src\ui\mainwindow.ui` exists
- [ ] `CMakeLists.txt` exists in root

## 🔨 Build Checklist (2 minutes)

```powershell
cd C:\projects\velocity_radar
mkdir build
cd build
cmake .. -G "MinGW Makefiles" -DCMAKE_PREFIX_PATH="C:/Qt/6.9.2/mingw_64"
cmake --build .
```

**Expected:** `[100%] Built target VelocityRadar` with no errors

- [ ] Build completed successfully
- [ ] `build\VelocityRadar.exe` exists
- [ ] No errors in console output

## 🚀 First Run (1 minute)

```powershell
cd C:\projects\velocity_radar\build
.\VelocityRadar.exe
```

**Expected:** Window appears with title "VELOCITY RADAR"

- [ ] Window opens
- [ ] Title bar says "VELOCITY RADAR"
- [ ] No crashes
- [ ] Log shows: `Application started`

## 🔌 Connect to Embedded System

**Before app:**
- [ ] USB-to-RS422 adapter plugged in
- [ ] RS-422 cable connected to radar
- [ ] Windows Device Manager shows COM port (e.g., COM3)
- [ ] Embedded system powered on

**In app:**
1. Check COM dropdown (should show available ports)
2. Select correct port (e.g., COM3)
3. Verify baud rate is 9600
4. Click "CONNECT"
5. Check log for: `Connected to COM3 @ 9600 baud`
6. Check status indicator: should be 🟢 green

- [ ] Connected successfully
- [ ] Status shows green circle
- [ ] All buttons now enabled

## 📝 Send Your First Command

1. Click "Enter Measure Mode"
2. Watch log panel:
   ```
   [SEND] MEASURE (code 103)
   [RAW] TX: 41 42 03 67 96
   [RAW] RX: 41 42 04 FE 67 97
   [ACK] Acknowledged (code 103)
   [INFO] State changed to MEASURING
   ```
3. Notice "State: IDLE" changed to "State: MEASURING"
4. Notice "Stop Measure" button is now the only enabled command button

**If you see this, the protocol stack works!**

- [ ] Command sent without errors
- [ ] ACK received
- [ ] State changed correctly
- [ ] Log shows colored message types

## 🧪 Test: Request Last Velocity

1. Click "Transmit Last M"
2. Watch log:
   ```
   [SEND] TXMT_LAST_V (code 105)
   [RAW] TX: 41 42 02 69 95
   [RAW] RX: 41 42 06 C8 [V_LO] [V_HI] [CHECKSUM]
   [RECV] LAST_V: 450.0 m/s (raw=7200)
   ```

**If you see actual velocity values, end-to-end communication works!**

- [ ] Last velocity command accepted
- [ ] Numerical velocity value displayed
- [ ] No timeouts

## 🛑 Clean Up

1. Click "Stop Measure" to exit MEASURING state
2. Click "DISCONNECT" to close serial port
3. Close the application

- [ ] Disconnected without errors
- [ ] Status shows red circle
- [ ] No crash on exit

---

## 🚨 Troubleshooting — Most Common Issues

### "cmake: command not found"
```powershell
$env:Path += ";C:\Qt\6.9.2\Tools\CMake\bin"
cmake --version  # Should work now
```

### "g++: command not found"
```powershell
$env:Path += ";C:\Qt\6.9.2\mingw_64\bin"
g++ --version  # Should work now
```

### Build fails with "Cannot find Qt6"
- Verify your Qt installation: `dir C:\Qt\6.9.2\mingw_64\lib\cmake\Qt6`
- If wrong path, update the cmake command: `-DCMAKE_PREFIX_PATH="C:/YOUR/PATH/HERE"`

### "No ports found" in dropdown
- Check Device Manager (Win+R → devmgmt.msc)
- Is the USB adapter showing under "Ports (COM & LPT)"?
- If not, driver may not be installed

### Application starts but buttons don't respond
- Make sure port is connected first (click CONNECT)
- Check that COM port dropdown is not "No ports found"

### Command sends but no response (timeout)
```
[ERROR] TIMEOUT: No response to MEASURE (code 103) after 2.0s
```
- Is embedded system powered on?
- Is RS-422 cable properly connected?
- Is it at the correct baud rate (9600)?
- Try the command again (may have been a transient error)

---

## 📚 Next: Read Full Documentation

Open `COMPLETE_GUIDE.md` for:
- Detailed file layout
- Step-by-step build instructions with screenshots
- Complete GUI usage walkthrough
- Testing without embedded system (simulating with PuTTY)
- Protocol debugging tips
- Adding new commands or customizing

---

## 📞 Quick Reference

| What | Command | Expected |
|------|---------|----------|
| **Build** | `cmake --build .` | `[100%] Built target` |
| **Run** | `.\VelocityRadar.exe` | "VELOCITY RADAR" window |
| **Connect** | Select COM + click CONNECT | Status: 🟢 Connected |
| **First test** | Click "Enter Measure Mode" | [ACK] logged + State: MEASURING |
| **Disconnect** | Click DISCONNECT | Status: ⚫ Disconnected |

---

**You're ready! Start with the build checklist above.** 🚀
