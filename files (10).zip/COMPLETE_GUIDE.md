# VELOCITY RADAR GUI — Complete Setup & Usage Guide

## Table of Contents
1. [Project Overview](#project-overview)
2. [System Requirements](#system-requirements)
3. [Project Setup](#project-setup)
4. [Building the Project](#building-the-project)
5. [Running the Application](#running-the-application)
6. [Using the GUI](#using-the-gui)
7. [Testing & Debugging](#testing--debugging)
8. [Troubleshooting](#troubleshooting)

---

## Project Overview

The **Velocity Radar GUI** is a Qt 6.9.2 application that communicates with an embedded Doppler radar system over RS-422 serial (via USB adapter).

### What It Does
- **Opens serial port** (COM port at 9600 baud, 8N1 no flow control)
- **Sends 11 command types** (EXPECTED_V, MEASURE, STOP_MEASURE, etc.)
- **Receives responses** (ACK, NACK, LAST_V, PARAMS, SYSTEM_TEST_RESULTS)
- **Validates checksums** and resynchronizes on errors
- **Tracks system state** (IDLE / MEASURING / SYSTEM_TEST)
- **Logs all activity** with color-coded messages

### Architecture (5 Layers)
```
Layer 5: MainWindow + ExpectedVDialog   (Qt GUI, button handlers, state machine)
Layer 4: SerialComm                     (QSerialPort wrapper, timeouts)
Layer 3: MessageParser                  (Byte-by-byte state machine, checksum validation)
Layer 2: MessageBuilder                 (Command encoding)
Layer 1: Protocol                       (Constants, codes, ranges, helpers)
```

---

## System Requirements

### Hardware
- PC running Windows 10+
- USB-to-RS422 adapter (presents as virtual COM port)
- RS-422 cable to embedded Velocity Radar system
- At least 1 available USB port

### Software
- **Qt 6.9.2** with MinGW compiler and Qt Serial Port module
  - Download from: https://www.qt.io/download
  - Select "Custom Installation" → MinGW 11.2 64-bit + Qt Serial Port
- **MinGW Compiler** (bundled with Qt or standalone)
- **CMake 3.16+** (bundled with Qt Creator, or standalone from cmake.org)
- **VS Code** (optional but recommended)
  - Extensions: "CMake Tools" (ms-vscode.cmake-tools)

### Verify Installation

**Windows PowerShell:**
```powershell
# Check Qt installation
dir "C:\Qt\6.9.2\mingw_64\bin\qmake.exe"
# Expected: C:\Qt\6.9.2\mingw_64\bin\qmake.exe  (exists)

# Check MinGW
g++ --version
# Expected: g++ (x86_64-posix-seh-rev0, Built by MinGW-W64 project) 11.2.0

# Check CMake
cmake --version
# Expected: cmake version 3.16 or higher
```

---

## Project Setup

### Step 1: Create Project Directory Structure

```powershell
# Create the project folder
mkdir C:\projects\velocity_radar
cd C:\projects\velocity_radar

# Create source and UI directories
mkdir src
mkdir src\ui
```

### Step 2: Download & Place Files

Download these 13 files from the outputs folder and place them as follows:

```
C:\projects\velocity_radar\
├── CMakeLists.txt                      ← Root
└── src\
    ├── main.cpp
    ├── protocol.h
    ├── messagebuilder.h
    ├── messagebuilder.cpp
    ├── messageparser.h
    ├── messageparser.cpp
    ├── serialcomm.h
    ├── serialcomm.cpp
    ├── expectedvdialog.h
    ├── expectedvdialog.cpp
    ├── mainwindow.h
    ├── mainwindow.cpp
    └── ui\
        └── mainwindow.ui              ← Your existing mainwindow.ui file
```

**NOTE:** You do NOT need `Expected_v.ui` — the dialog is built programmatically in code.

### Step 3: Verify File Placement

**PowerShell:**
```powershell
cd C:\projects\velocity_radar
ls src\*.h    # Should list 7 headers
ls src\*.cpp  # Should list 7 cpp files
ls src\ui\    # Should list mainwindow.ui
type CMakeLists.txt  # Check it exists
```

Expected output:
```
Directory: C:\projects\velocity_radar\src

Mode                 LastWriteTime         Length Name
----                 ----                   ------ ----
-a---          5/21/2026    14:32           8192  protocol.h
-a---          5/21/2026    14:32           4096  messagebuilder.h
-a---          5/21/2026    14:32           8192  messagebuilder.cpp
-a---          5/21/2026    14:32           8192  messageparser.h
-a---          5/21/2026    14:32          12288  messageparser.cpp
-a---          5/21/2026    14:32           4096  serialcomm.h
-a---          5/21/2026    14:32           8192  serialcomm.cpp
-a---          5/21/2026    14:32           4096  expectedvdialog.h
-a---          5/21/2026    14:32           4096  expectedvdialog.cpp
-a---          5/21/2026    14:32           4096  mainwindow.h
-a---          5/21/2026    14:32          24576  mainwindow.cpp
-a---          5/21/2026    14:32           4096  main.cpp
```

---

## Building the Project

### Option A: Command Line (Windows PowerShell)

```powershell
cd C:\projects\velocity_radar

# Step 1: Create build directory
mkdir build
cd build

# Step 2: Configure CMake
# Replace C:/Qt/6.9.2/mingw_64 with your Qt installation path
cmake .. -G "MinGW Makefiles" -DCMAKE_PREFIX_PATH="C:/Qt/6.9.2/mingw_64"

# Step 3: Build
cmake --build .

# Step 4: You should see:
#   [100%] Linking CXX executable VelocityRadar.exe
#   [100%] Built target VelocityRadar
```

**Expected build time:** 30–60 seconds on first build, 5–10 seconds on rebuilds.

### Option B: VS Code (Recommended for Development)

#### Setup VS Code

1. **Open folder in VS Code:**
   ```powershell
   code C:\projects\velocity_radar
   ```

2. **Install Extension:**
   - Open Extensions (Ctrl+Shift+X)
   - Search: "CMake Tools"
   - Install by Microsoft (ms-vscode.cmake-tools)

3. **Create `.vscode/settings.json`:**
   ```powershell
   mkdir .vscode
   # Create file: .vscode/settings.json
   ```

   Content:
   ```json
   {
       "cmake.configureArgs": [
           "-DCMAKE_PREFIX_PATH=C:/Qt/6.9.2/mingw_64"
       ],
       "cmake.generator": "MinGW Makefiles",
       "cmake.buildDirectory": "${workspaceFolder}/build"
   }
   ```

4. **Build in VS Code:**
   - Press `Ctrl+Shift+P`
   - Type: "CMake: Configure"
   - Wait for configuration to complete
   - Press `Ctrl+Shift+P` → "CMake: Build"
   - Watch the output panel for build progress

#### Expected Output
```
[main] Building folder: velocity_radar 
[proc] Executing command: cmake --build C:\projects\velocity_radar\build --config Debug -- -j10
[build] Starting build
[build] [  1%] Building CXX object CMakeFiles/VelocityRadar.dir/src/main.cpp.o
[build] [ 25%] Building CXX object CMakeFiles/VelocityRadar.dir/src/mainwindow.cpp.o
[build] [ 50%] Building CXX object CMakeFiles/VelocityRadar.dir/src/serialcomm.cpp.o
[build] [ 75%] Building CXX object CMakeFiles/VelocityRadar.dir/src/messageparser.cpp.o
[build] [100%] Linking CXX executable VelocityRadar.exe
[build] [100%] Built target VelocityRadar
[build] Build finished
```

---

## Running the Application

### After Successful Build

The executable is at:
```
C:\projects\velocity_radar\build\VelocityRadar.exe
```

### Option 1: From VS Code
- Press `Ctrl+Shift+P` → "CMake: Run Without Debugging"
- OR: Press `Ctrl+F5`

### Option 2: From PowerShell
```powershell
cd C:\projects\velocity_radar\build
.\VelocityRadar.exe
```

### Option 3: From Windows Explorer
- Navigate to `C:\projects\velocity_radar\build`
- Double-click `VelocityRadar.exe`

### First Run
You should see the main window with:
- Title: "VELOCITY RADAR"
- COM port dropdown (likely empty if no ports connected yet)
- Baud rate: 9600
- Connect/Disconnect buttons (disabled until port selected)
- Status: "⚫ Disconnected" (red circle)
- State: "State: IDLE"
- Command buttons (disabled until connected)
- Empty log panel

---

## Using the GUI

### 1. Connect to Embedded System

#### Before Connecting
1. Plug in the USB-to-RS422 adapter
2. Open Windows Device Manager (devmgmt.msc)
3. Check "Ports (COM & LPT)" — note the COM port number (e.g., COM3)

#### In the Application
1. **Click "Refresh"** (if implemented) or wait 1 second
   - The "COM 1" dropdown should update with available ports
2. **Select the port** from the dropdown (e.g., "COM3")
3. **Baud rate** is pre-set to 9600 (do not change unless your system uses 115200)
4. **Click "CONNECT"**

**Expected in log:**
```
14:32:05 [INFO] Connecting to COM3 @ 9600...
14:32:06 [INFO] Connected to COM3 @ 9600 baud
14:32:06 [INFO] State changed to IDLE
```

**Status indicator:** Changes to "🟢 Connected (COM3 @ 9600)"

---

### 2. Send Commands (Once Connected)

All buttons are now enabled. Commands are organized by function:

#### **Measure Mode**
```
┌─ MEASURE COMMANDS ──────┐
│ [Enter Measure Mode]    │  ← Enters MEASURING state
│ [Stop Measure]          │  ← Exits to IDLE (only valid in MEASURING)
│ [Transmit Last M]       │  ← Requests last measured velocity
└─────────────────────────┘
```

**Example Workflow:**
```
1. Click "Enter Measure Mode"
   Log: [SEND] MEASURE (code 103)
   Log: [RAW] TX: 41 42 03 67 96
   Waits 2 seconds for response...

2. Embedded system responds with ACK
   Log: [RAW] RX: 41 42 04 FE 67 97
   Log: [ACK] Acknowledged (code 103)
   Log: [INFO] State changed to MEASURING

3. All buttons disable except "Stop Measure"

4. Click "Transmit Last M" (while measuring or after)
   Log: [SEND] TXMT_LAST_V (code 105)
   Log: [RAW] TX: 41 42 02 69 95
   Waits 2 seconds...

5. Embedded system responds with velocity
   Log: [RAW] RX: 41 42 06 C8 40 1F D3
   Log: [RECV] LAST_V: 500.0 m/s (raw=8000)

6. Click "Stop Measure"
   State returns to IDLE
```

#### **Set Expected Velocity**
1. Click "Expected Value"
2. Dialog opens: "Enter Expected Velocity (m/s)"
3. Type a value between 150–1500 (e.g., 500)
4. Click OK

**Expected in log:**
```
14:32:15 [SEND] EXPECTED_V = 500 (code 102)
14:32:15 [RAW] TX: 41 42 05 66 F4 01 A0
14:32:16 [RAW] RX: 41 42 04 FE 66 99
14:32:16 [ACK] Acknowledged (code 102)
```

#### **System Test Mode**
```
┌─ SYSTEM TEST COMMANDS ──┐
│ [Enter System Test]     │  ← Enters SYSTEM_TEST state
│ [Perform System Test]   │  ← Runs internal diagnostics (~5s)
│ [Exit System Test]      │  ← Returns to IDLE
└─────────────────────────┘
```

**Example:**
```
1. Click "Enter System Test Mode"
   State → SYSTEM_TEST (only Perform & Exit enabled)

2. Click "Perform System Test"
   Log: [SEND] PERFORM_SYSTEM_TEST (code 109)
   Waits 5 seconds for completion (not 2!)

3. Embedded system completes internal tests
   Log: [RAW] RX: 41 42 05 D4 00 00 27
   Log: [RECV] SYSTEM TEST: ALL PASSED (flags=0x0000)
   
   OR if there are failures:
   Log: [ERROR] SYSTEM TEST: FAILURES DETECTED (flags=0x0001)
   Log: [ERROR]   - RAM failure

4. Click "Exit System Test Mode"
   State → IDLE
```

#### **Request Parameters**
```
Click "Transmit Parameters"
   Log: [SEND] TXMT_PARAMS (request parameters)
   Waits 2 seconds...
   
Embedded system responds:
   Log: [RECV] PARAMS: Expected V=500, Mount=Bracket, X=0.00m, Y=0.00m, Z=0.00m
```

#### **MVP Test** (Minimum Viable Product test)
```
Click "Perform MVP Test"
   Sends PERFORM_MVP_TEST command
   Waits 2 seconds for SYSTEM_TEST_RESULTS response
   
Embedded system responds:
   Log: [RECV] SYSTEM TEST: ALL PASSED (flags=0x0000)
```

---

### 3. Disconnect

1. Click "DISCONNECT"
2. Port closes, all buttons disable
3. Status: "⚫ Disconnected"

**Log:**
```
14:32:30 [INFO] Disconnected
```

---

## Testing & Debugging

### Simulating Responses (No Embedded System)

If you don't have the embedded system connected yet, you can test by **manually sending bytes** over the COM port using a terminal program.

#### Using **PuTTY Serial Terminal**

1. Download PuTTY (putty.org)
2. Open two PuTTY windows (one for each direction)

**Window 1 (Listen on COM3):**
- Connection type: Serial
- Serial line: COM3
- Speed: 9600
- Click "Open"
- This window receives bytes the app sends

**Window 2 (Send test responses):**
- Connection type: Serial
- Serial line: COM3
- Speed: 9600
- Click "Open"
- This window sends test responses

**Test: Send ACK for MEASURE command**

1. In the GUI app, click "Enter Measure Mode"
   - Window 1 shows: `41 42 03 67 96` (the command)

2. In Window 2, type the ACK response manually:
   ```
   41 42 04 FE 67 97
   ```
   (Copy-paste the hex bytes)

3. The GUI app receives it, decodes it, and logs:
   ```
   [RAW] RX: 41 42 04 FE 67 97
   [ACK] Acknowledged (code 103)
   [INFO] State changed to MEASURING
   ```

This confirms the parser, message decode, and state machine are working.

### Viewing Raw Hex Traffic

The log panel always shows `[RAW]` lines for every byte sent and received. Use this to verify the protocol frames match the spec exactly.

### Common Test Scenarios

**Scenario 1: Test Checksum Validation**
- Send a command with invalid checksum
- Expected: `[ERROR] Checksum validation failed`
- App does NOT decode the message, stays in WAIT_HEADER_1 state

**Scenario 2: Test Response Timeout**
- Send a command
- Do NOT send a response within 2 seconds
- Expected: `[ERROR] TIMEOUT: No response to MEASURE (code 103) after 2.0s`

**Scenario 3: Test Mode Restrictions**
- Enter MEASURING mode
- Try to click "Expected Value" or other commands
- Expected: Button is disabled (grayed out)
- If you somehow send the command anyway:
  - `[NACK] Command rejected (wrong mode)`

---

## Troubleshooting

### Build Issues

#### Error: "cmake: command not found"
**Solution:** Add CMake to PATH
```powershell
$env:Path += ";C:\Qt\6.9.2\Tools\CMake\bin"
```

#### Error: "g++: command not found"
**Solution:** Add MinGW to PATH
```powershell
$env:Path += ";C:\Qt\6.9.2\mingw_64\bin"
```

#### Error: "Cannot find Qt6"
**Solution:** Verify CMAKE_PREFIX_PATH
```powershell
# Check Qt installation
dir "C:\Qt\6.9.2\mingw_64\lib\cmake\Qt6"
# Should return Q6CoreConfig.cmake, Qt6GuiConfig.cmake, etc.

# If not found, your Qt installation path is different
# Find it and update CMakeLists.txt or use correct path in cmake command
```

#### Error: "unknown type name 'QSerialPort'"
**Solution:** Qt Serial Port module not installed
- Open Qt Online Installer
- Go to "Maintenance Tool"
- Add "Qt Serial Port" to your Qt 6.9.2 installation

---

### Runtime Issues

#### "No ports found" in dropdown
**Solution:** 
1. Check Windows Device Manager (devmgmt.msc)
2. Verify USB adapter driver is installed
3. Try a different USB port
4. Restart the application

#### "Failed to open COM3: Access denied"
**Solution:** 
- The port is already in use by another application
- Close PuTTY, Arduino IDE, or other serial terminals
- Try again

#### "Connection established but no response to commands"
**Possible causes:**
1. Baud rate mismatch (should be 9600)
2. Hardware not powered on
3. RS-422 cable disconnected
4. Wrong COM port selected
5. Embedded system in different state than expected

**Debug steps:**
1. Check raw hex in log panel — do you see TX bytes?
2. Verify embedded system is powered and running
3. Test with PuTTY — can you manually send/receive bytes?

#### Application crashes on button click
**Solution:**
1. Check Windows Event Viewer (eventvwr.exe) for error details
2. Make sure port is connected before clicking commands
3. Check for nullptr exceptions (e.g., if serialcomm initialization failed)

---

## File Reference

### Key Files Explained

| File | Purpose | Lines |
|------|---------|-------|
| **protocol.h** | All constants (codes, timeouts, ranges) | 200+ |
| **messagebuilder.h/cpp** | Encode 11 command types to QByteArray | 150+/300+ |
| **messageparser.h/cpp** | Byte-by-byte state machine, checksum validation | 180+/400+ |
| **serialcomm.h/cpp** | QSerialPort wrapper, timeout timer, signal forwarding | 100+/250+ |
| **expectedvdialog.h/cpp** | Expected velocity input dialog, range validation | 50+/100+ |
| **mainwindow.h/cpp** | GUI controller, button handlers, state machine, logging | 200+/900+ |
| **main.cpp** | Application entry point | 10 |
| **CMakeLists.txt** | Build configuration | 50 |

---

## Next Steps

### If Build Fails
1. Post the exact error message
2. Include output of `cmake --version`, `g++ --version`
3. Include output of build command with full path expansion

### If Runtime Fails
1. Check log messages carefully — they're descriptive
2. Test with PuTTY to isolate GUI vs. serial issues
3. Verify embedded system is responding to commands

### Customization
1. **Change log colors:** Edit COLOR_* in mainwindow.cpp
2. **Change timeout values:** Edit `protocol.h` (TIMEOUT_RESPONSE_MS, TIMEOUT_SYSTEM_TEST_MS)
3. **Add new commands:** Follow messagebuilder pattern for new buildXxx() function
4. **Add new response handler:** Follow mainwindow pattern for handleXxx() slot

---

## Support

**For issues during build:** Include CMake output, compiler version, Qt path
**For runtime issues:** Include log panel content from the GUI
**For protocol issues:** Compare raw hex in log to Interface Specification Document

Good luck! 🚀
