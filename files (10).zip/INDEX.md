# VELOCITY RADAR GUI — Complete Project Index

## 📦 What You've Received

A complete, production-ready Qt 6.9.2 GUI application for communicating with a Doppler velocity radar embedded system over RS-422 serial.

**Total delivery:** 16 files
- 13 source code files (C++/CMake)
- 3 documentation files

---

## 📖 Documentation — Start Here!

### 1. **QUICK_START.md** ⭐ START HERE
- **Read time:** 5 minutes
- **Format:** Checklist with copy-paste commands
- **Contains:**
  - Pre-build verification checklist
  - Build command (one-liner)
  - First-run checklist
  - Common troubleshooting (quick)
  - Test scenarios
  
**👉 Read this first if you want to build immediately.**

### 2. **COMPLETE_GUIDE.md**
- **Read time:** 20 minutes (or reference as needed)
- **Format:** Step-by-step instructions with detailed explanations
- **Contains:**
  - Detailed requirements (hardware + software)
  - Project directory layout (every file)
  - Build setup (Windows PowerShell + VS Code)
  - Running the application
  - Complete GUI usage walkthrough
  - Testing without embedded system
  - Extensive troubleshooting
  - File reference table

**👉 Read this if you need detailed explanations or hit issues.**

### 3. **PROJECT_SUMMARY.md**
- **Read time:** 10 minutes
- **Format:** Executive summary + technical overview
- **Contains:**
  - What was built (5 layers)
  - Architecture diagram
  - Feature list
  - Code statistics
  - Testing verification
  - Data flow example
  - Quality highlights

**👉 Read this to understand the architecture and design decisions.**

---

## 💻 Source Code Files

### Layer 1: Protocol Definition
```
protocol.h (200+ lines)
├── Message codes (11 commands + 5 responses)
├── Timing constants (2s, 5s, 1s)
├── Data ranges (V: 150–1500, XYZ: 0–160)
├── System test bit flags
└── Helper functions (commandName, responseTimeout, etc.)
```
**Dependency:** Qt Core only

---

### Layer 2: Message Builder
```
messagebuilder.h (80+ lines)
messagebuilder.cpp (300+ lines)
├── buildExpectedV(uint16_t)
├── buildMeasure()
├── buildStopMeasure()
├── buildTxmtLastV()
├── buildParallax(uint8_t, uint8_t, uint8_t, uint8_t)
├── buildTxmtParams()
├── buildEnterSystemTest()
├── buildPerformSystemTest()
├── buildExitSystemTest()
├── buildPerformMVPTest()
└── buildTxmtMVPTestResults()

Private helpers:
├── computeChecksum() — Two's complement
└── buildFrame() — Wraps payload with headers
```
**Dependency:** protocol.h, Qt Core

---

### Layer 3: Message Parser
```
messageparser.h (180+ lines)
messageparser.cpp (400+ lines)

State Machine:
├── WAIT_HEADER_1 — Scanning for 'A' (0x41)
├── WAIT_HEADER_2 — Looking for 'B' (0x42)
├── WAIT_SIZE — Capturing size byte
└── COLLECTING — Accumulating (SIZE-1) bytes

Signals emitted:
├── messageReceived(ParsedMessage) — Full, valid message
└── parseError(QString) — Bad checksum, invalid size, etc.

Decode functions (static):
├── decodeAck() → AckData
├── decodeNack() → NackData
├── decodeLastV() → LastVData
├── decodeParams() → ParamsData
└── decodeSystemTestResults() → SystemTestData
```
**Dependency:** protocol.h, Qt Core

---

### Layer 4: Serial Communication
```
serialcomm.h (100+ lines)
serialcomm.cpp (250+ lines)

Public interface:
├── openPort(QString portName, int baudRate) → bool
├── closePort()
├── isOpen() → bool
├── sendMessage(QByteArray msg, uint8_t code)
└── availablePorts() → QStringList (static)

Signals emitted:
├── messageReceived(ParsedMessage)
├── responseTimeout(uint8_t code)
├── portOpened(QString, int)
├── portClosed()
├── portError(QString)
├── rawDataSent(QByteArray)
├── rawDataReceived(QByteArray)
└── parseError(QString)

Internal:
├── QSerialPort (port I/O)
├── MessageParser (byte processing)
├── QTimer (response timeout)
└── State tracking (waiting for response)
```
**Dependency:** protocol.h, messageparser.h, Qt Core, Qt SerialPort

---

### Layer 5: GUI
```
expectedvdialog.h (60+ lines)
expectedvdialog.cpp (100+ lines)
├── Dialog for "Set Expected Velocity"
├── Text input with validation (150–1500)
├── Range hint label
├── OK/Cancel buttons
└── Built programmatically (no .ui file)

mainwindow.h (150+ lines)
mainwindow.cpp (900+ lines)
├── Main application window (inherits QDialog)
├── Button handlers (11 command types)
├── State machine (IDLE ↔ MEASURING ↔ SYSTEM_TEST)
├── Connection control (Connect/Disconnect)
├── Response handlers (ACK, NACK, LAST_V, PARAMS, TEST_RESULTS)
├── Logging system (7 log types, color-coded)
├── Button enable/disable logic
└── Status indicators (connection, state)

Programmatically added widgets:
├── m_connectionStatusLabel (green/red circle + port name)
├── m_systemStateLabel (current state display)
├── m_logWidget (QPlainTextEdit, monospace, 2000 lines)
└── Custom formatting (QTextCharFormat with colors)
```
**Dependency:** protocol.h, serialcomm.h, messagebuilder.h, messageparser.h, Qt Widgets, Qt Core

---

### Build Configuration
```
CMakeLists.txt (50 lines)
├── Qt 6 module finding (Widgets, SerialPort)
├── Auto MOC/UIC/RCC setup
├── Source file list
├── Executable definition
└── Linking configuration
```
**Dependency:** Qt 6.9.2

---

### Application Entry Point
```
main.cpp (10 lines)
├── QApplication creation
├── MainWindow instantiation
└── Event loop execution
```
**Dependency:** mainwindow.h, Qt Widgets

---

### UI Layout
```
src/ui/mainwindow.ui
├── Your existing .ui file (Qt Designer)
├── Layout with your button names
└── Plain text edit for logging
```
**Note:** Expected_v.ui not needed (dialog is programmatic)

---

## 🔄 Data Flow

```
User Input (GUI)
    ↓
Button slot (mainwindow.cpp)
    ↓
MessageBuilder::buildXxx() → QByteArray
    ↓
SerialComm::sendMessage()
    ├→ QSerialPort::write()    [bytes on wire]
    ├→ emit rawDataSent()      [hex logged]
    └→ Start response timer (2s or 5s)
         ↓
    [embedded system processes]
         ↓
    [RS-422 bytes arrive]
         ↓
    QSerialPort::readyRead()
    SerialComm::onReadyRead()
    ├→ emit rawDataReceived()  [hex logged]
    └→ MessageParser::processBytes()
         ├→ Byte-by-byte state machine
         ├→ Checksum validation
         └→ emit messageReceived(ParsedMessage)
              ↓
         SerialComm re-emits
              ↓
         MainWindow::onMessageReceived()
         ├→ Switch on message code
         ├→ MessageParser::decodeXxx() → typed struct
         ├→ log() with colors
         ├→ Update state if needed
         └→ UI updated
```

---

## 🛠️ How to Customize

### Add a New Command
1. Add `CMD_NEW = XXX` constant to `protocol.h`
2. Add `buildNewCommand()` to `messagebuilder.h` & `.cpp` (copy pattern from `buildMeasure`)
3. Add button click handler to `mainwindow.h` & `.cpp` (copy pattern from `onMeasureModeClicked`)
4. Connect button to handler in `setupConnections()`

### Add a New Response Type
1. Add `RSP_NEW = YYY` constant to `protocol.h`
2. Add decode struct and function to `messageparser.h` & `.cpp` (copy pattern from `decodeAck`)
3. Add handler in `mainwindow.cpp::onMessageReceived()` (copy pattern from `handleAck`)
4. Implement `handleNew()` response logic

### Change Log Colors
1. Edit `COLOR_*` constants at top of `mainwindow.cpp`
2. Rebuild

### Change Timeouts
1. Edit `TIMEOUT_*` constants in `protocol.h`
2. Rebuild

---

## 🧪 Testing Quick Reference

| Test | Steps | Expected |
|------|-------|----------|
| **Build** | See QUICK_START.md | VelocityRadar.exe created |
| **Connect** | Select COM, click CONNECT | Status: 🟢 Connected |
| **MEASURE** | Click "Enter Measure Mode" | [ACK] + State: MEASURING |
| **STOP** | Click "Stop Measure" | [ACK] + State: IDLE |
| **LAST_V** | Click "Transmit Last M" | [RECV] LAST_V: XXX m/s |
| **PARAMS** | Click "Transmit Parameters" | [RECV] PARAMS: ... |
| **TEST** | Click "Perform System Test" | [RECV] SYSTEM TEST: ... |
| **Timeout** | Send command, no response | [ERROR] TIMEOUT after 2.0s |
| **Checksum** | Send bad checksum | [ERROR] Checksum validation failed |

---

## 🎓 Learning Resources Included

### Code Comments
Every file has:
- Header comment explaining purpose
- Function comments for complex logic
- Inline comments for protocol details
- Signal/slot documentation

### Documentation
- **QUICK_START.md:** Checklist format, immediate action items
- **COMPLETE_GUIDE.md:** In-depth explanations, step-by-step
- **PROJECT_SUMMARY.md:** Architecture, design decisions, data flow

### Examples
- messagebuilder.cpp: 11 complete command examples
- messageparser.cpp: State machine implementation
- mainwindow.cpp: Button handling, response decoding, logging

---

## 📋 File Placement Checklist

```
velocity_radar/
├── ✅ CMakeLists.txt
├── ✅ QUICK_START.md (read first!)
├── ✅ COMPLETE_GUIDE.md (read if stuck)
├── ✅ PROJECT_SUMMARY.md (read for architecture)
└── src/
    ├── ✅ main.cpp
    ├── ✅ protocol.h
    ├── ✅ messagebuilder.h
    ├── ✅ messagebuilder.cpp
    ├── ✅ messageparser.h
    ├── ✅ messageparser.cpp
    ├── ✅ serialcomm.h
    ├── ✅ serialcomm.cpp
    ├── ✅ expectedvdialog.h
    ├── ✅ expectedvdialog.cpp
    ├── ✅ mainwindow.h
    ├── ✅ mainwindow.cpp
    └── ui/
        └── ✅ mainwindow.ui (your existing file)
```

Total: 16 files (13 source + 3 docs)

---

## ⚡ Quick Start Commands

```powershell
# Copy-paste this entire block to build and run
cd C:\projects\velocity_radar
mkdir build
cd build
cmake .. -G "MinGW Makefiles" -DCMAKE_PREFIX_PATH="C:/Qt/6.9.2/mingw_64"
cmake --build .
.\VelocityRadar.exe
```

---

## 🆘 If Something Goes Wrong

1. **Can't build?**
   - Check PATH includes Qt, MinGW, CMake
   - Run `cmake --version`, `g++ --version`
   - Read COMPLETE_GUIDE.md troubleshooting section

2. **Can't connect?**
   - Check Windows Device Manager (devmgmt.msc)
   - Verify USB adapter is recognized
   - Try different USB port

3. **Command doesn't work?**
   - Check [RAW] hex in log matches spec
   - Verify embedded system is powered on
   - Try with PuTTY first (isolate GUI issue)

4. **Don't understand code?**
   - Start with protocol.h (all constants)
   - Read messagebuilder.cpp (encoding logic)
   - Read mainwindow.cpp (everything tied together)

---

## ✅ What's Ready to Use

- ✅ All 11 commands fully implemented
- ✅ All 5 response types fully implemented
- ✅ State machine ready (IDLE/MEASURING/SYSTEM_TEST)
- ✅ Logging with color coding
- ✅ Connection management
- ✅ Timeout handling
- ✅ Error recovery
- ✅ Build system (CMake)
- ✅ Complete documentation

---

## 🚀 Next Steps

### For Immediate Build (5 minutes)
1. Read **QUICK_START.md**
2. Follow checklist
3. Run the application

### For Understanding (20 minutes)
1. Read **PROJECT_SUMMARY.md** (architecture)
2. Read **COMPLETE_GUIDE.md** (detailed setup)
3. Skim the source code

### For Integration (30 minutes)
1. Review protocol.h (constants)
2. Review messagebuilder.cpp (command encoding)
3. Review mainwindow.cpp (full example)

---

**You're all set. Pick a document above and get started!** 🚀

Questions? Check the relevant guide:
- **Can't build?** → QUICK_START.md or COMPLETE_GUIDE.md
- **How do I...?** → COMPLETE_GUIDE.md
- **How does this work?** → PROJECT_SUMMARY.md
- **Where's the code for X?** → This file (INDEX)
