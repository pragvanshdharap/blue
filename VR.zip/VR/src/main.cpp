#include "mainwindow.h"
#include "messageparser.h"

#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    // Register custom types for queued signal/slot connections
    qRegisterMetaType<ParsedMessage>("ParsedMessage");

    MainWindow w;
    w.show();
    return a.exec();
}
