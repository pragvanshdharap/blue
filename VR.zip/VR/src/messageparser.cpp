#include "messageparser.h"
#include "protocol.h"

/*
 * messageparser.cpp — Layer 3: Response Frame Parser Implementation
 *
 * State machine flow:
 *
 *   WAIT_HEADER_1: scan for 0x41 ('A')
 *       ↓ got 0x41
 *   WAIT_HEADER_2: expect 0x42 ('B')
 *       ↓ got 0x42                    (else: if byte is 0x41 stay, otherwise → WAIT_HEADER_1)
 *   WAIT_SIZE: read SIZE byte
 *       ↓ SIZE >= 2 && SIZE <= 255    (else: → WAIT_HEADER_1)
 *   COLLECTING: read (SIZE - 1) more bytes (CODE + DATA + CHECKSUM)
 *       ↓ all bytes collected
 *   handleCompleteFrame():
 *       - buffer contains [SIZE][CODE][DATA...][CHECKSUM]
 *       - verify: sum of all buffer bytes % 256 == 0
 *       - if valid: decode by CODE, emit messageReceived
 *       - if invalid: emit checksumError
 *       - reset to WAIT_HEADER_1
 *
 * Inter-byte timeout:
 *   - Started when first header byte (0x41) is received
 *   - Restarted on each subsequent byte
 *   - If 1 second passes with no byte → discard partial frame, reset
 */

// ─────────────────────────────────────────────
// Constructor / Destructor
// ─────────────────────────────────────────────

MessageParser::MessageParser(QObject *parent)
    : QObject(parent)
    , m_state(State::WAIT_HEADER_1)
    , m_size(0)
    , m_bytesRemaining(0)
    , m_interByteTimer(new QTimer(this))
{
    m_interByteTimer->setSingleShot(true);
    m_interByteTimer->setInterval(Protocol::Timeout::INTER_BYTE_MS);
    connect(m_interByteTimer, &QTimer::timeout,
            this, &MessageParser::onInterByteTimeout);
}

MessageParser::~MessageParser() = default;

// ─────────────────────────────────────────────
// Public: feed raw bytes
// ─────────────────────────────────────────────

void MessageParser::processBytes(const QByteArray &data)
{
    for (int i = 0; i < data.size(); ++i) {
        processByte(static_cast<uint8_t>(data.at(i)));
    }
}

// ─────────────────────────────────────────────
// Public: reset parser state
// ─────────────────────────────────────────────

void MessageParser::reset()
{
    m_state = State::WAIT_HEADER_1;
    m_size = 0;
    m_bytesRemaining = 0;
    m_buffer.clear();
    m_rawFrame.clear();
    m_interByteTimer->stop();
}

// ─────────────────────────────────────────────
// Private slot: inter-byte timeout expired
// ─────────────────────────────────────────────

void MessageParser::onInterByteTimeout()
{
    // Partial frame received but next byte didn't arrive within 1 second
    // Discard everything and reset
    m_state = State::WAIT_HEADER_1;
    m_size = 0;
    m_bytesRemaining = 0;
    m_buffer.clear();
    m_rawFrame.clear();
    emit frameTimeout();
}

// ─────────────────────────────────────────────
// Private: process one byte through state machine
// ─────────────────────────────────────────────

void MessageParser::processByte(uint8_t byte)
{
    switch (m_state) {

    case State::WAIT_HEADER_1:
        // Scanning for 0x41 ('A')
        if (byte == Protocol::HEADER_1) {
            m_rawFrame.clear();
            m_rawFrame.append(static_cast<char>(byte));
            m_state = State::WAIT_HEADER_2;
            // Start inter-byte timeout
            m_interByteTimer->start();
        }
        // Any other byte: stay in WAIT_HEADER_1 (keep scanning)
        break;

    case State::WAIT_HEADER_2:
        m_interByteTimer->start();  // Restart timeout
        if (byte == Protocol::HEADER_2) {
            // Got complete header 'A','B'
            m_rawFrame.append(static_cast<char>(byte));
            m_state = State::WAIT_SIZE;
        } else if (byte == Protocol::HEADER_1) {
            // Got another 'A' — could be start of a new frame
            // Stay in WAIT_HEADER_2 (treat this 'A' as the new HEADER_1)
            m_rawFrame.clear();
            m_rawFrame.append(static_cast<char>(byte));
        } else {
            // Invalid — not 'B' after 'A', reset
            m_rawFrame.clear();
            m_interByteTimer->stop();
            m_state = State::WAIT_HEADER_1;
        }
        break;

    case State::WAIT_SIZE:
        m_interByteTimer->start();  // Restart timeout
        if (byte >= Protocol::FRAME_SIZE_MIN && byte <= Protocol::FRAME_SIZE_MAX) {
            m_size = byte;
            m_buffer.clear();
            m_buffer.append(static_cast<char>(byte));  // SIZE goes into buffer
            m_rawFrame.append(static_cast<char>(byte));

            // Need (SIZE - 1) more bytes: CODE + DATA + CHECKSUM
            // SIZE includes itself, CODE, data, and checksum
            // After SIZE byte, remaining = CODE(1) + DATA(SIZE-3) + CHECKSUM(1) = SIZE - 1
            m_bytesRemaining = m_size - 1;

            if (m_bytesRemaining <= 0) {
                // SIZE=1 would mean only SIZE+CHECKSUM, no CODE — invalid per spec
                // Minimum valid SIZE=2 (SIZE+CODE+CHECKSUM)
                // But we already checked SIZE >= 2, so bytesRemaining >= 1
                // This branch shouldn't happen, but handle defensively
                m_rawFrame.clear();
                m_buffer.clear();
                m_interByteTimer->stop();
                m_state = State::WAIT_HEADER_1;
            } else {
                m_state = State::COLLECTING;
            }
        } else {
            // Invalid SIZE — reset
            m_rawFrame.clear();
            m_buffer.clear();
            m_interByteTimer->stop();
            m_state = State::WAIT_HEADER_1;
        }
        break;

    case State::COLLECTING:
        m_interByteTimer->start();  // Restart timeout
        m_buffer.append(static_cast<char>(byte));
        m_rawFrame.append(static_cast<char>(byte));
        m_bytesRemaining--;

        if (m_bytesRemaining == 0) {
            // Frame complete — buffer has [SIZE][CODE][DATA...][CHECKSUM]
            m_interByteTimer->stop();
            handleCompleteFrame();
        }
        break;
    }
}

// ─────────────────────────────────────────────
// Private: handle a fully-collected frame
//
// m_buffer = [SIZE][CODE][DATA_0]...[DATA_M][CHECKSUM]
// m_rawFrame = [0x41][0x42][SIZE][CODE][DATA...][CHECKSUM]
//
// Verification: sum of m_buffer bytes % 256 == 0
// ─────────────────────────────────────────────

void MessageParser::handleCompleteFrame()
{
    // Verify checksum over entire buffer (SIZE through CHECKSUM)
    if (!Protocol::verifyChecksum(m_buffer)) {
        emit checksumError(m_rawFrame);
        m_state = State::WAIT_HEADER_1;
        m_buffer.clear();
        m_rawFrame.clear();
        return;
    }

    // Checksum valid — extract payload (SIZE + CODE + DATA, without checksum)
    // m_buffer = [SIZE][CODE][DATA...][CHECKSUM]
    // payload  = [SIZE][CODE][DATA...] (drop last byte)
    QByteArray payload = m_buffer.left(m_buffer.size() - 1);

    // Decode based on CODE byte (second byte of payload, index 1)
    ParsedMessage msg = decodePayload(payload);
    msg.rawFrame = m_rawFrame;

    emit messageReceived(msg);

    // Reset for next frame
    m_state = State::WAIT_HEADER_1;
    m_buffer.clear();
    m_rawFrame.clear();
}

// ─────────────────────────────────────────────
// Private: route payload to correct decoder
//
// payload[0] = SIZE
// payload[1] = CODE
// payload[2..] = DATA (if any)
// ─────────────────────────────────────────────

ParsedMessage MessageParser::decodePayload(const QByteArray &payload)
{
    if (payload.size() < 2) {
        // Shouldn't happen (SIZE >= 2 guarantees at least SIZE+CODE)
        ParsedMessage msg;
        msg.type = ParsedMessage::UNKNOWN;
        return msg;
    }

    uint8_t code = static_cast<uint8_t>(payload.at(1));

    switch (code) {
    case Protocol::Resp::ACK:
        return decodeAck(payload);
    case Protocol::Resp::NACK:
        return decodeNack(payload);
    case Protocol::Resp::LAST_V:
        return decodeLastV(payload);
    case Protocol::Resp::PARAMS:
        return decodeParams(payload);
    case Protocol::Resp::SYSTEM_TEST_RESULTS:
        return decodeSystemTestResults(payload);
    default: {
        ParsedMessage msg;
        msg.type = ParsedMessage::UNKNOWN;
        msg.code = code;
        return msg;
    }
    }
}

// ─────────────────────────────────────────────
// Decoder: ACK (Code 254)
//
// Wire payload: [04][FE][MESSAGE]
//   SIZE = 4
//   CODE = 254 (0xFE)
//   MESSAGE = 1 byte, the CODE of the acknowledged command
//
// Example: ACK for MEASURE → payload [04][FE][67]
// ─────────────────────────────────────────────

ParsedMessage MessageParser::decodeAck(const QByteArray &payload)
{
    ParsedMessage msg;
    msg.type = ParsedMessage::ACK;
    msg.code = Protocol::Resp::ACK;

    if (payload.size() >= 3) {
        msg.ack.acknowledgedCode = static_cast<uint8_t>(payload.at(2));
    } else {
        msg.ack.acknowledgedCode = 0;
    }

    return msg;
}

// ─────────────────────────────────────────────
// Decoder: NACK (Code 255)
//
// Wire payload: [04][FF][MESSAGE]
//   SIZE = 4
//   CODE = 255 (0xFF)
//   MESSAGE = 1 byte, the CODE of the rejected command
//
// Example: NACK for MEASURE → payload [04][FF][67]
// ─────────────────────────────────────────────

ParsedMessage MessageParser::decodeNack(const QByteArray &payload)
{
    ParsedMessage msg;
    msg.type = ParsedMessage::NACK;
    msg.code = Protocol::Resp::NACK;

    if (payload.size() >= 3) {
        msg.nack.rejectedCode = static_cast<uint8_t>(payload.at(2));
    } else {
        msg.nack.rejectedCode = 0;
    }

    return msg;
}

// ─────────────────────────────────────────────
// Decoder: LAST_V (Code 200)
//
// Wire payload: [06][C8][RESULT][V_LO][V_HI]
//   SIZE = 6
//   CODE = 200 (0xC8)
//   RESULT = 0 (OK) or 0xFF (-1 signed = error)
//   V_LO = last_velocity & 0xFF (LSB)
//   V_HI = (last_velocity >> 8) & 0xFF (MSB)
//
// Real velocity = rawVelocity / 16.0 (m/s)
//
// Example: velocity=500 m/s = 8000 raw
//   payload [06][C8][00][40][1F]
//   V_LO=0x40, V_HI=0x1F → 0x1F40 = 8000
//   8000 / 16 = 500 m/s
// ─────────────────────────────────────────────

ParsedMessage MessageParser::decodeLastV(const QByteArray &payload)
{
    ParsedMessage msg;
    msg.type = ParsedMessage::LAST_V;
    msg.code = Protocol::Resp::LAST_V;

    if (payload.size() >= 5) {
        msg.lastV.result = static_cast<uint8_t>(payload.at(2));

        uint8_t vLo = static_cast<uint8_t>(payload.at(3));
        uint8_t vHi = static_cast<uint8_t>(payload.at(4));
        msg.lastV.rawVelocity = static_cast<uint16_t>(vLo) |
                                (static_cast<uint16_t>(vHi) << 8);
        msg.lastV.realVelocityMs = msg.lastV.rawVelocity / Protocol::Range::LAST_V_DIVISOR;
    } else {
        msg.lastV.result = 0xFF;
        msg.lastV.rawVelocity = 0;
        msg.lastV.realVelocityMs = 0.0;
    }

    return msg;
}

// ─────────────────────────────────────────────
// Decoder: PARAMS (Code 201)
//
// Wire payload: [09][C9][EXP_V_LO][EXP_V_HI][TRIPOD][X][Y][Z]
//   SIZE = 9
//   CODE = 201 (0xC9)
//   EXP_V_LO = expected_v & 0xFF (LSB)
//   EXP_V_HI = (expected_v >> 8) & 0xFF (MSB)
//   TRIPOD = 0 (bracket) or 1 (tripod)
//   X, Y, Z = antenna offsets (0–160, wire units)
//
// Example: V=500, bracket → payload [09][C9][F4][01][00][00][00][00]
// ─────────────────────────────────────────────

ParsedMessage MessageParser::decodeParams(const QByteArray &payload)
{
    ParsedMessage msg;
    msg.type = ParsedMessage::PARAMS;
    msg.code = Protocol::Resp::PARAMS;

    if (payload.size() >= 8) {
        uint8_t vLo = static_cast<uint8_t>(payload.at(2));
        uint8_t vHi = static_cast<uint8_t>(payload.at(3));
        msg.params.expectedVelocity = static_cast<uint16_t>(vLo) |
                                      (static_cast<uint16_t>(vHi) << 8);
        msg.params.tripod  = static_cast<uint8_t>(payload.at(4));
        msg.params.offsetX = static_cast<uint8_t>(payload.at(5));
        msg.params.offsetY = static_cast<uint8_t>(payload.at(6));
        msg.params.offsetZ = static_cast<uint8_t>(payload.at(7));
    } else {
        msg.params.expectedVelocity = 0;
        msg.params.tripod = 0;
        msg.params.offsetX = 0;
        msg.params.offsetY = 0;
        msg.params.offsetZ = 0;
    }

    return msg;
}

// ─────────────────────────────────────────────
// Decoder: SYSTEM_TEST_RESULTS (Code 212)
//
// Wire payload: [05][D4][FLAGS_LO][FLAGS_HI]
//   SIZE = 5
//   CODE = 212 (0xD4)
//   FLAGS_LO = test_flags & 0xFF (LSB)
//   FLAGS_HI = (test_flags >> 8) & 0xFF (MSB)
//
// Bit meanings (bit=1 → FAILURE):
//   Bit 0: RAM
//   Bit 1: I/O Ports
//   Bit 2: Synthesizer/Doppler
//   Bit 3: RF Subsystem
//   Bit 4: Accelerometer
//   Bit 5: RF Noise
//   Bits 6–15: spare
//
// FLAGS = 0x0000 → all tests passed
// ─────────────────────────────────────────────

ParsedMessage MessageParser::decodeSystemTestResults(const QByteArray &payload)
{
    ParsedMessage msg;
    msg.type = ParsedMessage::SYSTEM_TEST_RESULTS;
    msg.code = Protocol::Resp::SYSTEM_TEST_RESULTS;

    if (payload.size() >= 4) {
        uint8_t fLo = static_cast<uint8_t>(payload.at(2));
        uint8_t fHi = static_cast<uint8_t>(payload.at(3));
        msg.testResults.flags = static_cast<uint16_t>(fLo) |
                                (static_cast<uint16_t>(fHi) << 8);
        msg.testResults.allPassed = (msg.testResults.flags == 0x0000);
    } else {
        msg.testResults.flags = 0xFFFF;  // Assume all failed on decode error
        msg.testResults.allPassed = false;
    }

    return msg;
}
