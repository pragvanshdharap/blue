#ifndef SERIALCOMM_H
#define SERIALCOMM_H

/*
 * serialcomm.h — Win32-native serial layer with device-presence handshake
 *
 * Uses the Windows serial API (CreateFile / ReadFile / WriteFile on \\.\COMx)
 * directly, so it needs NO Qt6SerialPort module. Links automatically under
 * MinGW (kernel32). Same public interface as before, so mainwindow is unchanged.
 *
 * Connect sequence:
 *   1. openPort() actually opens the COM port. If the port does not exist or is
 *      busy, it emits portError and never reports connected.
 *   2. It then sends a read-only probe (TXMT_PARAMS) and waits up to 2 s.
 *   3. Only when a valid framed reply arrives does it emit portOpened.
 *   4. If nothing valid arrives in 2 s, it closes the port and emits portError.
 *
 * Note on RS-422 / MAX490E: that link has no RTS/CTS modem-control lines, so a
 * classic hardware (RTS/CTS) handshake is not physically available. This is a
 * device-presence handshake at the protocol level, which is the correct
 * equivalent for a 4-wire differential link.
 */

#include <QObject>
#include <QString>
#include <QStringList>
#include <QByteArray>
#include <QTimer>
#include <cstdint>

#include "messageparser.h"

class SerialComm : public QObject
{
    Q_OBJECT

public:
    explicit SerialComm(QObject *parent = nullptr);
    ~SerialComm() override;

    void openPort(const QString &portName);     // opens + runs handshake
    void closePort();
    bool isOpen() const { return m_state == State::Connected; }
    bool isWaitingResponse() const { return m_waitingResponse; }

    void sendCommand(const QByteArray &frame, uint8_t cmdCode);

    static QStringList availablePorts();         // real ports via QueryDosDevice

signals:
    void portOpened(const QString &portName);    // only AFTER handshake succeeds
    void portClosed();
    void portError(const QString &errorString);
    void messageReceived(const ParsedMessage &msg);
    void responseTimeout(uint8_t pendingCmdCode);
    void dataSent(const QByteArray &data);
    void dataReceived(const QByteArray &data);
    void checksumError(const QByteArray &rawFrame);
    void frameTimeout();

private slots:
    void onPoll();                  // poll timer: drain RX buffer
    void onParserMessage(const ParsedMessage &msg);
    void onResponseTimeout();
    void onHandshakeTimeout();

private:
    enum class State { Disconnected, Handshaking, Connected };

    bool configurePort();           // DCB (9600 8N1) + non-blocking timeouts
    bool writeBytes(const QByteArray &data);
    void doClose();                 // stop timers + CloseHandle (no signal)

    void          *m_handle;        // Win32 HANDLE, stored as void* to keep
    // windows.h out of this header
    State          m_state;
    QString        m_portName;
    bool           m_waitingResponse;
    uint8_t        m_pendingCmd;

    MessageParser *m_parser;
    QTimer        *m_pollTimer;
    QTimer        *m_responseTimer;
    QTimer        *m_handshakeTimer;
};

#endif // SERIALCOMM_H
