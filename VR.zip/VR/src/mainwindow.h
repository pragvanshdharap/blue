#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <cstdint>

#include "protocol.h"
#include "serialcomm.h"
#include "messagebuilder.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    // Button handlers
    void onConnectClicked();
    void onDisconnectClicked();
    void onExpectedValueClicked();
    void onParallaxClicked();
    void onTransmitParametersClicked();
    void onEnterMeasureModeClicked();
    void onStopMeasureClicked();
    void onTransmitLastModeClicked();
    void onEnterSystemTestModeClicked();
    void onExitSystemTestModeClicked();
    void onPerformSystemTestClicked();
    void onPerformMVPTestClicked();
    void onTransmitTestResultsClicked();

    // Serial communication handlers
    void onPortOpened(const QString &portName);
    void onPortClosed();
    void onPortError(const QString &errorString);
    void onDataSent(const QByteArray &data);
    void onMessageReceived(const ParsedMessage &msg);
    void onResponseTimeout(uint8_t pendingCmdCode);

private:
    enum class LogColor { Blue, Green, Red, Gray };
    void logMessage(const QString &text, LogColor color);
    void updateButtonStates();
    void populateComPorts();
    bool sendCommand(const QByteArray &frame, uint8_t cmdCode, const QString &cmdName);

    Ui::MainWindow *ui;
    SerialComm *m_serial;
    Protocol::SystemState m_systemState;
    uint8_t m_lastSentCmd;
};

#endif // MAINWINDOW_H
