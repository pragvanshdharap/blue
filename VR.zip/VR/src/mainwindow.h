#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <cstdint>

#include "protocol.h"
#include "serialcomm.h"
#include "messagebuilder.h"
#include "messageparser.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow() override;

private slots:
    // Button handlers
    void onConnectClicked();
    void onDisconnectClicked();
    void onExpectedValueClicked();
    void onParallaxClicked();
    void onTransmitParametersClicked();
    void onEnterMeasureModeClicked();
    void onStopMeasureClicked();
    void onTransmitLastModeClicked();
    void onEnterSystemTestModeClicked();
    void onExitSystemTestModeClicked();
    void onPerformSystemTestClicked();
    void onPerformMVPTestClicked();
    void onTransmitTestResultsClicked();

    // Serial communication handlers
    void onPortOpened(const QString &portName);
    void onPortClosed();
    void onPortError(const QString &errorString);
    void onDataSent(const QByteArray &data);
    void onMessageReceived(const ParsedMessage &msg);
    void onResponseTimeout(uint8_t pendingCmdCode);
    void onBitWindowTimeout();

private:
    enum class LogColor { Blue, Green, Red, Gray };
    void logMessage(const QString &text, LogColor color);
    void updateButtonStates();
    void populateComPorts();
    bool sendCommand(const QByteArray &frame, uint8_t cmdCode, const QString &cmdName);

    // Response dispatch (Change 1)
    void handleAck(const ParsedMessage &msg);
    void handleNack(const ParsedMessage &msg);
    void handleLastV(const ParsedMessage &msg);
    void handleParams(const ParsedMessage &msg);
    void handleTestResults(const ParsedMessage &msg);

    Ui::MainWindow *ui;
    SerialComm *m_serial;
    Protocol::SystemState m_systemState;
    uint8_t m_lastSentCmd;

    // Expected-velocity window tracking (Change 4)
    bool     m_expectedVSet;     // true once a value has been accepted
    uint16_t m_expectedV;        // last expected velocity sent (m/s)
    uint16_t m_pendingExpectedV; // value awaiting ACK before it becomes m_expectedV

    // Power-up BIT window (Change 5)
    class QTimer *m_bitTimer;    // 5 s window after connect to receive BIT
    bool          m_awaitingBit; // true between connect and BIT/timeout
};

#endif // MAINWINDOW_H
