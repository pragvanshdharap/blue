#include "expectedvdialog.h"
#include "protocol.h"

/*
 * expectedvdialog.cpp — Layer 5: Expected Velocity Input Dialog Implementation
 *
 * Simple modal dialog:
 *   - QSpinBox with range 150–1500
 *   - OK / Cancel buttons
 *   - Validates range automatically via QSpinBox min/max
 */

ExpectedVDialog::ExpectedVDialog(QWidget *parent)
    : QDialog(parent)
    , m_spinBox(new QSpinBox(this))
{
    setWindowTitle(QStringLiteral("Set Expected Velocity"));
    setFixedSize(300, 150);

    auto *layout = new QVBoxLayout(this);

    auto *label = new QLabel(
        QStringLiteral("Enter expected velocity (m/s):\nRange: %1 – %2")
            .arg(Protocol::Range::EXPECTED_V_MIN)
            .arg(Protocol::Range::EXPECTED_V_MAX),
        this);
    layout->addWidget(label);

    m_spinBox->setMinimum(Protocol::Range::EXPECTED_V_MIN);
    m_spinBox->setMaximum(Protocol::Range::EXPECTED_V_MAX);
    m_spinBox->setValue(500);           // Sensible default
    m_spinBox->setSuffix(QStringLiteral(" m/s"));
    m_spinBox->setAlignment(Qt::AlignCenter);
    layout->addWidget(m_spinBox);

    auto *buttons = new QDialogButtonBox(
        QDialogButtonBox::Ok | QDialogButtonBox::Cancel, this);
    connect(buttons, &QDialogButtonBox::accepted, this, &QDialog::accept);
    connect(buttons, &QDialogButtonBox::rejected, this, &QDialog::reject);
    layout->addWidget(buttons);

    setLayout(layout);
}

uint16_t ExpectedVDialog::getVelocity() const
{
    return static_cast<uint16_t>(m_spinBox->value());
}
