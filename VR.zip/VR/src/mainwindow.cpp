#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "expectedvdialog.h"

#include <QDateTime>
#include <QStringList>

/*
 * mainwindow.cpp — uses Win32-native SerialComm (real serial + handshake)
 */

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_serial(new SerialComm(this))
    , m_systemState(Protocol::SystemState::IDLE)
    , m_lastSentCmd(0)
{
    ui->setupUi(this);

    // Populate COM port dropdown with dummy ports
    populateComPorts();

    // Make log area read-only
    ui->plainTextEdit->setReadOnly(true);
    ui->plainTextEdit->setMaximumBlockCount(500);

    // ═══════════════════════════════════════════════════════════
    // BUTTON → SLOT CONNECTIONS
    // ═══════════════════════════════════════════════════════════

    connect(ui->CONNECT, &QPushButton::clicked,
            this, &MainWindow::onConnectClicked);

    connect(ui->DISCONNECT, &QPushButton::clicked,
            this, &MainWindow::onDisconnectClicked);

    connect(ui->expectedValue, &QPushButton::clicked,
            this, &MainWindow::onExpectedValueClicked);

    connect(ui->parallax, &QPushButton::clicked,
            this, &MainWindow::onParallaxClicked);

    connect(ui->transmitParameters, &QPushButton::clicked,
            this, &MainWindow::onTransmitParametersClicked);

    connect(ui->enterMeasureMode, &QPushButton::clicked,
            this, &MainWindow::onEnterMeasureModeClicked);

    connect(ui->stopMeasure, &QPushButton::clicked,
            this, &MainWindow::onStopMeasureClicked);

    connect(ui->transmitLastMode, &QPushButton::clicked,
            this, &MainWindow::onTransmitLastModeClicked);

    connect(ui->enterSystemTestMode, &QPushButton::clicked,
            this, &MainWindow::onEnterSystemTestModeClicked);

    connect(ui->exitSystemTestMode, &QPushButton::clicked,
            this, &MainWindow::onExitSystemTestModeClicked);

    connect(ui->performSystemTest, &QPushButton::clicked,
            this, &MainWindow::onPerformSystemTestClicked);

    connect(ui->performMVPTest, &QPushButton::clicked,
            this, &MainWindow::onPerformMVPTestClicked);

    connect(ui->transmitTestResults, &QPushButton::clicked,
            this, &MainWindow::onTransmitTestResultsClicked);

    // ═══════════════════════════════════════════════════════════
    // SERIAL COMM → GUI CONNECTIONS
    // ═══════════════════════════════════════════════════════════

    connect(m_serial, &SerialComm::portOpened,
            this, &MainWindow::onPortOpened);
    connect(m_serial, &SerialComm::portClosed,
            this, &MainWindow::onPortClosed);
    connect(m_serial, &SerialComm::portError,
            this, &MainWindow::onPortError);
    connect(m_serial, &SerialComm::messageReceived,
            this, &MainWindow::onMessageReceived);
    connect(m_serial, &SerialComm::responseTimeout,
            this, &MainWindow::onResponseTimeout);
    connect(m_serial, &SerialComm::dataSent,
            this, &MainWindow::onDataSent);

    updateButtonStates();
    logMessage(QStringLiteral("Velocity Radar ready. Select COM port and click Connect."),
               LogColor::Gray);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::populateComPorts()
{
    ui->COM_PORT->clear();
    const QStringList ports = SerialComm::availablePorts();
    if (ports.isEmpty()) {
        ui->COM_PORT->addItem(QStringLiteral("No ports found"));
        ui->COM_PORT->setEnabled(false);
    } else {
        ui->COM_PORT->addItems(ports);
        ui->COM_PORT->setEnabled(true);
    }
}

void MainWindow::logMessage(const QString &text, LogColor color)
{
    QString timestamp = QDateTime::currentDateTime().toString(
        QStringLiteral("hh:mm:ss.zzz"));

    QString colorHex;
    switch (color) {
    case LogColor::Blue:  colorHex = QStringLiteral("#2196F3"); break;
    case LogColor::Green: colorHex = QStringLiteral("#4CAF50"); break;
    case LogColor::Red:   colorHex = QStringLiteral("#F44336"); break;
    case LogColor::Gray:  colorHex = QStringLiteral("#9E9E9E"); break;
    }

    QString html = QStringLiteral(
                       "<span style='color:%1'>[%2] %3</span>")
                       .arg(colorHex, timestamp, text.toHtmlEscaped());

    ui->plainTextEdit->appendHtml(html);
}

void MainWindow::updateButtonStates()
{
    bool connected = m_serial->isOpen();
    bool waiting   = m_serial->isWaitingResponse();
    bool idle      = (m_systemState == Protocol::SystemState::IDLE);
    bool measuring = (m_systemState == Protocol::SystemState::MEASURING);
    bool testing   = (m_systemState == Protocol::SystemState::SYSTEM_TEST);

    ui->CONNECT->setEnabled(!connected);
    ui->DISCONNECT->setEnabled(connected);
    ui->COM_PORT->setEnabled(!connected);
    ui->BAUD_RATE->setEnabled(!connected);

    bool canSend = connected && !waiting;

    ui->expectedValue->setEnabled(canSend && idle);
    ui->parallax->setEnabled(canSend && idle);
    ui->transmitParameters->setEnabled(canSend && idle);
    ui->enterMeasureMode->setEnabled(canSend && idle);
    ui->enterSystemTestMode->setEnabled(canSend && idle);

    ui->stopMeasure->setEnabled(canSend && measuring);
    ui->transmitLastMode->setEnabled(canSend && measuring);

    ui->performSystemTest->setEnabled(canSend && testing);
    ui->exitSystemTestMode->setEnabled(canSend && testing);
    ui->performMVPTest->setEnabled(canSend && testing);
    ui->transmitTestResults->setEnabled(canSend && testing);
}

bool MainWindow::sendCommand(const QByteArray &frame, uint8_t cmdCode,
                             const QString &cmdName)
{
    if (frame.isEmpty()) {
        logMessage(QStringLiteral("ERROR: Invalid command frame for %1").arg(cmdName),
                   LogColor::Red);
        return false;
    }

    if (!m_serial->isOpen()) {
        logMessage(QStringLiteral("ERROR: Port not connected"), LogColor::Red);
        return false;
    }

    if (m_serial->isWaitingResponse()) {
        logMessage(QStringLiteral("ERROR: Waiting for response to previous command"),
                   LogColor::Red);
        return false;
    }

    m_lastSentCmd = cmdCode;

    m_serial->sendCommand(frame, cmdCode);

    logMessage(QStringLiteral("[SEND] %1 (Code %2)  Hex: %3")
                   .arg(cmdName)
                   .arg(cmdCode)
                   .arg(Protocol::toHexString(frame)),
               LogColor::Blue);

    updateButtonStates();
    return true;
}

// ═══════════════════════════════════════════════════════════
// BUTTON CLICK HANDLERS
// ═══════════════════════════════════════════════════════════

void MainWindow::onConnectClicked()
{
    QString portName = ui->COM_PORT->currentText();
    logMessage(QStringLiteral("Opening %1...").arg(portName), LogColor::Gray);
    m_serial->openPort(portName);
}

void MainWindow::onDisconnectClicked()
{
    m_serial->closePort();
    m_systemState = Protocol::SystemState::IDLE;
    m_lastSentCmd = 0;
}

void MainWindow::onExpectedValueClicked()
{
    if (m_systemState != Protocol::SystemState::IDLE) {
        logMessage(QStringLiteral("ERROR: Must be in IDLE state"),
                   LogColor::Red);
        return;
    }

    ExpectedVDialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        uint16_t velocity = dialog.getVelocity();
        QByteArray frame = MessageBuilder::buildExpectedV(velocity);
        sendCommand(frame, Protocol::Cmd::EXPECTED_V,
                    QStringLiteral("EXPECTED_V (%1 m/s)").arg(velocity));
    }
}

void MainWindow::onParallaxClicked()
{
    logMessage(QStringLiteral("PARALLAX: Not implemented (hardware pending)"),
               LogColor::Gray);
}

void MainWindow::onTransmitParametersClicked()
{
    QByteArray frame = MessageBuilder::buildTxmtParams();
    sendCommand(frame, Protocol::Cmd::TXMT_PARAMS,
                QStringLiteral("TXMT_PARAMS"));
}

void MainWindow::onEnterMeasureModeClicked()
{
    QByteArray frame = MessageBuilder::buildMeasure();
    sendCommand(frame, Protocol::Cmd::MEASURE,
                QStringLiteral("MEASURE"));
}

void MainWindow::onStopMeasureClicked()
{
    QByteArray frame = MessageBuilder::buildStopMeasure();
    sendCommand(frame, Protocol::Cmd::STOP_MEASURE,
                QStringLiteral("STOP_MEASURE"));
}

void MainWindow::onTransmitLastModeClicked()
{
    QByteArray frame = MessageBuilder::buildTxmtLastV();
    sendCommand(frame, Protocol::Cmd::TXMT_LAST_V,
                QStringLiteral("TXMT_LAST_V"));
}

void MainWindow::onEnterSystemTestModeClicked()
{
    QByteArray frame = MessageBuilder::buildEnterSystemTest();
    sendCommand(frame, Protocol::Cmd::ENTER_SYSTEM_TEST,
                QStringLiteral("ENTER_SYSTEM_TEST"));
}

void MainWindow::onExitSystemTestModeClicked()
{
    QByteArray frame = MessageBuilder::buildExitSystemTest();
    sendCommand(frame, Protocol::Cmd::EXIT_SYSTEM_TEST,
                QStringLiteral("EXIT_SYSTEM_TEST"));
}

void MainWindow::onPerformSystemTestClicked()
{
    QByteArray frame = MessageBuilder::buildPerformSystemTest();
    sendCommand(frame, Protocol::Cmd::PERFORM_SYSTEM_TEST,
                QStringLiteral("PERFORM_SYSTEM_TEST (5s timeout)"));
}

void MainWindow::onPerformMVPTestClicked()
{
    QByteArray frame = MessageBuilder::buildPerformMvpTest();
    sendCommand(frame, Protocol::Cmd::PERFORM_MVP_TEST,
                QStringLiteral("PERFORM_MVP_TEST"));
}

void MainWindow::onTransmitTestResultsClicked()
{
    QByteArray frame = MessageBuilder::buildTxmtMvpTestResults();
    sendCommand(frame, Protocol::Cmd::TXMT_MVP_TEST_RESULTS,
                QStringLiteral("TXMT_MVP_TEST_RESULTS"));
}

// ═══════════════════════════════════════════════════════════
// SERIAL COMMUNICATION HANDLERS
// ═══════════════════════════════════════════════════════════

void MainWindow::onPortOpened(const QString &portName)
{
    logMessage(QStringLiteral("Connected to %1").arg(portName),
               LogColor::Green);
    m_systemState = Protocol::SystemState::IDLE;
    updateButtonStates();
}

void MainWindow::onPortClosed()
{
    logMessage(QStringLiteral("Port disconnected"), LogColor::Gray);
    m_systemState = Protocol::SystemState::IDLE;
    m_lastSentCmd = 0;
    updateButtonStates();
}

void MainWindow::onPortError(const QString &errorString)
{
    logMessage(QStringLiteral("SERIAL ERROR: %1").arg(errorString), LogColor::Red);
    updateButtonStates();
}

void MainWindow::onDataSent(const QByteArray &data)
{
    Q_UNUSED(data);
}

void MainWindow::onMessageReceived(const ParsedMessage &msg)
{
    logMessage(QStringLiteral("[RECV] %1 (Code %2)  Hex: %3")
                   .arg(Protocol::responseName(msg.code))
                   .arg(msg.code)
                   .arg(Protocol::toHexString(msg.rawFrame)),
                   LogColor::Green);
    updateButtonStates();
}

void MainWindow::onResponseTimeout(uint8_t pendingCmdCode)
{
    logMessage(QStringLiteral("TIMEOUT: No response for Code %1")
                   .arg(pendingCmdCode),
                   LogColor::Red);
    updateButtonStates();
}
