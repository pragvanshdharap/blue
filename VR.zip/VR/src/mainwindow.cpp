#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "expectedvdialog.h"

#include <QDateTime>
#include <QStringList>
#include <QTimer>

/*
 * mainwindow.cpp — uses Win32-native SerialComm (real serial).
 *
 * Power-up BIT: the VR runs its built-in test autonomously on power-up and
 * sends SYSTEM_TEST_RESULTS unsolicited (~5 s). On connect, the PC opens the
 * port and listens for up to 5 s for that frame, then settles into stand-by
 * (IDLE) regardless. See onPortOpened / onBitWindowTimeout / handleTestResults.
 *
 * Measure window: the PC stores the expected velocity and flags any reported
 * LAST_V outside ±100 m/s as an error. See handleLastV.
 */

static const int BIT_WINDOW_MS        = 5000;  // listen window for power-up BIT
static const int EXPECTED_V_TOLERANCE = 100;   // ± m/s measurement window

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_serial(new SerialComm(this))
    , m_systemState(Protocol::SystemState::IDLE)
    , m_lastSentCmd(0)
    , m_expectedVSet(false)
    , m_expectedV(0)
    , m_pendingExpectedV(0)
    , m_bitTimer(new QTimer(this))
    , m_awaitingBit(false)
{
    ui->setupUi(this);

    m_bitTimer->setSingleShot(true);
    connect(m_bitTimer, &QTimer::timeout, this, &MainWindow::onBitWindowTimeout);

    // Populate COM port dropdown with real ports
    populateComPorts();

    // Make log area read-only
    ui->plainTextEdit->setReadOnly(true);
    ui->plainTextEdit->setMaximumBlockCount(500);

    // ═══════════════════════════════════════════════════════════
    // BUTTON → SLOT CONNECTIONS
    // ═══════════════════════════════════════════════════════════

    connect(ui->CONNECT, &QPushButton::clicked,
            this, &MainWindow::onConnectClicked);

    connect(ui->DISCONNECT, &QPushButton::clicked,
            this, &MainWindow::onDisconnectClicked);

    connect(ui->expectedMV, &QPushButton::clicked,
            this, &MainWindow::onExpectedValueClicked);

    connect(ui->parallax, &QPushButton::clicked,
            this, &MainWindow::onParallaxClicked);

    connect(ui->transmitParameters, &QPushButton::clicked,
            this, &MainWindow::onTransmitParametersClicked);

    connect(ui->enterMeasureMode, &QPushButton::clicked,
            this, &MainWindow::onEnterMeasureModeClicked);

    connect(ui->stopMeasure, &QPushButton::clicked,
            this, &MainWindow::onStopMeasureClicked);

    connect(ui->transmitLastMV, &QPushButton::clicked,
            this, &MainWindow::onTransmitLastModeClicked);

    connect(ui->enterSystemTestMode, &QPushButton::clicked,
            this, &MainWindow::onEnterSystemTestModeClicked);

    connect(ui->exitSystemTestMode, &QPushButton::clicked,
            this, &MainWindow::onExitSystemTestModeClicked);

    connect(ui->performSystemTest, &QPushButton::clicked,
            this, &MainWindow::onPerformSystemTestClicked);

    connect(ui->performMVPTest, &QPushButton::clicked,
            this, &MainWindow::onPerformMVPTestClicked);

    connect(ui->transmitTestResults, &QPushButton::clicked,
            this, &MainWindow::onTransmitTestResultsClicked);

    // ═══════════════════════════════════════════════════════════
    // SERIAL COMM → GUI CONNECTIONS
    // ═══════════════════════════════════════════════════════════

    connect(m_serial, &SerialComm::portOpened,
            this, &MainWindow::onPortOpened);
    connect(m_serial, &SerialComm::portClosed,
            this, &MainWindow::onPortClosed);
    connect(m_serial, &SerialComm::portError,
            this, &MainWindow::onPortError);
    connect(m_serial, &SerialComm::messageReceived,
            this, &MainWindow::onMessageReceived);
    connect(m_serial, &SerialComm::responseTimeout,
            this, &MainWindow::onResponseTimeout);
    connect(m_serial, &SerialComm::dataSent,
            this, &MainWindow::onDataSent);

    updateButtonStates();
    logMessage(QStringLiteral("Velocity Radar ready. Select COM port and click Connect."),
               LogColor::Gray);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::populateComPorts()
{
    ui->COM_PORT->clear();
    const QStringList ports = SerialComm::availablePorts();
    if (ports.isEmpty()) {
        ui->COM_PORT->addItem(QStringLiteral("No ports found"));
        ui->COM_PORT->setEnabled(false);
    } else {
        ui->COM_PORT->addItems(ports);
        ui->COM_PORT->setEnabled(true);
    }
}

void MainWindow::logMessage(const QString &text, LogColor color)
{
    QString timestamp = QDateTime::currentDateTime().toString(
        QStringLiteral("hh:mm:ss.zzz"));

    QString colorHex;
    switch (color) {
    case LogColor::Blue:  colorHex = QStringLiteral("#2196F3"); break;
    case LogColor::Green: colorHex = QStringLiteral("#4CAF50"); break;
    case LogColor::Red:   colorHex = QStringLiteral("#F44336"); break;
    case LogColor::Gray:  colorHex = QStringLiteral("#9E9E9E"); break;
    }

    QString html = QStringLiteral(
                       "<span style='color:%1'>[%2] %3</span>")
                       .arg(colorHex, timestamp, text.toHtmlEscaped());

    ui->plainTextEdit->appendHtml(html);
}

void MainWindow::updateButtonStates()
{
    bool connected = m_serial->isOpen();
    bool waiting   = m_serial->isWaitingResponse();
    bool idle      = (m_systemState == Protocol::SystemState::IDLE);
    bool measuring = (m_systemState == Protocol::SystemState::MEASURING);
    bool testing   = (m_systemState == Protocol::SystemState::SYSTEM_TEST);

    ui->CONNECT->setEnabled(!connected);
    ui->DISCONNECT->setEnabled(connected);
    ui->COM_PORT->setEnabled(!connected);
    ui->BAUD_RATE->setEnabled(!connected);

    // During the power-up BIT window the unit is running its self-test and
    // should not be sent commands, so gate command buttons on !m_awaitingBit.
    bool canSend = connected && !waiting && !m_awaitingBit;

    ui->expectedMV->setEnabled(canSend && idle);
    ui->parallax->setEnabled(canSend && idle);
    ui->transmitParameters->setEnabled(canSend && idle);
    ui->enterMeasureMode->setEnabled(canSend && idle);
    ui->enterSystemTestMode->setEnabled(canSend && idle);

    ui->stopMeasure->setEnabled(canSend && measuring);
    ui->transmitLastMV->setEnabled(canSend && measuring);

    ui->performSystemTest->setEnabled(canSend && testing);
    ui->exitSystemTestMode->setEnabled(canSend && testing);
    ui->performMVPTest->setEnabled(canSend && testing);
    ui->transmitTestResults->setEnabled(canSend && testing);
}

bool MainWindow::sendCommand(const QByteArray &frame, uint8_t cmdCode,
                             const QString &cmdName)
{
    if (frame.isEmpty()) {
        logMessage(QStringLiteral("ERROR: Invalid command frame for %1").arg(cmdName),
                   LogColor::Red);
        return false;
    }

    if (!m_serial->isOpen()) {
        logMessage(QStringLiteral("ERROR: Port not connected"), LogColor::Red);
        return false;
    }

    if (m_serial->isWaitingResponse()) {
        logMessage(QStringLiteral("ERROR: Waiting for response to previous command"),
                   LogColor::Red);
        return false;
    }

    m_lastSentCmd = cmdCode;

    m_serial->sendCommand(frame, cmdCode);

    logMessage(QStringLiteral("[SEND] %1 (Code %2)  Hex: %3")
                   .arg(cmdName)
                   .arg(cmdCode)
                   .arg(Protocol::toHexString(frame)),
               LogColor::Blue);

    updateButtonStates();
    return true;
}

// ═══════════════════════════════════════════════════════════
// BUTTON CLICK HANDLERS
// ═══════════════════════════════════════════════════════════

void MainWindow::onConnectClicked()
{
    QString portName = ui->COM_PORT->currentText();
    if (portName.isEmpty() || portName == QStringLiteral("No ports found")) {
        logMessage(QStringLiteral("ERROR: No valid COM port selected"), LogColor::Red);
        return;
    }
    logMessage(QStringLiteral("Opening %1...").arg(portName), LogColor::Gray);
    m_serial->openPort(portName);
}

void MainWindow::onDisconnectClicked()
{
    m_bitTimer->stop();
    m_awaitingBit = false;
    m_serial->closePort();
    m_systemState = Protocol::SystemState::IDLE;
    m_lastSentCmd = 0;
}

void MainWindow::onExpectedValueClicked()
{
    if (m_systemState != Protocol::SystemState::IDLE) {
        logMessage(QStringLiteral("ERROR: Must be in IDLE state"),
                   LogColor::Red);
        return;
    }

    ExpectedVDialog dialog(this);
    if (dialog.exec() == QDialog::Accepted) {
        uint16_t velocity = dialog.getVelocity();
        QByteArray frame = MessageBuilder::buildExpectedV(velocity);
        // Remember the value but don't commit it until the device ACKs it.
        m_pendingExpectedV = velocity;
        sendCommand(frame, Protocol::Cmd::EXPECTED_V,
                    QStringLiteral("EXPECTED_V (%1 m/s)").arg(velocity));
    }
}

void MainWindow::onParallaxClicked()
{
    logMessage(QStringLiteral("PARALLAX: Not implemented (hardware pending)"),
               LogColor::Gray);
}

void MainWindow::onTransmitParametersClicked()
{
    QByteArray frame = MessageBuilder::buildTxmtParams();
    sendCommand(frame, Protocol::Cmd::TXMT_PARAMS,
                QStringLiteral("TXMT_PARAMS"));
}

void MainWindow::onEnterMeasureModeClicked()
{
    QByteArray frame = MessageBuilder::buildMeasure();
    sendCommand(frame, Protocol::Cmd::MEASURE,
                QStringLiteral("MEASURE"));
}

void MainWindow::onStopMeasureClicked()
{
    QByteArray frame = MessageBuilder::buildStopMeasure();
    sendCommand(frame, Protocol::Cmd::STOP_MEASURE,
                QStringLiteral("STOP_MEASURE"));
}

void MainWindow::onTransmitLastModeClicked()
{
    QByteArray frame = MessageBuilder::buildTxmtLastV();
    sendCommand(frame, Protocol::Cmd::TXMT_LAST_V,
                QStringLiteral("TXMT_LAST_V"));
}

void MainWindow::onEnterSystemTestModeClicked()
{
    QByteArray frame = MessageBuilder::buildEnterSystemTest();
    sendCommand(frame, Protocol::Cmd::ENTER_SYSTEM_TEST,
                QStringLiteral("ENTER_SYSTEM_TEST"));
}

void MainWindow::onExitSystemTestModeClicked()
{
    QByteArray frame = MessageBuilder::buildExitSystemTest();
    sendCommand(frame, Protocol::Cmd::EXIT_SYSTEM_TEST,
                QStringLiteral("EXIT_SYSTEM_TEST"));
}

void MainWindow::onPerformSystemTestClicked()
{
    QByteArray frame = MessageBuilder::buildPerformSystemTest();
    sendCommand(frame, Protocol::Cmd::PERFORM_SYSTEM_TEST,
                QStringLiteral("PERFORM_SYSTEM_TEST (5s timeout)"));
}

void MainWindow::onPerformMVPTestClicked()
{
    QByteArray frame = MessageBuilder::buildPerformMvpTest();
    sendCommand(frame, Protocol::Cmd::PERFORM_MVP_TEST,
                QStringLiteral("PERFORM_MVP_TEST"));
}

void MainWindow::onTransmitTestResultsClicked()
{
    QByteArray frame = MessageBuilder::buildTxmtMvpTestResults();
    sendCommand(frame, Protocol::Cmd::TXMT_MVP_TEST_RESULTS,
                QStringLiteral("TXMT_MVP_TEST_RESULTS"));
}

// ═══════════════════════════════════════════════════════════
// SERIAL COMMUNICATION HANDLERS
// ═══════════════════════════════════════════════════════════

void MainWindow::onPortOpened(const QString &portName)
{
    logMessage(QStringLiteral("Connected to %1 (9600 8N1)").arg(portName),
               LogColor::Green);

    // Power-up BIT window: the VR sends SYSTEM_TEST_RESULTS unsolicited within
    // ~5 s of power-up. If the operator just powered the unit and connected the
    // cable, that frame should arrive now. Open a 5 s listening window before
    // settling into stand-by.
    m_systemState = Protocol::SystemState::IDLE;
    m_awaitingBit = true;
    m_bitTimer->start(BIT_WINDOW_MS);
    logMessage(QStringLiteral("Waiting up to 5 s for power-up self-test (BIT)..."),
               LogColor::Gray);

    updateButtonStates();
}

void MainWindow::onBitWindowTimeout()
{
    // No BIT frame arrived in the window. This is normal if the VR was already
    // powered and past its self-test before the cable was connected.
    if (m_awaitingBit) {
        m_awaitingBit = false;
        logMessage(QStringLiteral(
                       "No power-up self-test received (unit likely already running). "
                       "System in stand-by."), LogColor::Gray);
        updateButtonStates();
    }
}

void MainWindow::onPortClosed()
{
    m_bitTimer->stop();
    m_awaitingBit = false;
    logMessage(QStringLiteral("Port disconnected"), LogColor::Gray);
    m_systemState = Protocol::SystemState::IDLE;
    m_lastSentCmd = 0;
    updateButtonStates();
}

void MainWindow::onPortError(const QString &errorString)
{
    m_bitTimer->stop();
    m_awaitingBit = false;
    logMessage(QStringLiteral("SERIAL ERROR: %1").arg(errorString), LogColor::Red);
    updateButtonStates();
}

void MainWindow::onDataSent(const QByteArray &data)
{
    Q_UNUSED(data);
}

// ─────────────────────────────────────────────────────────────
// Response dispatch (Change 1)
// ─────────────────────────────────────────────────────────────

void MainWindow::onMessageReceived(const ParsedMessage &msg)
{
    logMessage(QStringLiteral("[RECV] %1 (Code %2)  Hex: %3")
                   .arg(Protocol::responseName(msg.code))
                   .arg(msg.code)
                   .arg(Protocol::toHexString(msg.rawFrame)),
                   LogColor::Green);

    switch (msg.type) {
    case ParsedMessage::ACK:                 handleAck(msg);         break;
    case ParsedMessage::NACK:                handleNack(msg);        break;
    case ParsedMessage::LAST_V:              handleLastV(msg);       break;
    case ParsedMessage::PARAMS:              handleParams(msg);      break;
    case ParsedMessage::SYSTEM_TEST_RESULTS: handleTestResults(msg); break;
    case ParsedMessage::UNKNOWN:
        logMessage(QStringLiteral("  WARNING: unknown response code %1").arg(msg.code),
                   LogColor::Red);
        break;
    }

    updateButtonStates();
}

void MainWindow::onResponseTimeout(uint8_t pendingCmdCode)
{
    logMessage(QStringLiteral("TIMEOUT: No response for %1 (Code %2)")
                   .arg(Protocol::commandName(pendingCmdCode))
                   .arg(pendingCmdCode),
                   LogColor::Red);
    updateButtonStates();
}

// ─────────────────────────────────────────────────────────────
// Typed response handlers
// ─────────────────────────────────────────────────────────────

void MainWindow::handleAck(const ParsedMessage &msg)
{
    const uint8_t acked = msg.ack.acknowledgedCode;
    logMessage(QStringLiteral("  ACK for %1 (Code %2)")
                   .arg(Protocol::commandName(acked)).arg(acked),
               LogColor::Green);

    switch (acked) {
    case Protocol::Cmd::MEASURE:
        m_systemState = Protocol::SystemState::MEASURING;
        logMessage(QStringLiteral("  State -> MEASURING"), LogColor::Green);
        break;
    case Protocol::Cmd::STOP_MEASURE:
        m_systemState = Protocol::SystemState::IDLE;
        logMessage(QStringLiteral("  State -> IDLE (stand-by)"), LogColor::Green);
        break;
    case Protocol::Cmd::ENTER_SYSTEM_TEST:
        m_systemState = Protocol::SystemState::SYSTEM_TEST;
        logMessage(QStringLiteral("  State -> SYSTEM_TEST"), LogColor::Green);
        break;
    case Protocol::Cmd::EXIT_SYSTEM_TEST:
        m_systemState = Protocol::SystemState::IDLE;
        logMessage(QStringLiteral("  State -> IDLE (stand-by)"), LogColor::Green);
        break;
    case Protocol::Cmd::EXPECTED_V:
        // Device accepted the expected velocity: commit it for the ±window check.
        m_expectedV    = m_pendingExpectedV;
        m_expectedVSet = true;
        logMessage(QStringLiteral(
                       "  Measurement window set: %1 +/- %2 m/s  (%3 to %4)")
                       .arg(m_expectedV)
                       .arg(EXPECTED_V_TOLERANCE)
                       .arg(int(m_expectedV) - EXPECTED_V_TOLERANCE)
                       .arg(int(m_expectedV) + EXPECTED_V_TOLERANCE),
                   LogColor::Green);
        break;
    default:
        break;
    }
}

void MainWindow::handleNack(const ParsedMessage &msg)
{
    const uint8_t rejected = msg.nack.rejectedCode;
    logMessage(QStringLiteral("  NACK: %1 (Code %2) rejected by VR")
                   .arg(Protocol::commandName(rejected)).arg(rejected),
               LogColor::Red);
}

void MainWindow::handleLastV(const ParsedMessage &msg)
{
    if (msg.lastV.result != Protocol::MeasResult::OK) {
        logMessage(QStringLiteral("  Measurement ERROR reported by VR (result=0x%1)")
                       .arg(msg.lastV.result, 2, 16, QLatin1Char('0')),
                       LogColor::Red);
        return;
    }

    const double v = msg.lastV.realVelocityMs;
    logMessage(QStringLiteral("  Velocity: %1 m/s (raw %2)")
                   .arg(v, 0, 'f', 1).arg(msg.lastV.rawVelocity),
               LogColor::Green);

    // ±100 m/s measurement-window check (Change 4). The protocol has no
    // dedicated out-of-range response code, so the PC enforces the window.
    if (m_expectedVSet) {
        const double lo = double(m_expectedV) - EXPECTED_V_TOLERANCE;
        const double hi = double(m_expectedV) + EXPECTED_V_TOLERANCE;
        if (v < lo || v > hi) {
            logMessage(QStringLiteral(
                           "  ERROR: %1 m/s is outside expected window %2 to %3 m/s")
                           .arg(v, 0, 'f', 1).arg(lo, 0, 'f', 0).arg(hi, 0, 'f', 0),
                       LogColor::Red);
        } else {
            logMessage(QStringLiteral("  Within expected window (%1 to %2 m/s)")
                           .arg(lo, 0, 'f', 0).arg(hi, 0, 'f', 0),
                           LogColor::Green);
        }
    } else {
        logMessage(QStringLiteral(
                       "  Note: no EXPECTED_V set, skipping window check"), LogColor::Gray);
    }
}

void MainWindow::handleParams(const ParsedMessage &msg)
{
    logMessage(QStringLiteral("  Expected V: %1 m/s").arg(msg.params.expectedVelocity),
               LogColor::Green);
    logMessage(QStringLiteral("  Tripod: %1   Offsets X=%2 Y=%3 Z=%4")
                   .arg(msg.params.tripod ? QStringLiteral("yes") : QStringLiteral("no"))
                   .arg(msg.params.offsetX).arg(msg.params.offsetY).arg(msg.params.offsetZ),
               LogColor::Green);
}

void MainWindow::handleTestResults(const ParsedMessage &msg)
{
    // This frame is either the unsolicited power-up BIT, or a reply to a
    // user-triggered PERFORM_SYSTEM_TEST. Either way, decode and show it.
    if (m_awaitingBit) {
        m_awaitingBit = false;
        m_bitTimer->stop();
        logMessage(QStringLiteral("  Power-up self-test (BIT) results received:"),
                   LogColor::Green);
    } else {
        logMessage(QStringLiteral("  System test results:"), LogColor::Green);
    }

    if (msg.testResults.allPassed) {
        logMessage(QStringLiteral("  ALL SUBSYSTEMS PASSED (flags=0x0000)"),
                   LogColor::Green);
    } else {
        logMessage(QStringLiteral("  FAILURES DETECTED (flags=0x%1)")
                       .arg(msg.testResults.flags, 4, 16, QLatin1Char('0')),
                       LogColor::Red);
    }

    const QStringList lines = Protocol::decodeTestFlags(msg.testResults.flags);
    for (const QString &line : lines) {
        const LogColor c = line.contains(QStringLiteral("FAIL"))
        ? LogColor::Red : LogColor::Green;
        logMessage(QStringLiteral("    %1").arg(line), c);
    }

    logMessage(QStringLiteral("  System in stand-by, ready for commands."),
               LogColor::Gray);
}
