#ifndef PROTOCOL_H
#define PROTOCOL_H

/*
 * protocol.h — Layer 1: Velocity Radar Protocol Constants
 *
 * Single source of truth for:
 *   - Frame format (Header bytes, SIZE/CODE/DATA/CHECKSUM layout)
 *   - Command codes (PC → System, 102–112)
 *   - Response codes (System → PC, 200/201/212/254/255)
 *   - Timeout values
 *   - Data ranges & validation
 *   - System test flag bit definitions
 *   - Helper/utility functions
 *
 * Reference: VELOCITY_RADAR_COMPLETE_CONTEXT.md v1.0
 */

#include <cstdint>
#include <QString>
#include <QStringList>
#include <QByteArray>

namespace Protocol {

// ─────────────────────────────────────────────
// Frame Header
// ─────────────────────────────────────────────
constexpr uint8_t HEADER_1 = 0x41;  // 'A'
constexpr uint8_t HEADER_2 = 0x42;  // 'B'

// ─────────────────────────────────────────────
// SIZE field rules
//   SIZE = 1(SIZE) + 1(CODE) + M(data bytes) + 1(CHECKSUM)
//   Minimum SIZE = 2 (no data: SIZE + CODE + CHECKSUM)
//   Maximum SIZE = 255
// ─────────────────────────────────────────────
constexpr uint8_t FRAME_SIZE_MIN = 2;
constexpr uint8_t FRAME_SIZE_MAX = 255;

// ─────────────────────────────────────────────
// Command Codes (PC → System)
// ─────────────────────────────────────────────
namespace Cmd {
    constexpr uint8_t EXPECTED_V           = 102;  // Set expected velocity (150–1500)
    constexpr uint8_t MEASURE              = 103;  // Enter measure mode
    constexpr uint8_t STOP_MEASURE         = 104;  // Exit measure mode
    constexpr uint8_t TXMT_LAST_V          = 105;  // Request last measured velocity
    constexpr uint8_t PARALLAX             = 106;  // Set antenna offset
    constexpr uint8_t TXMT_PARAMS          = 107;  // Request current parameters
    constexpr uint8_t ENTER_SYSTEM_TEST    = 108;  // Enter system test mode
    constexpr uint8_t PERFORM_SYSTEM_TEST  = 109;  // Run system diagnostics
    constexpr uint8_t EXIT_SYSTEM_TEST     = 110;  // Exit system test mode
    constexpr uint8_t PERFORM_MVP_TEST     = 111;  // Run MVP internal test
    constexpr uint8_t TXMT_MVP_TEST_RESULTS = 112; // Request MVP test results
}

// ─────────────────────────────────────────────
// Response Codes (System → PC)
// ─────────────────────────────────────────────
namespace Resp {
    constexpr uint8_t LAST_V               = 200;  // Last measured velocity
    constexpr uint8_t PARAMS               = 201;  // Current parameters
    constexpr uint8_t SYSTEM_TEST_RESULTS  = 212;  // Test pass/fail flags
    constexpr uint8_t ACK                  = 254;  // Acknowledge
    constexpr uint8_t NACK                 = 255;  // Not acknowledge
}

// ─────────────────────────────────────────────
// Expected SIZE values for each message
// SIZE = 1(SIZE) + 1(CODE) + M(data) + 1(CHECKSUM)
// ─────────────────────────────────────────────
namespace Size {
    // Commands
    constexpr uint8_t EXPECTED_V           = 5;   // SIZE+CODE + 2 data + CHK
    constexpr uint8_t MEASURE              = 3;   // SIZE+CODE + 0 data + CHK
    constexpr uint8_t STOP_MEASURE         = 3;
    constexpr uint8_t TXMT_LAST_V          = 2;   // Minimal: SIZE+CODE+CHK only
    constexpr uint8_t PARALLAX             = 7;   // SIZE+CODE + 4 data + CHK
    constexpr uint8_t TXMT_PARAMS          = 3;
    constexpr uint8_t ENTER_SYSTEM_TEST    = 3;
    constexpr uint8_t PERFORM_SYSTEM_TEST  = 3;
    constexpr uint8_t EXIT_SYSTEM_TEST     = 3;
    constexpr uint8_t PERFORM_MVP_TEST     = 3;
    constexpr uint8_t TXMT_MVP_TEST_RESULTS = 3;

    // Responses
    constexpr uint8_t LAST_V               = 6;   // SIZE+CODE + 3 data + CHK
    constexpr uint8_t PARAMS               = 9;   // SIZE+CODE + 6 data + CHK
    constexpr uint8_t SYSTEM_TEST_RESULTS  = 5;   // SIZE+CODE + 2 data + CHK
    constexpr uint8_t ACK                  = 4;   // SIZE+CODE + 1 data + CHK
    constexpr uint8_t NACK                 = 4;
}

// ─────────────────────────────────────────────
// Timeouts (milliseconds)
// ─────────────────────────────────────────────
namespace Timeout {
    constexpr int RESPONSE_MS         = 2000;  // Standard: 2 seconds
    constexpr int SYSTEM_TEST_MS      = 5000;  // PERFORM_SYSTEM_TEST: 5 seconds
    constexpr int INTER_BYTE_MS       = 1000;  // Max gap between bytes in a frame
}

// ─────────────────────────────────────────────
// Data Ranges
// ─────────────────────────────────────────────
namespace Range {
    constexpr uint16_t EXPECTED_V_MIN      = 150;
    constexpr uint16_t EXPECTED_V_MAX      = 1500;
    constexpr uint16_t LAST_V_RAW_MAX      = 24000;
    constexpr double   LAST_V_DIVISOR      = 16.0;   // raw / 16 = real m/s
    constexpr uint8_t  PARALLAX_OFFSET_MAX = 160;
    constexpr double   PARALLAX_MULTIPLIER = 16.0;    // wire × 16 = real meters
}

// ─────────────────────────────────────────────
// LAST_V result byte
// ─────────────────────────────────────────────
namespace MeasResult {
    constexpr uint8_t OK    = 0x00;   // Measurement successful
    constexpr uint8_t ERROR = 0xFF;   // -1 signed = 0xFF unsigned
}

// ─────────────────────────────────────────────
// System Test Flag Bits (bit=1 means FAILURE)
// ─────────────────────────────────────────────
namespace TestFlag {
    constexpr uint16_t RAM          = (1 << 0);  // Bit 0
    constexpr uint16_t IO_PORTS     = (1 << 1);  // Bit 1
    constexpr uint16_t SYNTHESIZER  = (1 << 2);  // Bit 2
    constexpr uint16_t RF           = (1 << 3);  // Bit 3
    constexpr uint16_t ACCELEROMETER = (1 << 4); // Bit 4
    constexpr uint16_t RF_NOISE     = (1 << 5);  // Bit 5
    // Bits 6–15: spare (should be 0)

    constexpr int NUM_DEFINED = 6;

    // Human-readable names indexed by bit position
    inline QString bitName(int bit) {
        switch (bit) {
            case 0: return QStringLiteral("RAM");
            case 1: return QStringLiteral("I/O Ports");
            case 2: return QStringLiteral("Synthesizer/Doppler");
            case 3: return QStringLiteral("RF Subsystem");
            case 4: return QStringLiteral("Accelerometer");
            case 5: return QStringLiteral("RF Noise");
            default: return QStringLiteral("Spare (bit %1)").arg(bit);
        }
    }
}

// ─────────────────────────────────────────────
// System States
// ─────────────────────────────────────────────
enum class SystemState {
    IDLE,
    MEASURING,
    SYSTEM_TEST
};

inline QString systemStateName(SystemState s) {
    switch (s) {
        case SystemState::IDLE:        return QStringLiteral("IDLE");
        case SystemState::MEASURING:   return QStringLiteral("MEASURING");
        case SystemState::SYSTEM_TEST: return QStringLiteral("SYSTEM_TEST");
    }
    return QStringLiteral("UNKNOWN");
}

// ─────────────────────────────────────────────
// Helper: Command name from code
// ─────────────────────────────────────────────
inline QString commandName(uint8_t code) {
    switch (code) {
        case Cmd::EXPECTED_V:            return QStringLiteral("EXPECTED_V");
        case Cmd::MEASURE:               return QStringLiteral("MEASURE");
        case Cmd::STOP_MEASURE:          return QStringLiteral("STOP_MEASURE");
        case Cmd::TXMT_LAST_V:           return QStringLiteral("TXMT_LAST_V");
        case Cmd::PARALLAX:              return QStringLiteral("PARALLAX");
        case Cmd::TXMT_PARAMS:           return QStringLiteral("TXMT_PARAMS");
        case Cmd::ENTER_SYSTEM_TEST:     return QStringLiteral("ENTER_SYSTEM_TEST");
        case Cmd::PERFORM_SYSTEM_TEST:   return QStringLiteral("PERFORM_SYSTEM_TEST");
        case Cmd::EXIT_SYSTEM_TEST:      return QStringLiteral("EXIT_SYSTEM_TEST");
        case Cmd::PERFORM_MVP_TEST:      return QStringLiteral("PERFORM_MVP_TEST");
        case Cmd::TXMT_MVP_TEST_RESULTS: return QStringLiteral("TXMT_MVP_TEST_RESULTS");
        default:                         return QStringLiteral("UNKNOWN(%1)").arg(code);
    }
}

// ─────────────────────────────────────────────
// Helper: Response name from code
// ─────────────────────────────────────────────
inline QString responseName(uint8_t code) {
    switch (code) {
        case Resp::LAST_V:              return QStringLiteral("LAST_V");
        case Resp::PARAMS:              return QStringLiteral("PARAMS");
        case Resp::SYSTEM_TEST_RESULTS: return QStringLiteral("SYSTEM_TEST_RESULTS");
        case Resp::ACK:                 return QStringLiteral("ACK");
        case Resp::NACK:                return QStringLiteral("NACK");
        default:                        return QStringLiteral("UNKNOWN(%1)").arg(code);
    }
}

// ─────────────────────────────────────────────
// Helper: Response timeout for a given command code
// ─────────────────────────────────────────────
inline int responseTimeout(uint8_t cmdCode) {
    if (cmdCode == Cmd::PERFORM_SYSTEM_TEST)
        return Timeout::SYSTEM_TEST_MS;
    return Timeout::RESPONSE_MS;
}

// ─────────────────────────────────────────────
// Helper: Does this command expect a data response (not ACK)?
//
// Commands that get data responses instead of ACK:
//   TXMT_LAST_V        → LAST_V (200)
//   TXMT_PARAMS        → PARAMS (201)
//   PERFORM_SYSTEM_TEST → SYSTEM_TEST_RESULTS (212)
//   PERFORM_MVP_TEST   → SYSTEM_TEST_RESULTS (212)
//   TXMT_MVP_TEST_RESULTS → SYSTEM_TEST_RESULTS (212)
// ─────────────────────────────────────────────
inline bool expectsDataResponse(uint8_t cmdCode) {
    switch (cmdCode) {
        case Cmd::TXMT_LAST_V:
        case Cmd::TXMT_PARAMS:
        case Cmd::PERFORM_SYSTEM_TEST:
        case Cmd::PERFORM_MVP_TEST:
        case Cmd::TXMT_MVP_TEST_RESULTS:
            return true;
        default:
            return false;
    }
}

// ─────────────────────────────────────────────
// Helper: Decode system test flags into readable strings
// ─────────────────────────────────────────────
inline QStringList decodeTestFlags(uint16_t flags) {
    QStringList results;
    for (int i = 0; i < 16; ++i) {
        if (i < TestFlag::NUM_DEFINED) {
            bool failed = (flags >> i) & 1;
            results << QStringLiteral("%1: %2")
                       .arg(TestFlag::bitName(i),
                            failed ? QStringLiteral("FAIL") : QStringLiteral("PASS"));
        } else if ((flags >> i) & 1) {
            // Spare bit set — unexpected, report it
            results << QStringLiteral("Spare bit %1: SET").arg(i);
        }
    }
    return results;
}

// ─────────────────────────────────────────────
// Helper: Checksum computation
//
// Checksum = (-sum_of_payload_bytes) & 0xFF
// Payload = SIZE + CODE + DATA (everything between headers and checksum)
//
// Verification: (SIZE + CODE + DATA + CHECKSUM) % 256 == 0
// ─────────────────────────────────────────────
inline uint8_t computeChecksum(const QByteArray &payload) {
    int sum = 0;
    for (int i = 0; i < payload.size(); ++i) {
        sum += static_cast<uint8_t>(payload.at(i));
    }
    return static_cast<uint8_t>((-sum) & 0xFF);
}

inline bool verifyChecksum(const QByteArray &payloadWithChecksum) {
    int sum = 0;
    for (int i = 0; i < payloadWithChecksum.size(); ++i) {
        sum += static_cast<uint8_t>(payloadWithChecksum.at(i));
    }
    return (sum & 0xFF) == 0;
}

// ─────────────────────────────────────────────
// Helper: Format a QByteArray as hex string for logging
//   e.g. "41 42 03 67 96"
// ─────────────────────────────────────────────
inline QString toHexString(const QByteArray &data) {
    QString hex;
    for (int i = 0; i < data.size(); ++i) {
        if (i > 0) hex += QStringLiteral(" ");
        hex += QStringLiteral("%1").arg(
            static_cast<uint8_t>(data.at(i)), 2, 16, QLatin1Char('0'));
    }
    return hex.toUpper();
}

// ─────────────────────────────────────────────
// Serial Configuration Defaults
// ─────────────────────────────────────────────
namespace Serial {
    constexpr int DEFAULT_BAUD = 9600;
    // 8 data bits, 1 stop bit, no parity, no flow control
    // (set via QSerialPort enums in serialcomm.cpp)
}

} // namespace Protocol

#endif // PROTOCOL_H
