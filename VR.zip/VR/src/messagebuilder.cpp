#include "messagebuilder.h"
#include "protocol.h"

/*
 * messagebuilder.cpp — Layer 2: Command Frame Builder Implementation
 *
 * wrapFrame() is the core helper:
 *   Input:  payload = [SIZE][CODE][...DATA...]
 *   Output: [0x41][0x42][SIZE][CODE][...DATA...][CHECKSUM]
 *
 * Checksum is computed over the payload (SIZE through last DATA byte):
 *   CHECKSUM = (-sum(payload)) & 0xFF
 *
 * Verification rule:
 *   (SIZE + CODE + DATA + CHECKSUM) % 256 == 0
 */

// ─────────────────────────────────────────────
// Internal helper: wrap payload into a complete frame
// ─────────────────────────────────────────────
QByteArray MessageBuilder::wrapFrame(const QByteArray &payload)
{
    uint8_t checksum = Protocol::computeChecksum(payload);

    QByteArray frame;
    frame.reserve(2 + payload.size() + 1);  // headers + payload + checksum
    frame.append(static_cast<char>(Protocol::HEADER_1));  // 0x41
    frame.append(static_cast<char>(Protocol::HEADER_2));  // 0x42
    frame.append(payload);                                 // SIZE + CODE + DATA
    frame.append(static_cast<char>(checksum));             // CHECKSUM
    return frame;
}

// ─────────────────────────────────────────────
// Code 102: EXPECTED_V — Set expected velocity
//
// SIZE = 5 (SIZE + CODE + V_LO + V_HI + CHECKSUM)
// Payload: [05][66][V_LO][V_HI]
//
// Example: velocity=500 → V_LO=0xF4, V_HI=0x01
//   Payload sum: 5 + 102 + 244 + 1 = 352
//   Checksum: (-352) & 0xFF = 160 (0xA0)
//   Wire: 41 42 05 66 F4 01 A0
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildExpectedV(uint16_t velocity)
{
    if (velocity < Protocol::Range::EXPECTED_V_MIN ||
        velocity > Protocol::Range::EXPECTED_V_MAX) {
        return QByteArray();  // Invalid range
    }

    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::EXPECTED_V));  // SIZE = 5
    payload.append(static_cast<char>(Protocol::Cmd::EXPECTED_V));   // CODE = 102
    payload.append(static_cast<char>(velocity & 0xFF));             // V_LO (LSB)
    payload.append(static_cast<char>((velocity >> 8) & 0xFF));      // V_HI (MSB)
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 103: MEASURE — Enter measure mode
//
// SIZE = 3 (SIZE + CODE + CHECKSUM)
// Payload: [03][67]
//
// Wire: 41 42 03 67 96
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildMeasure()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::MEASURE));  // SIZE = 3
    payload.append(static_cast<char>(Protocol::Cmd::MEASURE));   // CODE = 103
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 104: STOP_MEASURE — Exit measure mode
//
// SIZE = 3, Payload: [03][68]
// Wire: 41 42 03 68 95
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildStopMeasure()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::STOP_MEASURE));
    payload.append(static_cast<char>(Protocol::Cmd::STOP_MEASURE));
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 105: TXMT_LAST_V — Request last measured velocity
//
// SIZE = 2 (minimal frame: SIZE + CODE + CHECKSUM, no data)
// Payload: [02][69]
//
// Wire: 41 42 02 69 95
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildTxmtLastV()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::TXMT_LAST_V));  // SIZE = 2
    payload.append(static_cast<char>(Protocol::Cmd::TXMT_LAST_V));   // CODE = 105
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 106: PARALLAX — Set antenna offset
//
// SIZE = 7 (SIZE + CODE + TRIPOD + X + Y + Z + CHECKSUM)
// Payload: [07][6A][TRIPOD][X][Y][Z]
//
// tripod: 0=bracket, 1=tripod
// x,y,z: 0–160 (wire units, ×16 = real meters)
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildParallax(uint8_t tripod, uint8_t x, uint8_t y, uint8_t z)
{
    if (tripod > 1) return QByteArray();
    if (x > Protocol::Range::PARALLAX_OFFSET_MAX ||
        y > Protocol::Range::PARALLAX_OFFSET_MAX ||
        z > Protocol::Range::PARALLAX_OFFSET_MAX) {
        return QByteArray();
    }

    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::PARALLAX));  // SIZE = 7
    payload.append(static_cast<char>(Protocol::Cmd::PARALLAX));   // CODE = 106
    payload.append(static_cast<char>(tripod));
    payload.append(static_cast<char>(x));
    payload.append(static_cast<char>(y));
    payload.append(static_cast<char>(z));
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 107: TXMT_PARAMS — Request current parameters
//
// SIZE = 3, Payload: [03][6B]
// Wire: 41 42 03 6B 92
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildTxmtParams()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::TXMT_PARAMS));
    payload.append(static_cast<char>(Protocol::Cmd::TXMT_PARAMS));
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 108: ENTER_SYSTEM_TEST — Enter system test mode
//
// SIZE = 3, Payload: [03][6C]
// Wire: 41 42 03 6C 91
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildEnterSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::ENTER_SYSTEM_TEST));
    payload.append(static_cast<char>(Protocol::Cmd::ENTER_SYSTEM_TEST));
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 109: PERFORM_SYSTEM_TEST — Run diagnostics
//
// SIZE = 3, Payload: [03][6D]
// Wire: 41 42 03 6D 90
// NOTE: 5-second response timeout (not standard 2s)
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildPerformSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::PERFORM_SYSTEM_TEST));
    payload.append(static_cast<char>(Protocol::Cmd::PERFORM_SYSTEM_TEST));
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 110: EXIT_SYSTEM_TEST — Exit system test mode
//
// SIZE = 3, Payload: [03][6E]
// Wire: 41 42 03 6E 8F
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildExitSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::EXIT_SYSTEM_TEST));
    payload.append(static_cast<char>(Protocol::Cmd::EXIT_SYSTEM_TEST));
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 111: PERFORM_MVP_TEST — Run MVP test
//
// SIZE = 3, Payload: [03][6F]
// Wire: 41 42 03 6F 8E
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildPerformMvpTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::PERFORM_MVP_TEST));
    payload.append(static_cast<char>(Protocol::Cmd::PERFORM_MVP_TEST));
    return wrapFrame(payload);
}

// ─────────────────────────────────────────────
// Code 112: TXMT_MVP_TEST_RESULTS — Request MVP results
//
// SIZE = 3, Payload: [03][70]
// Wire: 41 42 03 70 8D
// ─────────────────────────────────────────────
QByteArray MessageBuilder::buildTxmtMvpTestResults()
{
    QByteArray payload;
    payload.append(static_cast<char>(Protocol::Size::TXMT_MVP_TEST_RESULTS));
    payload.append(static_cast<char>(Protocol::Cmd::TXMT_MVP_TEST_RESULTS));
    return wrapFrame(payload);
}
