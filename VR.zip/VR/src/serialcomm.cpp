#include "serialcomm.h"
#include "protocol.h"

#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>

/*
 * serialcomm.cpp — Win32-native serial implementation.
 *
 * The handle is kept as void* in the header; here we cast it back to HANDLE.
 * INVALID_HANDLE_VALUE ((HANDLE)-1) marks "no port".
 */

static const int  POLL_INTERVAL_MS    = 20;     // RX drain cadence

SerialComm::SerialComm(QObject *parent)
    : QObject(parent)
    , m_handle(INVALID_HANDLE_VALUE)
    , m_state(State::Disconnected)
    , m_waitingResponse(false)
    , m_pendingCmd(0)
    , m_parser(new MessageParser(this))
    , m_pollTimer(new QTimer(this))
    , m_responseTimer(new QTimer(this))
    , m_handshakeTimer(new QTimer(this))
{
    m_responseTimer->setSingleShot(true);
    m_handshakeTimer->setSingleShot(true);
    m_pollTimer->setInterval(POLL_INTERVAL_MS);

    connect(m_pollTimer,      &QTimer::timeout, this, &SerialComm::onPoll);
    connect(m_responseTimer,  &QTimer::timeout, this, &SerialComm::onResponseTimeout);
    connect(m_handshakeTimer, &QTimer::timeout, this, &SerialComm::onHandshakeTimeout);

    connect(m_parser, &MessageParser::messageReceived, this, &SerialComm::onParserMessage);
    connect(m_parser, &MessageParser::checksumError,   this, &SerialComm::checksumError);
    connect(m_parser, &MessageParser::frameTimeout,    this, &SerialComm::frameTimeout);
}

SerialComm::~SerialComm()
{
    doClose();
}

// ─────────────────────────────────────────────────────────────
// Open + handshake
// ─────────────────────────────────────────────────────────────

void SerialComm::openPort(const QString &portName)
{
    if (m_state != State::Disconnected)
        doClose();

    m_portName = portName;

    // Win32 needs the \\.\ prefix to reach COM10 and above reliably.
    const QByteArray devPath = (QStringLiteral("\\\\.\\") + portName).toLatin1();

    HANDLE h = CreateFileA(devPath.constData(),
                           GENERIC_READ | GENERIC_WRITE,
                           0,             // no sharing
                           nullptr,
                           OPEN_EXISTING,
                           0,             // synchronous I/O
                           nullptr);

    if (h == INVALID_HANDLE_VALUE) {
        const DWORD err = GetLastError();
        QString reason;
        if (err == ERROR_FILE_NOT_FOUND)
            reason = QStringLiteral("port does not exist");
        else if (err == ERROR_ACCESS_DENIED)
            reason = QStringLiteral("port busy or in use");
        else
            reason = QStringLiteral("Win32 error %1").arg(static_cast<uint>(err));

        emit portError(QStringLiteral("Cannot open %1 (%2)").arg(portName, reason));
        return;
    }

    m_handle = h;

    if (!configurePort()) {
        doClose();
        emit portError(QStringLiteral("Failed to configure %1 (9600 8N1)").arg(portName));
        return;
    }

    PurgeComm(h, PURGE_RXCLEAR | PURGE_TXCLEAR);
    m_parser->reset();

    // The VR runs its power-up BIT autonomously and sends SYSTEM_TEST_RESULTS
    // unsolicited. The PC plays no active role in triggering it, so we do NOT
    // send a probe here. We simply open the port, start draining RX, and report
    // the port as open. MainWindow owns the 5 s BIT-listening window and decides
    // what to do if no BIT frame arrives.
    m_state = State::Connected;
    m_pollTimer->start();

    emit portOpened(portName);
}

// ─────────────────────────────────────────────────────────────
// Port configuration
// ─────────────────────────────────────────────────────────────

bool SerialComm::configurePort()
{
    HANDLE h = static_cast<HANDLE>(m_handle);

    DCB dcb;
    ZeroMemory(&dcb, sizeof(dcb));
    dcb.DCBlength = sizeof(dcb);
    if (!GetCommState(h, &dcb))
        return false;

    dcb.BaudRate      = CBR_9600;
    dcb.ByteSize      = 8;
    dcb.Parity        = NOPARITY;
    dcb.StopBits      = ONESTOPBIT;
    dcb.fBinary       = TRUE;
    dcb.fParity       = FALSE;
    dcb.fOutxCtsFlow  = FALSE;
    dcb.fOutxDsrFlow  = FALSE;
    dcb.fDtrControl   = DTR_CONTROL_DISABLE;
    dcb.fRtsControl   = RTS_CONTROL_DISABLE;
    dcb.fInX          = FALSE;
    dcb.fOutX         = FALSE;
    if (!SetCommState(h, &dcb))
        return false;

    // Non-blocking reads: ReadFile returns immediately with whatever is buffered.
    COMMTIMEOUTS to;
    to.ReadIntervalTimeout         = MAXDWORD;
    to.ReadTotalTimeoutConstant    = 0;
    to.ReadTotalTimeoutMultiplier  = 0;
    to.WriteTotalTimeoutConstant   = 100;
    to.WriteTotalTimeoutMultiplier = 10;
    if (!SetCommTimeouts(h, &to))
        return false;

    return true;
}

bool SerialComm::writeBytes(const QByteArray &data)
{
    HANDLE h = static_cast<HANDLE>(m_handle);
    if (h == INVALID_HANDLE_VALUE)
        return false;

    DWORD written = 0;
    const BOOL ok = WriteFile(h, data.constData(),
                              static_cast<DWORD>(data.size()),
                              &written, nullptr);
    return ok && written == static_cast<DWORD>(data.size());
}

// ─────────────────────────────────────────────────────────────
// RX polling
// ─────────────────────────────────────────────────────────────

void SerialComm::onPoll()
{
    HANDLE h = static_cast<HANDLE>(m_handle);
    if (h == INVALID_HANDLE_VALUE)
        return;

    char buf[256];
    DWORD read = 0;
    if (ReadFile(h, buf, sizeof(buf), &read, nullptr) && read > 0) {
        const QByteArray chunk(buf, static_cast<int>(read));
        emit dataReceived(chunk);
        m_parser->processBytes(chunk);   // emits messageReceived / checksumError
    }
}

// ─────────────────────────────────────────────────────────────
// Decoded frame from parser
// ─────────────────────────────────────────────────────────────

void SerialComm::onParserMessage(const ParsedMessage &msg)
{
    // A decoded frame may be an unsolicited power-up SYSTEM_TEST_RESULTS, or a
    // reply to a command we sent. Either way, forward it to the GUI. If it
    // resolves a pending command, clear the response timer.
    if (m_waitingResponse) {
        m_waitingResponse = false;
        m_responseTimer->stop();
    }
    emit messageReceived(msg);
}

void SerialComm::onResponseTimeout()
{
    m_waitingResponse = false;
    emit responseTimeout(m_pendingCmd);
}

void SerialComm::onHandshakeTimeout()
{
    // No longer used: the VR sends BIT results unsolicited and the PC runs no
    // active handshake. Kept as a no-op so existing connections/moc stay valid.
}

// ─────────────────────────────────────────────────────────────
// Sending commands (post-connect)
// ─────────────────────────────────────────────────────────────

void SerialComm::sendCommand(const QByteArray &frame, uint8_t cmdCode)
{
    if (m_state != State::Connected) {
        emit portError(QStringLiteral("Port not connected"));
        return;
    }

    m_parser->reset();

    if (!writeBytes(frame)) {
        emit portError(QStringLiteral("Write failed on %1").arg(m_portName));
        return;
    }
    emit dataSent(frame);

    m_pendingCmd      = cmdCode;
    m_waitingResponse = true;
    m_responseTimer->start(Protocol::responseTimeout(cmdCode));
}

// ─────────────────────────────────────────────────────────────
// Close
// ─────────────────────────────────────────────────────────────

void SerialComm::closePort()
{
    const bool wasActive = (m_state != State::Disconnected);
    doClose();
    if (wasActive)
        emit portClosed();
}

void SerialComm::doClose()
{
    m_pollTimer->stop();
    m_responseTimer->stop();
    m_handshakeTimer->stop();
    m_waitingResponse = false;

    HANDLE h = static_cast<HANDLE>(m_handle);
    if (h != INVALID_HANDLE_VALUE)
        CloseHandle(h);

    m_handle = INVALID_HANDLE_VALUE;
    m_state  = State::Disconnected;
}

// ─────────────────────────────────────────────────────────────
// Port enumeration (no Qt6SerialPort needed)
// ─────────────────────────────────────────────────────────────

QStringList SerialComm::availablePorts()
{
    QStringList ports;
    char target[1024];

    for (int i = 1; i <= 255; ++i) {
        const QByteArray name = QStringLiteral("COM%1").arg(i).toLatin1();
        // QueryDosDevice returns non-zero only if the device name exists.
        if (QueryDosDeviceA(name.constData(), target, sizeof(target)) != 0)
            ports << QString::fromLatin1(name);
    }
    return ports;
}
