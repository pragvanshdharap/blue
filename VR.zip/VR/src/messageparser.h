#ifndef MESSAGEPARSER_H
#define MESSAGEPARSER_H

/*
 * messageparser.h — Layer 3: Response Frame Parser
 *
 * Byte-by-byte state machine that:
 *   1. Scans for header pattern 0x41 0x42
 *   2. Reads SIZE byte
 *   3. Collects (SIZE - 1) remaining bytes (CODE + DATA + CHECKSUM)
 *   4. Validates checksum: (SIZE + CODE + DATA + CHECKSUM) % 256 == 0
 *   5. Decodes into typed struct based on CODE
 *   6. Emits signal with decoded message
 *
 * State machine:
 *   WAIT_HEADER_1 → WAIT_HEADER_2 → WAIT_SIZE → COLLECTING → (complete)
 *                                                              ↓
 *                                              validate → decode → emit
 *
 * On any error (bad checksum, unexpected byte), resets to WAIT_HEADER_1
 * and resumes scanning for the next 0x41 0x42 pattern.
 *
 * Inter-byte timeout: if no byte arrives within 1 second after frame
 * started, the partial frame is discarded and state resets.
 *
 * Reference: VELOCITY_RADAR_COMPLETE_CONTEXT.md v1.0
 */

#include <QObject>
#include <QByteArray>
#include <QTimer>
#include <cstdint>

// ─────────────────────────────────────────────
// Decoded response structures
// ─────────────────────────────────────────────

struct AckMessage {
    uint8_t acknowledgedCode;   // The command code being ACK'd
};

struct NackMessage {
    uint8_t rejectedCode;       // The command code being NACK'd
};

struct LastVMessage {
    uint8_t  result;            // 0x00 = OK, 0xFF = measurement error
    uint16_t rawVelocity;       // 0–24000 wire units
    double   realVelocityMs;    // rawVelocity / 16.0 (m/s)
};

struct ParamsMessage {
    uint16_t expectedVelocity;  // 150–1500 m/s
    uint8_t  tripod;            // 0 = bracket, 1 = tripod
    uint8_t  offsetX;           // 0–160 (wire units)
    uint8_t  offsetY;
    uint8_t  offsetZ;
};

struct SystemTestResultsMessage {
    uint16_t flags;             // 16-bit flag word (bit=1 → failure)
    bool     allPassed;         // Convenience: flags == 0
};

// ─────────────────────────────────────────────
// Variant wrapper for any decoded response
// ─────────────────────────────────────────────

struct ParsedMessage {
    enum Type {
        ACK,
        NACK,
        LAST_V,
        PARAMS,
        SYSTEM_TEST_RESULTS,
        UNKNOWN
    };

    Type type = UNKNOWN;
    uint8_t code = 0;           // Raw response code byte
    QByteArray rawFrame;        // Complete frame including headers

    // Only one of these is valid, determined by 'type'
    AckMessage               ack;
    NackMessage              nack;
    LastVMessage             lastV;
    ParamsMessage            params;
    SystemTestResultsMessage testResults;
};

// ─────────────────────────────────────────────
// Parser class
// ─────────────────────────────────────────────

class MessageParser : public QObject
{
    Q_OBJECT

public:
    explicit MessageParser(QObject *parent = nullptr);
    ~MessageParser() override;

    // Feed raw bytes from serial port (can be 1 byte or many)
    void processBytes(const QByteArray &data);

    // Reset parser state (e.g. on port close or error)
    void reset();

signals:
    // Emitted when a complete, valid response is decoded
    void messageReceived(const ParsedMessage &msg);

    // Emitted on checksum failure (frame received but invalid)
    void checksumError(const QByteArray &rawFrame);

    // Emitted when inter-byte timeout expires mid-frame
    void frameTimeout();

private slots:
    void onInterByteTimeout();

private:
    // Parser state machine states
    enum class State {
        WAIT_HEADER_1,  // Scanning for 0x41
        WAIT_HEADER_2,  // Got 0x41, expecting 0x42
        WAIT_SIZE,      // Got headers, expecting SIZE byte
        COLLECTING      // Collecting remaining (SIZE - 1) bytes
    };

    State    m_state;
    uint8_t  m_size;            // SIZE field value
    int      m_bytesRemaining;  // How many more bytes to collect
    QByteArray m_buffer;        // Accumulates frame bytes (from SIZE onward)
    QByteArray m_rawFrame;      // Complete frame including headers

    QTimer  *m_interByteTimer;  // 1-second inter-byte timeout

    // Process one byte through the state machine
    void processByte(uint8_t byte);

    // Called when m_bytesRemaining reaches 0 — full frame in buffer
    void handleCompleteFrame();

    // Decode a validated payload (SIZE+CODE+DATA, no checksum) by CODE
    ParsedMessage decodePayload(const QByteArray &payload);

    // Individual decoders (payload = SIZE+CODE+DATA, headers/checksum stripped)
    ParsedMessage decodeAck(const QByteArray &payload);
    ParsedMessage decodeNack(const QByteArray &payload);
    ParsedMessage decodeLastV(const QByteArray &payload);
    ParsedMessage decodeParams(const QByteArray &payload);
    ParsedMessage decodeSystemTestResults(const QByteArray &payload);
};

Q_DECLARE_METATYPE(ParsedMessage)

#endif // MESSAGEPARSER_H
