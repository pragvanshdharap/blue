#ifndef MESSAGEBUILDER_H
#define MESSAGEBUILDER_H

/*
 * messagebuilder.h — Layer 2: Command Frame Builder
 *
 * Builds complete binary frames for all 11 PC→System commands.
 * Each function returns a QByteArray: [HEADER_1][HEADER_2][payload][CHECKSUM]
 *
 * Frame format:
 *   Byte 1:   HEADER_1 (0x41 'A')
 *   Byte 2:   HEADER_2 (0x42 'B')
 *   Byte 3:   SIZE
 *   Byte 4:   CODE
 *   Byte 5…N: DATA (0 or more bytes, little-endian for multi-byte)
 *   Byte N+1: CHECKSUM = (-sum(SIZE..DATA)) & 0xFF
 */

#include <QByteArray>
#include <cstdint>

class MessageBuilder
{
public:
    // ── Commands with no data ────────────────────────

    // Code 103: Enter measure mode
    // Wire: [41][42][03][67][96]
    static QByteArray buildMeasure();

    // Code 104: Exit measure mode
    // Wire: [41][42][03][68][95]
    static QByteArray buildStopMeasure();

    // Code 105: Request last measured velocity
    // Wire: [41][42][02][69][95]
    // NOTE: SIZE=2 (minimal frame — only SIZE+CODE+CHECKSUM)
    static QByteArray buildTxmtLastV();

    // Code 107: Request current parameters
    // Wire: [41][42][03][6B][92]
    static QByteArray buildTxmtParams();

    // Code 108: Enter system test mode
    // Wire: [41][42][03][6C][91]
    static QByteArray buildEnterSystemTest();

    // Code 109: Run system diagnostics (~5s response time)
    // Wire: [41][42][03][6D][90]
    static QByteArray buildPerformSystemTest();

    // Code 110: Exit system test mode
    // Wire: [41][42][03][6E][8F]
    static QByteArray buildExitSystemTest();

    // Code 111: Run MVP internal test
    // Wire: [41][42][03][6F][8E]
    static QByteArray buildPerformMvpTest();

    // Code 112: Request MVP test results
    // Wire: [41][42][03][70][8D]
    static QByteArray buildTxmtMvpTestResults();

    // ── Commands with data ───────────────────────────

    // Code 102: Set expected velocity
    //   velocity: 150–1500 (integer m/s)
    //   Wire: [41][42][05][66][V_LO][V_HI][CHECKSUM]
    //   Returns empty QByteArray if velocity out of range
    static QByteArray buildExpectedV(uint16_t velocity);

    // Code 106: Set antenna offset (parallax)
    //   tripod: 0 = bracket mounted, 1 = tripod mounted
    //   x, y, z: offset values 0–160 (only meaningful if tripod=1)
    //   Wire: [41][42][07][6A][TRIPOD][X][Y][Z][CHECKSUM]
    //   Returns empty QByteArray if values out of range
    static QByteArray buildParallax(uint8_t tripod, uint8_t x, uint8_t y, uint8_t z);

private:
    // Internal: wraps payload (SIZE+CODE+DATA) with headers and checksum
    //   payload = [SIZE][CODE][...DATA...]
    //   returns  = [0x41][0x42][SIZE][CODE][...DATA...][CHECKSUM]
    static QByteArray wrapFrame(const QByteArray &payload);
};

#endif // MESSAGEBUILDER_H
