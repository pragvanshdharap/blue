#ifndef EXPECTEDVDIALOG_H
#define EXPECTEDVDIALOG_H

/*
 * expectedvdialog.h — Layer 5: Expected Velocity Input Dialog
 *
 * Modal dialog with a QSpinBox (range 150–1500 m/s).
 * User enters integer velocity, clicks OK → getVelocity() returns value.
 * Cancel → QDialog::Rejected.
 */

#include <QDialog>
#include <QSpinBox>
#include <QLabel>
#include <QDialogButtonBox>
#include <QVBoxLayout>
#include <cstdint>

class ExpectedVDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ExpectedVDialog(QWidget *parent = nullptr);
    ~ExpectedVDialog() override = default;

    uint16_t getVelocity() const;

private:
    QSpinBox *m_spinBox;
};

#endif // EXPECTEDVDIALOG_H
