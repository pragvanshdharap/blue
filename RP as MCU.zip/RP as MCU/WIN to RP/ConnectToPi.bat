@echo off
:: ConnectToPi.bat — Launch GUI with pre-filled IP and auto-connect
:: Edit the IP below to match your Pi's address
set "PI_HOST=192.168.10.2"
set "PI_PORT=5050"
set "AUTO_CONNECT=1"

:: Optional: activate a venv next to this script if present
if exist "%~dp0.venv\Scripts\activate.bat" call "%~dp0.venv\Scripts\activate.bat"

:: Prefer python launcher 'py' on Windows if available, else 'python'
where py >nul 2>nul && ( set "PY=py" ) || ( set "PY=python" )

%PY% "%~dp0led_gui_autoconn.py" --host "%PI_HOST%" --port %PI_PORT% --auto-connect
