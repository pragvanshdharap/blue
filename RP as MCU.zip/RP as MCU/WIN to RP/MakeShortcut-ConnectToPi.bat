@echo off
:: MakeShortcut-ConnectToPi.bat — Creates a desktop shortcut that runs ConnectToPi.bat
set "SCRIPT=%~dp0ConnectToPi.bat"
set "SHORTCUT=%USERPROFILE%\Desktop\Connect to my Pi.lnk"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
  "$s=(New-Object -COM WScript.Shell).CreateShortcut('%SHORTCUT%');" ^
  "$s.TargetPath='%SCRIPT%';" ^
  "$s.WorkingDirectory='%~dp0';" ^
  "$s.IconLocation='%SystemRoot%\System32\imageres.dll,1';" ^
  "$s.Description='Launch LED GUI and auto-connect to Raspberry Pi';" ^
  "$s.Save()"

echo Created shortcut: %SHORTCUT%
pause
