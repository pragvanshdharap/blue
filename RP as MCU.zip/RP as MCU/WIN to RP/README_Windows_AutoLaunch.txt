Windows quickstart

Files:
- led_gui_autoconn.py     : GUI that accepts --host/--port and auto-connect flag
- ConnectToPi.bat         : Edits IP/port and launches GUI with auto-connect
- MakeShortcut-ConnectToPi.bat : Creates a Desktop shortcut to ConnectToPi.bat

Steps:
1) Install Python 3.10+ and PySide6:
   py -m pip install PySide6

2) Place all three files in one folder.
   Optionally create a venv in that folder and install PySide6 there.

3) Edit ConnectToPi.bat and set PI_HOST to your Pi's IP (e.g., 192.168.10.2).

4) Double-click ConnectToPi.bat (or run MakeShortcut-ConnectToPi.bat once to create a Desktop shortcut).

Notes:
- You can also run the GUI directly:
  py led_gui_autoconn.py --host 192.168.10.2 --port 5050 --auto-connect
- Environment variables PI_HOST, PI_PORT, AUTO_CONNECT=1 will be honored by the GUI.
