# led_gui_autoconn.spec — One-file capable PyInstaller spec for led_gui_autoconn.py
# Build (one-file EXE on Windows):
#   pyinstaller -y --onefile --noconsole led_gui_autoconn.spec
#
# Build (one-folder for easier debugging):
#   pyinstaller -y led_gui_autoconn.spec
#
# Notes:
# - We explicitly collect PySide6 plugins/data to avoid "Qt platform plugin not found".
# - Build on the target OS (no cross-compile).

import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

pyside6_datas = collect_data_files('PySide6', include_py_files=False)
hidden = collect_submodules('PySide6') + collect_submodules('shiboken6')

script_path = 'led_gui_autoconn.py'
block_cipher = None

a = Analysis(
    [script_path],
    pathex=['.'],
    binaries=[],
    datas=pyside6_datas,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    name='led_gui_autoconn',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,   # GUI app
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon='led.ico',  # (optional) provide your icon path
)

# Note: Including COLLECT yields a one-folder build by default.
# Passing --onefile at the command line makes PyInstaller pack into a single EXE.
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='led_gui_autoconn'
)
