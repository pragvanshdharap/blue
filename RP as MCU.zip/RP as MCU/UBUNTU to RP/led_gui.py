#!/usr/bin/env python3
"""
PySide6 GUI client for Raspberry Pi LED server (headless control)
- Connects to <PI_IP>:5050 (configurable)
- Buttons for LED1..LED4 (toggle ON/OFF)
- "All OFF" button
- "Status" button shows current LED states from server
- Works on Linux & Windows (PySide6 only)

Protocol (ASCII, one command per line):
  LED <1..4> ON|OFF
  ALL OFF
  STATUS
  QUIT

Server banner: "OK LEDSRV READY"
Typical replies: "OK", "STATUS LED1=ON LED2=OFF LED3=ON LED4=OFF"
"""

import sys
import socket
import threading
import queue
import time

from PySide6 import QtCore, QtWidgets


DEFAULT_PORT = 5050
CONNECT_TIMEOUT = 5.0
RECV_BUFSIZE = 4096


class NetWorker(QtCore.QObject):
    """
    Worker object running in a background thread.
    Provides a simple request->response API for line-based commands.
    """
    connected = QtCore.Signal(str)        # banner string
    disconnected = QtCore.Signal(str)     # reason
    response = QtCore.Signal(str)         # one-line server response
    error = QtCore.Signal(str)

    def __init__(self):
        super().__init__()
        self._sock = None
        self._lock = threading.Lock()
        self._rx_thread = None
        self._rx_run = False
        self._rq = queue.Queue()  # command queue (strings without trailing \n)

    @QtCore.Slot(str, int)
    def connect_to(self, host: str, port: int):
        self.disconnect_from("reconnect")
        try:
            s = socket.create_connection((host, port), timeout=CONNECT_TIMEOUT)
            s.settimeout(1.0)
            banner = s.recv(RECV_BUFSIZE).decode(errors="ignore").strip()
            self._sock = s
            self.connected.emit(banner if banner else "CONNECTED")
            # start RX dispatcher thread
            self._rx_run = True
            self._rx_thread = threading.Thread(target=self._rx_loop, daemon=True)
            self._rx_thread.start()
        except Exception as e:
            self._sock = None
            self.error.emit(f"Connect error: {e}")

    @QtCore.Slot()
    def disconnect_from(self, reason: str = "user"):
        with self._lock:
            if self._sock:
                try:
                    # try graceful QUIT
                    try:
                        self._send_line("QUIT")
                    except Exception:
                        pass
                    self._sock.close()
                except Exception:
                    pass
                self._sock = None
        if self._rx_thread:
            self._rx_run = False
            self._rx_thread.join(timeout=0.2)
            self._rx_thread = None
        self.disconnected.emit(reason)

    def _send_line(self, line: str):
        if not self._sock:
            raise RuntimeError("Not connected")
        msg = (line + "\n").encode()
        self._sock.sendall(msg)

    @QtCore.Slot(str)
    def send_command(self, line: str):
        """Queue a command to be sent by the RX loop; we also read a response line if available."""
        self._rq.put(line)

    def _rx_loop(self):
        buf = b""
        last_send_ts = 0.0
        while self._rx_run:
            # send any pending command
            try:
                cmd = self._rq.get_nowait()
                with self._lock:
                    if self._sock:
                        self._send_line(cmd)
                        last_send_ts = time.time()
                # We don't block waiting here; we parse replies in the same loop.
            except queue.Empty:
                pass

            # try to read some data
            with self._lock:
                s = self._sock
            if not s:
                break
            try:
                chunk = s.recv(RECV_BUFSIZE)
                if not chunk:
                    raise ConnectionError("Server closed")
                buf += chunk
                while b"\n" in buf:
                    line, buf = buf.split(b"\n", 1)
                    text = line.decode(errors="ignore").strip()
                    if text:
                        self.response.emit(text)
            except socket.timeout:
                # no data this tick; continue
                pass
            except Exception as e:
                self.error.emit(f"RX error: {e}")
                break

        # Cleanup
        self.disconnect_from("rx-stop")


class MainWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Pi LED Controller (PySide6)")
        self.resize(600, 360)

        # --- UI controls ---
        self.host_edit = QtWidgets.QLineEdit("raspberrypi.local")
        self.port_edit = QtWidgets.QLineEdit(str(DEFAULT_PORT))
        self.connect_btn = QtWidgets.QPushButton("Connect")
        self.disconnect_btn = QtWidgets.QPushButton("Disconnect")
        self.disconnect_btn.setEnabled(False)

        top = QtWidgets.QHBoxLayout()
        top.addWidget(QtWidgets.QLabel("Host:"))
        top.addWidget(self.host_edit, 1)
        top.addWidget(QtWidgets.QLabel("Port:"))
        self.port_edit.setMaximumWidth(90)
        top.addWidget(self.port_edit)
        top.addWidget(self.connect_btn)
        top.addWidget(self.disconnect_btn)

        # LED buttons (toggle style)
        grid = QtWidgets.QGridLayout()
        self.led_btns = []
        for i in range(4):
            btn = QtWidgets.QPushButton(f"LED {i+1}: OFF")
            btn.setCheckable(True)
            btn.setMinimumHeight(48)
            btn.clicked.connect(lambda checked, idx=i: self.on_led_clicked(idx, checked))
            self.led_btns.append(btn)
            r, c = divmod(i, 2)
            grid.addWidget(btn, r, c)

        self.all_off_btn = QtWidgets.QPushButton("ALL OFF")
        self.status_btn = QtWidgets.QPushButton("STATUS")
        grid.addWidget(self.all_off_btn, 2, 0)
        grid.addWidget(self.status_btn, 2, 1)

        # Log box
        self.log = QtWidgets.QPlainTextEdit()
        self.log.setReadOnly(True)

        lay = QtWidgets.QVBoxLayout(self)
        lay.addLayout(top)
        lay.addLayout(grid)
        lay.addWidget(self.log, 1)

        # --- networking worker in a thread ---
        self.thread = QtCore.QThread(self)
        self.worker = NetWorker()
        self.worker.moveToThread(self.thread)
        self.thread.start()

        # Connect signals
        self.connect_btn.clicked.connect(self.do_connect)
        self.disconnect_btn.clicked.connect(self.do_disconnect)
        self.all_off_btn.clicked.connect(lambda: self.send_cmd("ALL OFF"))
        self.status_btn.clicked.connect(lambda: self.send_cmd("STATUS"))

        self.worker.connected.connect(self.on_connected)
        self.worker.disconnected.connect(self.on_disconnected)
        self.worker.response.connect(self.on_response)
        self.worker.error.connect(self.on_error)

        # disable LED buttons until connected
        self.set_led_controls_enabled(False)

    def set_led_controls_enabled(self, enabled: bool):
        for b in self.led_btns:
            b.setEnabled(enabled)
        self.all_off_btn.setEnabled(enabled)
        self.status_btn.setEnabled(enabled)

    def log_line(self, text: str):
        self.log.appendPlainText(text)
        self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())

    @QtCore.Slot()
    def do_connect(self):
        host = self.host_edit.text().strip()
        try:
            port = int(self.port_edit.text())
        except ValueError:
            self.log_line("Invalid port")
            return
        self.log_line(f"Connecting to {host}:{port} ...")
        QtCore.QMetaObject.invokeMethod(self.worker, "connect_to", QtCore.Qt.QueuedConnection,
                                        QtCore.Q_ARG(str, host), QtCore.Q_ARG(int, port))
        self.connect_btn.setEnabled(False)

    @QtCore.Slot()
    def do_disconnect(self):
        QtCore.QMetaObject.invokeMethod(self.worker, "disconnect_from", QtCore.Qt.QueuedConnection)
        self.connect_btn.setEnabled(True)

    @QtCore.Slot(str)
    def on_connected(self, banner: str):
        self.log_line(f"[CONNECTED] {banner}")
        self.disconnect_btn.setEnabled(True)
        self.set_led_controls_enabled(True)
        # ask for STATUS to sync UI
        self.send_cmd("STATUS")

    @QtCore.Slot(str)
    def on_disconnected(self, reason: str):
        self.log_line(f"[DISCONNECTED] {reason}")
        self.disconnect_btn.setEnabled(False)
        self.connect_btn.setEnabled(True)
        self.set_led_controls_enabled(False)
        # reset button labels
        for i, b in enumerate(self.led_btns):
            b.setChecked(False)
            b.setText(f"LED {i+1}: OFF")

    @QtCore.Slot(str)
    def on_response(self, line: str):
        self.log_line(f"< {line}")
        if line.startswith("STATUS "):
            # parse STATUS LED1=ON LED2=OFF ...
            parts = line.split()
            # parts[0] == "STATUS"
            states = {}
            for kv in parts[1:]:
                if "=" in kv:
                    k, v = kv.split("=")
                    states[k] = v
            for i in range(4):
                key = f"LED{i+1}"
                on = (states.get(key, "OFF") == "ON")
                self.led_btns[i].setChecked(on)
                self.led_btns[i].setText(f"LED {i+1}: {'ON' if on else 'OFF'}")

    @QtCore.Slot(str)
    def on_error(self, msg: str):
        self.log_line(f"[ERROR] {msg}")

    def send_cmd(self, cmd: str):
        self.log_line(f"> {cmd}")
        QtCore.QMetaObject.invokeMethod(self.worker, "send_command", QtCore.Qt.QueuedConnection,
                                        QtCore.Q_ARG(str, cmd))

    def on_led_clicked(self, idx: int, checked: bool):
        self.send_cmd(f"LED {idx+1} {'ON' if checked else 'OFF'}")
        # Ask STATUS to reflect authoritative state from server
        QtCore.QTimer.singleShot(100, lambda: self.send_cmd("STATUS"))

    def closeEvent(self, e):
        self.do_disconnect()
        super().closeEvent(e)


def main():
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
