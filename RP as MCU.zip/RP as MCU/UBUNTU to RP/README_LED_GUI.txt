PySide6 GUI client for Raspberry Pi LED server

1) Install dependencies on your Linux/Windows PC:
   pip install PySide6

2) Run the GUI:
   python led_gui.py

3) In the GUI:
   - Enter your Raspberry Pi IP (e.g., raspberrypi.local or 192.168.1.50)
   - Port: 5050 (default from the server example)
   - Click CONNECT
   - Use LED1..LED4 buttons to toggle ON/OFF, or click STATUS / ALL OFF

Notes:
- This client assumes the Pi is running the 'led_server.py' from the earlier instructions.
- The client requests STATUS after each toggle to stay in sync with the server.
