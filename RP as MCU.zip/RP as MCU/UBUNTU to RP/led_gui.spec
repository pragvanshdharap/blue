# led_gui.spec — One-file PyInstaller spec for led_gui.py
# Usage:
#   pyinstaller -y led_gui.spec
#
# Output:
#   dist/led_gui/led_gui.exe (Windows)
#   dist/led_gui/led_gui     (Linux/macOS)
#
# Notes:
# - This spec bundles PySide6 plugins (platforms, styles, etc.) via collect_data_files
#   so you avoid "could not find Qt platform plugin" errors.
# - Build on the target OS (cross-OS builds are not supported by PyInstaller).

import os
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

# Collect Qt plugin/data files and hidden imports explicitly (defensive)
pyside6_datas = collect_data_files('PySide6', include_py_files=False)
pyside6_hidden = collect_submodules('PySide6')
shiboken6_hidden = collect_submodules('shiboken6')

# If your script is not in the same folder, adjust this path:
script_path = 'led_gui.py'

block_cipher = None

a = Analysis(
    [script_path],
    pathex=['.'],
    binaries=[],
    datas=pyside6_datas,
    hiddenimports=pyside6_hidden + shiboken6_hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# Optional icon: replace "led.ico" with your .ico path and uncomment the "icon" arg below.
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    name='led_gui',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,          # set True if you installed UPX and want smaller binaries
    console=False,      # GUI app; set True if you want a console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    # icon='led.ico',
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='led_gui'
)
