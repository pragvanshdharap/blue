// ads131m08.h
#ifndef __ADS131M08_H
#define __ADS131M08_H

#include "stm32f4xx_hal.h"
#include <stdint.h>

// === Commands ===
#define CMD_RESET       0x0011
#define CMD_UNLOCK      0x0655
#define CMD_LOCK        0x0555
#define CMD_RDATA       0x0012
#define CMD_WREG        0x6000
#define CMD_RREG        0x2000

// === Registers (useful ones) ===
#define REG_CH_EN       0x40
#define REG_CONFIG1     0x01

// Externs for user to set from main
extern SPI_HandleTypeDef hspi1;
extern GPIO_TypeDef* ADS131M08_CS_Port;
extern uint16_t ADS131M08_CS_Pin;

// API
void ADS131M08_Init(void);
void ADS131M08_SendCmd(uint16_t cmd);
void ADS131M08_WriteReg(uint8_t addr, uint16_t data);
void ADS131M08_ReadData(uint8_t *rxBuf);
void ADS131M08_ParseSamples(uint8_t *rxBuf, int32_t *channels_out);
void ADS131M08_DataReadyHandler(void);
void ADS131M08_ConfigureDefault(void);

// Conversion helpers
float ADS131M08_RawToVoltage(int32_t rawValue, float vref, float gain);
float VoltageToG(float voltage, float zero_g_voltage, float sensitivity_v_per_g);

#endif
