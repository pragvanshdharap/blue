// ads131m08.c
#include "ads131m08.h"
#include "main.h"
#include <string.h>

SPI_HandleTypeDef hspi1; // will be linked to CubeMX-generated hspi1
GPIO_TypeDef* ADS131M08_CS_Port = GPIOA;
uint16_t ADS131M08_CS_Pin = GPIO_PIN_4;

static void CS_Select(void) {
    HAL_GPIO_WritePin(ADS131M08_CS_Port, ADS131M08_CS_Pin, GPIO_PIN_RESET);
}
static void CS_Deselect(void) {
    HAL_GPIO_WritePin(ADS131M08_CS_Port, ADS131M08_CS_Pin, GPIO_PIN_SET);
}

void ADS131M08_Init(void) {
    // Ensure CS high
    CS_Deselect();
    HAL_Delay(10);
}

void ADS131M08_SendCmd(uint16_t cmd) {
    uint8_t tx[2] = { (uint8_t)(cmd >> 8), (uint8_t)(cmd & 0xFF) };
    CS_Select();
    HAL_SPI_Transmit(&hspi1, tx, 2, HAL_MAX_DELAY);
    CS_Deselect();
}

void ADS131M08_WriteReg(uint8_t addr, uint16_t data) {
    uint16_t cmd = CMD_WREG | (addr & 0x7F);
    uint8_t tx[4];
    tx[0] = (uint8_t)(cmd >> 8);
    tx[1] = (uint8_t)(cmd & 0xFF);
    tx[2] = (uint8_t)(data >> 8);
    tx[3] = (uint8_t)(data & 0xFF);
    CS_Select();
    HAL_SPI_Transmit(&hspi1, tx, 4, HAL_MAX_DELAY);
    CS_Deselect();
}

void ADS131M08_ReadData(uint8_t *rxBuf) {
    // In continuous mode, a plain SPI read while CS low reads status+channels
    CS_Select();
    HAL_SPI_Receive(&hspi1, rxBuf, 27, HAL_MAX_DELAY);
    CS_Deselect();
}

void ADS131M08_ParseSamples(uint8_t *rxBuf, int32_t *channels_out) {
    for (int i = 0; i < 8; i++) {
        uint8_t *ch = &rxBuf[3 + i * 3];
        int32_t val = ((int32_t)ch[0] << 16) | ((int32_t)ch[1] << 8) | ((int32_t)ch[2]);
        if (val & 0x800000) val |= 0xFF000000;  // Sign-extend 24-bit to 32-bit
        channels_out[i] = val;
    }
}

void ADS131M08_DataReadyHandler(void) {
    uint8_t rx_buf[27];
    static int32_t parsed[8];
    ADS131M08_ReadData(rx_buf);
    ADS131M08_ParseSamples(rx_buf, parsed);
    // Copy to global place that application can use (simple approach)
    memcpy((void*)(&parsed[0]), (void*)(&parsed[0]), 0); // placeholder to avoid unused warnings
    // In real usage, copy parsed to user buffer or set flag
    // For convenience, a user may expose adc_data array in main.c
}

void ADS131M08_ConfigureDefault(void) {
    ADS131M08_SendCmd(CMD_RESET);
    HAL_Delay(2);
    ADS131M08_SendCmd(CMD_UNLOCK);
    HAL_Delay(1);

    // CONFIG1: default 500 SPS
    ADS131M08_WriteReg(0x01, 0x0600);

    // Disable advanced features by defaults
    for (uint8_t ch = 0x05; ch <= 0x0C; ch++) {
        ADS131M08_WriteReg(ch, 0x0000); // CHxSET normal, gain=1
    }

    // Enable all 8 channels
    ADS131M08_WriteReg(REG_CH_EN, 0x00FF);

    ADS131M08_SendCmd(CMD_LOCK);
}

// Conversion helper
float ADS131M08_RawToVoltage(int32_t rawValue, float vref, float gain) {
    const float maxCode = (float)(1 << 23); // 2^23
    return ((float)rawValue) * (vref / gain) / maxCode;
}

float VoltageToG(float voltage, float zero_g_voltage, float sensitivity_v_per_g) {
    return (voltage - zero_g_voltage) / sensitivity_v_per_g;
}
