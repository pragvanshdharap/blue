/* stm32f4xx_it.c
   Minimal EXTI IRQ handler snippet to integrate with ADS131M08 driver.
   If you have CubeMX-generated file, add the HAL_GPIO_EXTI_Callback implementation there.
*/

#include "stm32f4xx_it.h"
#include "main.h"
#include "ads131m08.h"

void SysTick_Handler(void)
{
  HAL_IncTick();
}

void EXTI0_IRQHandler(void)
{
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);
}

/* Place this in your project (CubeMX may already generate it). */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == GPIO_PIN_0) {
        ADS131M08_DataReadyHandler();
    }
}
