ADS131M08 STM32F4 Project - README
=================================

What this ZIP contains
- Core/Src/main.c            : Example main that integrates ADS131M08 driver.
- Core/Src/ads131m08.c      : Driver implementation (basic).
- Core/Inc/ads131m08.h      : Driver header.
- Core/Src/stm32f4xx_it.c   : Minimal interrupt handler snippet.
- README.md                 : This file.

Goal
----
A ready-to-integrate code bundle you can drop into an STM32CubeIDE project for the
STM32F407VGT6 Discovery board and use with the ADS131M08EVM (PHI removed and EVM powered by 3.3V).

Quick CubeMX / STM32CubeIDE Setup
---------------------------------
1. Create new STM32 Project:
   - MCU: STM32F407VGTx
   - Board: STM32F4-Discovery (or correct MCU variant)

2. In CubeMX:
   - Enable SPI1 as Full‑Duplex Master:
     * Mode: Master
     * Direction: Full Duplex
     * Data Size: 8 bit
     * Clock Polarity: Low
     * Clock Phase: 2nd Edge (CPOL=0, CPHA=1) => SPI Mode 1
     * NSS: Software
     * Baud Rate Prescaler: e.g., 32 (to get ~1 MHz for 168 MHz system; adjust as needed)

   - Configure PA5=SCK, PA6=MISO, PA7=MOSI (default SPI1 pins)
   - Configure PA4 as GPIO Output for CS
   - Configure PB0 as GPIO_EXTI (falling edge) for DRDY

   - Optionally enable USART2 for UART logging (PA2/PA3).

3. Generate code and open project in STM32CubeIDE.

4. Replace or merge generated files:
   - Copy Core/Src/ads131m08.c -> Core/Src/
   - Copy Core/Inc/ads131m08.h -> Core/Inc/
   - Merge main.c provided here with generated main.c (or replace after confirming peripheral init functions are present).
   - Add the EXTI callback from stm32f4xx_it.c into your generated ISR file if not present.

5. Adjust pin defines in main.c to match your CubeMX mapping if you selected different pins.

Wiring (STM32F4 Discovery -> ADS131M08EVM J11)
----------------------------------------------
- PA7 (MOSI) -> J11.5 (MOSI)
- PA6 (MISO) -> J11.7 (MISO)
- PA5 (SCK)  -> J11.9 (SCLK)
- PA4 (CS)   -> J11.11 (CS)
- PB0 (DRDY) -> J11.13 (DRDY)
- GND        -> J11.1 (GND)
- DVDD (3.3V)-> J11.3 (DVDD)
- AVDD (3.3V)-> J11.2 (AVDD)

Notes & Tips
------------
- Power the EVM with 3.3V on AVDD and DVDD when PHI is removed.
- Use a logic analyzer if transfers fail; check SPI mode and CS timing.
- This bundle is a starting point: add thread-safety, buffering, and UART/SD streaming as needed.

If you want, I can now:
- Build a full .zip that you can download (containing the files above).  <-- I already produced this.
- Generate a complete STM32CubeMX .ioc file (takes extra time and exact pin choices).
- Add UART streaming/CSV output or FreeRTOS integration.

Happy to extend — tell me what extra you'd like.
