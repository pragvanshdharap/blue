// ads131m08.h - Dual ADS131M08 driver (SPI1 + SPI2)
#ifndef __ADS131M08_H
#define __ADS131M08_H

#include "stm32f4xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

#define ADS131M08_FRAME_BYTES 27
#define ADS131M08_NUM_CHANNELS 8

// === Commands ===
#define CMD_RESET       0x0011
#define CMD_UNLOCK      0x0655
#define CMD_LOCK        0x0555
#define CMD_RDATA       0x0012
#define CMD_WREG        0x6000
#define CMD_RREG        0x2000

// Registers
#define REG_CH_EN       0x40
#define REG_CONFIG1     0x01

typedef struct {
    SPI_HandleTypeDef *hspi;
    GPIO_TypeDef* cs_port;
    uint16_t cs_pin;
    uint16_t drdy_pin;           // DRDY GPIO pin (e.g. GPIO_PIN_0)
    GPIO_TypeDef* drdy_port;     // DRDY port (e.g. GPIOB)
    uint8_t rx_buf[ADS131M08_FRAME_BYTES];
    int32_t channels[ADS131M08_NUM_CHANNELS];
    volatile bool new_data;      // set true when new frame parsed
} ADS131M08_HandleTypeDef;

/* Initialize a device handle (does not power or change CubeMX) */
void ADS131M08_Init(ADS131M08_HandleTypeDef *dev);

/* Basic commands using dev's SPI & CS */
void ADS131M08_SendCmd(ADS131M08_HandleTypeDef *dev, uint16_t cmd);
void ADS131M08_WriteReg(ADS131M08_HandleTypeDef *dev, uint8_t addr, uint16_t data);
void ADS131M08_ReadData(ADS131M08_HandleTypeDef *dev);
void ADS131M08_ParseSamples(ADS131M08_HandleTypeDef *dev);

/* Combined helpers */
void ADS131M08_ConfigureDefault(ADS131M08_HandleTypeDef *dev);

/* DRDY handler to call from EXTI callback */
void ADS131M08_DataReadyHandler(ADS131M08_HandleTypeDef *dev);

/* Conversion helpers */
float ADS131M08_RawToVoltage(int32_t rawValue, float vref, float gain);
float VoltageToG(float voltage, float zero_g_voltage, float sensitivity_v_per_g);

#endif
