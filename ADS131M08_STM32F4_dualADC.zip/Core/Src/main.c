/* main.c - Example showing two ADS131M08 devices on SPI1 and SPI2
   Wiring (suggested):
   ADC1 -> SPI1 (PA5/PA6/PA7), CS PA4, DRDY PB0
   ADC2 -> SPI2 (PB13/PB14/PB15), CS PB12, DRDY PB1
*/

#include "main.h"
#include "ads131m08.h"
#include <string.h>
#include <stdio.h>

extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern UART_HandleTypeDef huart2;

/* Device handles (visible to EXTI handler as externs) */
ADS131M08_HandleTypeDef hadc1;
ADS131M08_HandleTypeDef hadc2;

void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART2_UART_Init(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();
    MX_USART2_UART_Init();

    HAL_Delay(100);

    // Initialize device handle structures
    hadc1.hspi = &hspi1;
    hadc1.cs_port = GPIOA;
    hadc1.cs_pin = GPIO_PIN_4;
    hadc1.drdy_port = GPIOB;
    hadc1.drdy_pin = GPIO_PIN_0;
    ADS131M08_Init(&hadc1);

    hadc2.hspi = &hspi2;
    hadc2.cs_port = GPIOB;
    hadc2.cs_pin = GPIO_PIN_12;
    hadc2.drdy_port = GPIOB;
    hadc2.drdy_pin = GPIO_PIN_1;
    ADS131M08_Init(&hadc2);

    // Configure both ADCs (register writes)
    ADS131M08_ConfigureDefault(&hadc1);
    ADS131M08_ConfigureDefault(&hadc2);

    // Main loop: when new_data is set by DRDY callbacks, consume and print
    char msg[160];
    float vref = 2.4f;
    float gain = 1.0f;

    while (1) {
        if (hadc1.new_data) {
            hadc1.new_data = false;
            for (int ch = 0; ch < ADS131M08_NUM_CHANNELS; ch++) {
                float v = ADS131M08_RawToVoltage(hadc1.channels[ch], vref, gain);
                int len = snprintf(msg, sizeof(msg), "ADC1 CH%d raw=%ld V=%.6f\r\n", ch, (long)hadc1.channels[ch], v);
                HAL_UART_Transmit(&huart2, (uint8_t*)msg, len, HAL_MAX_DELAY);
            }
        }
        if (hadc2.new_data) {
            hadc2.new_data = false;
            for (int ch = 0; ch < ADS131M08_NUM_CHANNELS; ch++) {
                float v = ADS131M08_RawToVoltage(hadc2.channels[ch], vref, gain);
                int len = snprintf(msg, sizeof(msg), "ADC2 CH%d raw=%ld V=%.6f\r\n", ch, (long)hadc2.channels[ch], v);
                HAL_UART_Transmit(&huart2, (uint8_t*)msg, len, HAL_MAX_DELAY);
            }
        }
        HAL_Delay(5); // small delay to yield CPU
    }
}

/* Weak generated functions */
void SystemClock_Config(void) { /* CubeMX generated */ }
static void MX_GPIO_Init(void) { /* CubeMX generated: ensure PB0 and PB1 set as EXTI falling edge, PA4 output, PB12 output */ }
static void MX_SPI1_Init(void) { /* CubeMX generated */ }
static void MX_SPI2_Init(void) { /* CubeMX generated */ }
static void MX_USART2_UART_Init(void) { /* CubeMX generated */ }
