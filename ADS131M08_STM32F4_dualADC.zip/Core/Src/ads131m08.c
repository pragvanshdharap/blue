// ads131m08.c - Dual ADS131M08 driver implementation
#include "ads131m08.h"
#include "main.h"
#include <string.h>

static void CS_Select(ADS131M08_HandleTypeDef *dev) {
    HAL_GPIO_WritePin(dev->cs_port, dev->cs_pin, GPIO_PIN_RESET);
}
static void CS_Deselect(ADS131M08_HandleTypeDef *dev) {
    HAL_GPIO_WritePin(dev->cs_port, dev->cs_pin, GPIO_PIN_SET);
}

void ADS131M08_Init(ADS131M08_HandleTypeDef *dev) {
    CS_Deselect(dev);
    dev->new_data = false;
    memset(dev->rx_buf, 0, ADS131M08_FRAME_BYTES);
    memset(dev->channels, 0, sizeof(dev->channels));
    HAL_Delay(5);
}

void ADS131M08_SendCmd(ADS131M08_HandleTypeDef *dev, uint16_t cmd) {
    uint8_t tx[2] = { (uint8_t)(cmd >> 8), (uint8_t)(cmd & 0xFF) };
    CS_Select(dev);
    HAL_SPI_Transmit(dev->hspi, tx, 2, HAL_MAX_DELAY);
    CS_Deselect(dev);
}

void ADS131M08_WriteReg(ADS131M08_HandleTypeDef *dev, uint8_t addr, uint16_t data) {
    uint16_t cmd = CMD_WREG | (addr & 0x7F);
    uint8_t tx[4];
    tx[0] = (uint8_t)(cmd >> 8);
    tx[1] = (uint8_t)(cmd & 0xFF);
    tx[2] = (uint8_t)(data >> 8);
    tx[3] = (uint8_t)(data & 0xFF);
    CS_Select(dev);
    HAL_SPI_Transmit(dev->hspi, tx, 4, HAL_MAX_DELAY);
    CS_Deselect(dev);
}

void ADS131M08_ReadData(ADS131M08_HandleTypeDef *dev) {
    CS_Select(dev);
    HAL_SPI_Receive(dev->hspi, dev->rx_buf, ADS131M08_FRAME_BYTES, HAL_MAX_DELAY);
    CS_Deselect(dev);
}

void ADS131M08_ParseSamples(ADS131M08_HandleTypeDef *dev) {
    // rx_buf layout: 0-2 status, 3-5 ch1, 6-8 ch2, ... 24-26 ch8
    for (int i = 0; i < ADS131M08_NUM_CHANNELS; i++) {
        uint8_t *ch = &dev->rx_buf[3 + i * 3];
        int32_t val = ((int32_t)ch[0] << 16) | ((int32_t)ch[1] << 8) | ((int32_t)ch[2]);
        if (val & 0x800000) val |= 0xFF000000; // sign-extend
        dev->channels[i] = val;
    }
    dev->new_data = true;
}

void ADS131M08_DataReadyHandler(ADS131M08_HandleTypeDef *dev) {
    // Called from EXTI callback when DRDY falls for this device
    ADS131M08_ReadData(dev);
    ADS131M08_ParseSamples(dev);
    // Note: keep handler short. If heavy processing needed, set a flag and handle in main loop or a task.
}

void ADS131M08_ConfigureDefault(ADS131M08_HandleTypeDef *dev) {
    ADS131M08_SendCmd(dev, CMD_RESET);
    HAL_Delay(2);
    ADS131M08_SendCmd(dev, CMD_UNLOCK);
    HAL_Delay(1);

    // CONFIG1: default 500 SPS
    ADS131M08_WriteReg(dev, 0x01, 0x0600);

    // CHxSET: normal input, gain=1
    for (uint8_t ch = 0x05; ch <= 0x0C; ch++) {
        ADS131M08_WriteReg(dev, ch, 0x0000);
    }

    // Enable all 8 channels
    ADS131M08_WriteReg(dev, REG_CH_EN, 0x00FF);

    ADS131M08_SendCmd(dev, CMD_LOCK);
}

float ADS131M08_RawToVoltage(int32_t rawValue, float vref, float gain) {
    const float maxCode = (float)(1 << 23); // 2^23
    return ((float)rawValue) * (vref / gain) / maxCode;
}

float VoltageToG(float voltage, float zero_g_voltage, float sensitivity_v_per_g) {
    return (voltage - zero_g_voltage) / sensitivity_v_per_g;
}
