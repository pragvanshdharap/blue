/* stm32f4xx_it.c - EXTI handlers for DRDY pins
   Make sure CubeMX maps PB0 -> EXTI0, PB1 -> EXTI1 and enables NVIC.
*/

#include "stm32f4xx_it.h"
#include "main.h"
#include "ads131m08.h"

/* hadc1 and hadc2 are defined in main.c */
extern ADS131M08_HandleTypeDef hadc1;
extern ADS131M08_HandleTypeDef hadc2;

void SysTick_Handler(void)
{
  HAL_IncTick();
}

void EXTI0_IRQHandler(void)
{
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);
}

void EXTI1_IRQHandler(void)
{
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_1);
}

/* Place this in your project (CubeMX may already generate it). */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == hadc1.drdy_pin) {
        ADS131M08_DataReadyHandler(&hadc1);
    } else if (GPIO_Pin == hadc2.drdy_pin) {
        ADS131M08_DataReadyHandler(&hadc2);
    }
}
