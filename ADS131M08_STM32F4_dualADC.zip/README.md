README - Dual ADS131M08 (SPI1 + SPI2) Project
============================================

Files:
- Core/Inc/ads131m08.h
- Core/Src/ads131m08.c
- Core/Src/main.c
- Core/Src/stm32f4xx_it.c

What changed:
- Driver rewritten to support multiple device instances (ADS131M08_HandleTypeDef).
- Example shows hadc1 -> SPI1 (ADC1) and hadc2 -> SPI2 (ADC2).
- DRDY falling edges (PB0 and PB1) call device-specific handlers which read & parse 27-byte frames.
- main loop prints per-board, per-channel data labeled "ADC1 CHx" / "ADC2 CHx".

CubeMX notes:
- Configure SPI1 pins: PA5=SCK, PA6=MISO, PA7=MOSI
- Configure SPI2 pins: PB13=SCK, PB14=MISO, PB15=MOSI
- Configure PA4 as GPIO output (ADC1 CS).
- Configure PB12 as GPIO output (ADC2 CS).
- Configure PB0 and PB1 as External Interrupt (EXTI) lines, falling edge.
- Enable USART2 for logging if desired (PA2/PA3).

Wiring:
ADC1 (J11) -> STM32: MOSI PA7, MISO PA6, SCLK PA5, CS PA4, DRDY PB0.
ADC2 (J11) -> STM32: MOSI PB15, MISO PB14, SCLK PB13, CS PB12, DRDY PB1.
Both ADCs: AVDD/DVDD = 3.3V, GND common.

Usage:
- Import into CubeMX/STM32CubeIDE.
- Merge/replace peripheral init functions as needed.
- Build & flash.

If you want, I can:
- Produce a CubeMX .ioc file with these exact pins.
- Convert the read/print flow to DMA-based SPI or FreeRTOS task.
