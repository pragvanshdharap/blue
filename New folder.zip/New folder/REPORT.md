Good question. Let me trace **exactly where** "Expected V" appears and what needs changing:

---

## Files that need changes:

### 1. **mainwindow.ui** (already done per your images)
- Object name: `expectedValue` → `expectedMV` ✓
- Button text: "Expected V" → "Expected MV" ✓

### 2. **mainwindow.h** — For consistency (optional but recommended)
```cpp
// Currently:
void onExpectedValueClicked();

// Should be:
void onExpectedMVClicked();
```
**Why:** The slot name should match the button purpose. Not required for compilation, but keeps maintenance clear.

### 3. **mainwindow.cpp** — TWO places
```cpp
// Line 58 - connect() call:
// Currently:
connect(ui->expectedMV, &QPushButton::clicked,
        this, &MainWindow::onExpectedValueClicked);

// Should be:
connect(ui->expectedMV, &QPushButton::clicked,
        this, &MainWindow::onExpectedMVClicked);

// Line 241 - slot implementation:
// Currently:
void MainWindow::onExpectedValueClicked()

// Should be:
void MainWindow::onExpectedMVClicked()
```

### 4. **protocol.h** — Check comments (minimal)
- Any comments that say "Expected V" or reference the button — update to "Expected MV"
- But the protocol constants themselves don't change (they're protocol-level, not UI-level)

### 5. **Context/Documentation** (not code, but good practice)
- Update `VELOCITY_RADAR_COMPLETE_CONTEXT.md` to reflect `expectedMV` instead of `expectedValue`

---

## Same for "Transmit Last V" → "Transmit Last MV":

**mainwindow.h:**
```cpp
void onTransmitLastModeClicked();  → void onTransmitLastMVClicked();
```

**mainwindow.cpp:**
- Line 73 connect() call
- Line 287 slot implementation

---

## **Summary: 3 files need code changes**

1. **mainwindow.ui** ✓ (already done)
2. **mainwindow.h** — 2 slot declarations (expectedMV + lastMV)
3. **mainwindow.cpp** — 4 places (2 connects + 2 slot definitions)

**Total edits: ~6 locations** across 2 files (plus documentation).










**2 Critical bugs that will block hardware testing:**

1. **Header bytes are `0x41 0x42` (A B) instead of `0x4D 0x56` (M V)** in `protocol.h`. The VR firmware expects M V — every frame you send will be ignored, and every response will fail to parse. The wire examples in Rules.md still show `41 42` which is why this slipped through, but the Frame Structure section and the Implementation Status section both say M V is correct.

2. **Device-presence handshake was removed** from `serialcomm.cpp`. The Rules.md specifies a TXMT_PARAMS probe with 2s timeout before emitting `portOpened`, but the code skips straight to `State::Connected` and emits `portOpened` immediately. Connecting to a port with nothing attached will show "Connected" — the exact false-success scenario the handshake was designed to prevent.

**2 Medium issues (state gating):**

- `transmitLastMV` is enabled during MEASURING, but the spec says only STOP_MEASURE is accepted (firmware will NACK it)
- `performMVPTest` and `transmitTestResults` are enabled during SYSTEM_TEST, but the spec only allows PERFORM_SYSTEM_TEST and EXIT_SYSTEM_TEST

**Everything else passed** — 33 checks covering checksums, wire formats, parsing, timeouts, state transitions, button wiring, and more. The architecture is solid; just those two critical values need fixing before you connect to real hardware.


----
I'll fix every file. Let me work through them systematically.## 🔴 CRIT-1: Fix Header Bytes — protocol.h## 🔴 CRIT-1: Fix Header Comments — messagebuilder.h## 🔴 CRIT-1: Fix Header Comments — messagebuilder.cpp## 🔴 CRIT-1: Fix Header Comments — messageparser.h## 🔴 CRIT-1: Fix Header Comments — messageparser.cpp## 🔴 CRIT-2: Restore Device-Presence Handshake — serialcomm.cpp## 🔴 CRIT-2: Update serialcomm.h comment## 🟡 MED-1: Fix Button State Gating — mainwindow.cppGood — no stale `0x41`/`0x42` references remain in any file. Let me verify the critical edits look correct:All fixes applied. Let me package everything:All fixes verified. Let me package and present:All 14 files are in the zip. Here's what was changed in each and what you need to do manually in the `.ui`:

---

## Changes Per File

| File | What Changed |
|---|---|
| **protocol.h** | `HEADER_1 = 0x4D`, `HEADER_2 = 0x56` (was 0x41/0x42) |
| **messagebuilder.h** | All wire comments updated: `[4D][56]` and `[0x4D][0x56]` |
| **messagebuilder.cpp** | All wire comments updated: `4D 56`, inline comments `// 0x4D`, `// 0x56` |
| **messageparser.h** | State machine comments: scans for `0x4D ('M')`, expects `0x56 ('V')` |
| **messageparser.cpp** | All state machine comments updated: `'M'`/`'V'` throughout |
| **serialcomm.h** | Updated docblock to document the restored handshake sequence |
| **serialcomm.cpp** | **Restored full handshake:** `openPort()` → Handshaking → sends TXMT_PARAMS probe → 2s timer. `onParserMessage()` promotes to Connected on valid frame. `onHandshakeTimeout()` closes port + emits `portError`. |
| **mainwindow.cpp** | **Fixed button gating:** `transmitLastMV` → IDLE only. `performMVPTest` + `transmitTestResults` → IDLE only. `stopMeasure` → MEASURING only. `performSystemTest` + `exitSystemTestMode` → SYSTEM_TEST only. |
| **mainwindow.h** | No changes needed |
| **expectedvdialog.h/.cpp** | No changes needed |
| **main.cpp** | No changes needed |
| **CMakeLists.txt** | No changes needed |

---

## 🔵 What YOU Need to Fix in `mainwindow.ui` (Qt Designer)

Open `mainwindow.ui` in Qt Designer and make these 3 changes:

**1. BAUD_RATE combo — remove the 115200 option**

Select the `BAUD_RATE` QComboBox → Edit Items → **delete "115200"**, keep only "9600". The baud rate is fixed at 9600 per the protocol spec; having 115200 misleads the operator.

**2. COM_PORT combo — remove stale placeholder items**

Select the `COM_PORT` QComboBox → Edit Items → **delete all 4 items** ("COM 1", "COM 2", "COM 3", "COM 4"). The code's `populateComPorts()` clears and repopulates with real ports at runtime anyway, and the hardcoded items have wrong format (space in "COM 1" vs expected "COM1").

**3. (Optional) Rename misleading widget text on `transmitTestResults` button**

The button text currently says "Transmt MVP Test Results" (typo: "Transmt" → "Transmit"). Fix the display text to "Transmit MVP Test Results".

---

That's everything — drop the `VR_FIXED/src/` files into your project's `src/` folder, rebuild, and you're ready for hardware testing.