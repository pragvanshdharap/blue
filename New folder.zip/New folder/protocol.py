"""
VELOCITY RADAR — Protocol Definition (Layer 1)

All message codes, timing constants, data ranges, and bit flag definitions.
Every other file imports this.

Reference: Interface Specification Document
"""

from enum import Enum

# ==========================================================================
#  Frame Structure
# ==========================================================================
HEADER_1 = 0x41   # 'A'
HEADER_2 = 0x42   # 'B'

# ==========================================================================
#  Command Codes (PC → Embedded System)
# ==========================================================================
CMD_EXPECTED_V            = 102
CMD_MEASURE               = 103
CMD_STOP_MEASURE          = 104
CMD_TXMT_LAST_V           = 105
CMD_PARALLAX              = 106
CMD_TXMT_PARAMS           = 107
CMD_ENTER_SYSTEM_TEST     = 108
CMD_PERFORM_SYSTEM_TEST   = 109
CMD_EXIT_SYSTEM_TEST      = 110
CMD_PERFORM_MVP_TEST      = 111
CMD_TXMT_MVP_TEST_RESULTS = 112

# ==========================================================================
#  Response Codes (Embedded System → PC)
# ==========================================================================
RSP_LAST_V              = 200
RSP_PARAMS              = 201
RSP_SYSTEM_TEST_RESULTS = 212
RSP_ACK                 = 254
RSP_NACK                = 255

# ==========================================================================
#  Timing Constants (milliseconds)
# ==========================================================================
TIMEOUT_RESPONSE_MS      = 2000
TIMEOUT_SYSTEM_TEST_MS   = 5000
TIMEOUT_INTER_BYTE_MS    = 1000

# ==========================================================================
#  Data Ranges
# ==========================================================================
EXPECTED_V_MIN = 150
EXPECTED_V_MAX = 1500

PARALLAX_SCALE   = 16
LAST_V_SCALE     = 16
LAST_V_RESULT_OK    = 0
LAST_V_RESULT_ERROR = -1

TRIPOD_BRACKET = 0
TRIPOD_TRIPOD  = 1

# ==========================================================================
#  System Test Bit Flags
# ==========================================================================
TEST_FLAG_RAM           = (1 << 0)
TEST_FLAG_PORTS         = (1 << 1)
TEST_FLAG_SYNT_DOPP     = (1 << 2)
TEST_FLAG_RF_TEST       = (1 << 3)
TEST_FLAG_ACCELEROMETER = (1 << 4)
TEST_FLAG_RF_NOISE      = (1 << 5)

DEFAULT_BAUD_RATE = 9600

# ==========================================================================
#  Power-up Built-In Test (BIT) Timing
# ==========================================================================
TIMEOUT_BIT_MS = 5000   # 5 seconds wait for power-up BIT after connect

# ==========================================================================
#  Measurement Tolerance
# ==========================================================================
MEASUREMENT_TOLERANCE = 100   # ±100 m/s around EXPECTED_V

# ==========================================================================
#  System States
# ==========================================================================
class SystemState(Enum):
    WAITING_FOR_BIT = "WAITING_FOR_BIT"   # 5s window after connect, awaiting auto-BIT
    IDLE            = "IDLE"               # Standby — ready for commands
    MEASURING       = "MEASURING"          # Auto-measuring rounds
    SYSTEM_TEST     = "SYSTEM_TEST"        # In test mode

# ==========================================================================
#  Helpers
# ==========================================================================
_COMMAND_NAMES = {
    CMD_EXPECTED_V:            "EXPECTED_V",
    CMD_MEASURE:               "MEASURE",
    CMD_STOP_MEASURE:          "STOP_MEASURE",
    CMD_TXMT_LAST_V:           "TXMT_LAST_V",
    CMD_PARALLAX:              "PARALLAX",
    CMD_TXMT_PARAMS:           "TXMT_PARAMS",
    CMD_ENTER_SYSTEM_TEST:     "ENTER_SYSTEM_TEST",
    CMD_PERFORM_SYSTEM_TEST:   "PERFORM_SYSTEM_TEST",
    CMD_EXIT_SYSTEM_TEST:      "EXIT_SYSTEM_TEST",
    CMD_PERFORM_MVP_TEST:      "PERFORM_MVP_TEST",
    CMD_TXMT_MVP_TEST_RESULTS: "TXMT_MVP_TEST_RESULTS",
    RSP_ACK:                   "ACK",
    RSP_NACK:                  "NACK",
    RSP_LAST_V:                "LAST_V",
    RSP_PARAMS:                "PARAMS",
    RSP_SYSTEM_TEST_RESULTS:   "SYSTEM_TEST_RESULTS",
}

def command_name(code: int) -> str:
    return _COMMAND_NAMES.get(code, f"UNKNOWN({code})")

def response_timeout(command_code: int) -> int:
    if command_code == CMD_PERFORM_SYSTEM_TEST:
        return TIMEOUT_SYSTEM_TEST_MS
    return TIMEOUT_RESPONSE_MS

def expects_data_response(command_code: int) -> bool:
    return command_code in (
        CMD_TXMT_LAST_V, CMD_TXMT_PARAMS, CMD_PERFORM_SYSTEM_TEST,
        CMD_PERFORM_MVP_TEST, CMD_TXMT_MVP_TEST_RESULTS,
    )

def decode_test_flags(flags: int) -> list:
    if flags == 0x0000:
        return ["ALL TESTS PASSED"]
    failures = []
    if flags & TEST_FLAG_RAM:           failures.append("RAM failure")
    if flags & TEST_FLAG_PORTS:         failures.append("I/O Ports failure")
    if flags & TEST_FLAG_SYNT_DOPP:     failures.append("Synthesizer/Doppler failure")
    if flags & TEST_FLAG_RF_TEST:       failures.append("RF subsystem failure")
    if flags & TEST_FLAG_ACCELEROMETER: failures.append("Accelerometer failure")
    if flags & TEST_FLAG_RF_NOISE:      failures.append("RF noise failure")
    spare_mask = 0xFFC0
    if flags & spare_mask:
        failures.append(f"Unknown flags: 0x{flags & spare_mask:04X}")
    return failures