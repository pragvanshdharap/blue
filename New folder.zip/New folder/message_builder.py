"""
VELOCITY RADAR — Message Builder (Layer 2)

One function per command. Each returns a complete bytes object ready to send:
    [0x41][0x42][SIZE][CODE][DATA...][CHECKSUM]

Checksum: (-sum_of_payload) & 0xFF  (two's complement mod 256)
All multi-byte data fields are LITTLE-ENDIAN (LSB first).
"""

from protocol import *


def _compute_checksum(payload: bytes) -> int:
    """Two's complement checksum over payload bytes."""
    return (-sum(payload)) & 0xFF


def _build_frame(payload: bytes) -> bytes:
    """Build complete frame: HEADER + payload + CHECKSUM."""
    checksum = _compute_checksum(payload)
    return bytes([HEADER_1, HEADER_2]) + payload + bytes([checksum])


# =========================================================================
#  Command Builders
# =========================================================================

def build_expected_v(velocity: int) -> bytes:
    """CMD 102: EXPECTED_V — Set expected velocity (150–1500).
    Wire: ['A']['B'][05][66][V_LO][V_HI][CHECKSUM]"""
    v_lo = velocity & 0xFF
    v_hi = (velocity >> 8) & 0xFF
    return _build_frame(bytes([5, CMD_EXPECTED_V, v_lo, v_hi]))


def build_measure() -> bytes:
    """CMD 103: MEASURE — Enter measure mode.
    Wire: ['A']['B'][03][67][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_MEASURE]))


def build_stop_measure() -> bytes:
    """CMD 104: STOP_MEASURE — Exit measure mode.
    Wire: ['A']['B'][03][68][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_STOP_MEASURE]))


def build_txmt_last_v() -> bytes:
    """CMD 105: TXMT_LAST_V — Request last velocity.
    Wire: ['A']['B'][02][69][CHECKSUM]"""
    return _build_frame(bytes([2, CMD_TXMT_LAST_V]))


def build_parallax(tripod: int, x: int, y: int, z: int) -> bytes:
    """CMD 106: PARALLAX — Set parallax parameters.
    Wire: ['A']['B'][07][6A][TRIPOD][X][Y][Z][CHECKSUM]"""
    return _build_frame(bytes([7, CMD_PARALLAX, tripod, x, y, z]))


def build_txmt_params() -> bytes:
    """CMD 107: TXMT_PARAMS — Request current parameters.
    Wire: ['A']['B'][03][6B][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_TXMT_PARAMS]))


def build_enter_system_test() -> bytes:
    """CMD 108: ENTER_SYSTEM_TEST.
    Wire: ['A']['B'][03][6C][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_ENTER_SYSTEM_TEST]))


def build_perform_system_test() -> bytes:
    """CMD 109: PERFORM_SYSTEM_TEST (~5 second response).
    Wire: ['A']['B'][03][6D][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_PERFORM_SYSTEM_TEST]))


def build_exit_system_test() -> bytes:
    """CMD 110: EXIT_SYSTEM_TEST.
    Wire: ['A']['B'][03][6E][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_EXIT_SYSTEM_TEST]))


def build_perform_mvp_test() -> bytes:
    """CMD 111: PERFORM_MVP_TEST.
    Wire: ['A']['B'][03][6F][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_PERFORM_MVP_TEST]))


def build_txmt_mvp_test_results() -> bytes:
    """CMD 112: TXMT_MVP_TEST_RESULTS.
    Wire: ['A']['B'][03][70][CHECKSUM]"""
    return _build_frame(bytes([3, CMD_TXMT_MVP_TEST_RESULTS]))
