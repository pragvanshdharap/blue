# Velocity Radar GUI — Verification Report
### Code vs Rules.md Compliance Audit
**Date:** 2026-06-09

---

## CRITICAL ISSUES (2)

### 🔴 CRIT-1: Frame Header Bytes Are Wrong (protocol.h)

**Rule (Rules.md, Frame Structure):**
> `HEADER_1 = 0x4D ('M')`, `HEADER_2 = 0x56 ('V')`
> "Frame starts with these two bytes; any other pattern resets the receiver"

**Code (protocol.h, lines 29–30):**
```cpp
constexpr uint8_t HEADER_1 = 0x41;  // 'A'   ← WRONG
constexpr uint8_t HEADER_2 = 0x42;  // 'B'   ← WRONG
```

**Impact:** Every frame the GUI sends will start with `0x41 0x42` instead of `0x4D 0x56`. The VR firmware will never recognize any command — the receiver will continuously reset and scan for `M V`, which never arrives. **The entire system is non-functional.**

This also propagates through:
- `messagebuilder.cpp` → `wrapFrame()` prepends wrong headers
- `messageparser.cpp` → state machine scans for wrong header pattern
- All comments across all files reference `0x41`/`0x42`

**Fix:** Change protocol.h:
```cpp
constexpr uint8_t HEADER_1 = 0x4D;  // 'M'
constexpr uint8_t HEADER_2 = 0x56;  // 'V'
```

**Note:** The wire examples *inside Rules.md itself* still show `41 42` (e.g., `41 42 03 67 96` for MEASURE). These examples are stale — they weren't updated when the header changed. The Frame Structure section at the top of Rules.md is the authoritative definition. The Rules.md's own "Implementation Status" section (line 505) also confirms: `HEADER_1 = 0x4D, HEADER_2 = 0x56`.

---

### 🔴 CRIT-2: Device-Presence Handshake Removed (serialcomm.cpp)

**Rule (Rules.md, Layer 4 specification, lines 588–615):**
> `openPort()` runs a protocol-level presence check before reporting success:
> 1. CreateFile on `\\.\COMx`
> 2. DCB configured, buffers purged, parser reset
> 3. State → **Handshaking**. Poll timer started.
> 4. **TXMT_PARAMS (code 107) is sent as the probe**
> 5. A **2-second handshake timer** is armed
> 6. First valid framed reply → State = Connected, emit `portOpened`
> 7. If 2s elapses with no valid frame → close port, emit `portError`
>
> "clicking Connect on a port with no hardware now correctly fails with a timeout instead of a false success."

**Code (serialcomm.cpp, openPort(), lines 63–82):**
```cpp
// Comment says: "we do NOT send a probe here"
m_state = State::Connected;        // ← Skips Handshaking entirely
m_pollTimer->start();
emit portOpened(portName);         // ← Immediate success, no verification
```

**Impact:** Connecting to a COM port with no VR hardware attached will report "Connected" — exactly the false-success bug the handshake was designed to prevent. The `State::Handshaking` enum value exists in the header but is never used. The `onHandshakeTimeout()` slot is a no-op stub.

The current design delegates BIT-waiting to MainWindow (5s timer for unsolicited SYSTEM_TEST_RESULTS), but that's a *separate concern* — it doesn't verify device presence. A port with no hardware will show "Connected" for 5 seconds, then say "unit likely already running" and enable all command buttons.

**Fix:** Restore the handshake sequence in `openPort()`:
1. After configuring DCB, set `m_state = State::Handshaking`
2. Start poll timer
3. Send `MessageBuilder::buildTxmtParams()` as probe
4. Arm `m_handshakeTimer` for 2000ms
5. In `onParserMessage()`: if state == Handshaking, promote to Connected, emit `portOpened`, consume the reply
6. In `onHandshakeTimeout()`: close port, emit `portError("No response from device")`

---

## MEDIUM ISSUES (2)

### 🟡 MED-1: Button State Gating Violates State Restrictions

**Rule (Rules.md, State Restrictions):**
> **MEASURING mode:** System ignores all messages EXCEPT STOP_MEASURE.
> Any other command during measurement → NACK (state conflict).
>
> **SYSTEM_TEST mode:** System only accepts PERFORM_SYSTEM_TEST and EXIT_SYSTEM_TEST.
> Any other command in test mode → NACK.

**Code (mainwindow.cpp, updateButtonStates(), lines 174–180):**
```cpp
// These buttons are ENABLED during MEASURING — but firmware will NACK them:
ui->transmitLastMV->setEnabled(canSend && measuring);   // ← NACK guaranteed

// These buttons are ENABLED during SYSTEM_TEST — but firmware will NACK them:
ui->performMVPTest->setEnabled(canSend && testing);      // ← NACK guaranteed
ui->transmitTestResults->setEnabled(canSend && testing); // ← NACK guaranteed
```

**Impact:** Users can press buttons that will always be NACKed by the firmware, causing confusion. The GUI should prevent sending commands the firmware will reject.

**Fix for MEASURING state:**
```cpp
// Only STOP_MEASURE should be enabled during MEASURING
ui->stopMeasure->setEnabled(canSend && measuring);
ui->transmitLastMV->setEnabled(false);  // Firmware NACKs this in MEASURING
```
*(Note: LAST_V arrives automatically during measurement — no need to request it.)*

**Fix for SYSTEM_TEST state:**
```cpp
// Only PERFORM_SYSTEM_TEST and EXIT_SYSTEM_TEST in SYSTEM_TEST mode
ui->performSystemTest->setEnabled(canSend && testing);
ui->exitSystemTestMode->setEnabled(canSend && testing);
ui->performMVPTest->setEnabled(false);       // Not accepted in SYSTEM_TEST
ui->transmitTestResults->setEnabled(false);  // Not accepted in SYSTEM_TEST
```

**Caveat:** If the firmware actually accepts MVP commands in SYSTEM_TEST mode (undocumented behavior), then Rules.md should be updated to reflect that. But as written, the code violates the spec.

---

### 🟡 MED-2: Rules.md Widget Names Don't Match Actual .ui File

**Rule (Rules.md, Layer 5 widget table, lines 635–640):**

| Rules.md says | Actual .ui name | Code connects to |
|---|---|---|
| `expectedValue` | `expectedMV` | `expectedMV` ✓ |
| `transmitLastMode` | `transmitLastMV` | `transmitLastMV` ✓ |

**Impact:** The code is correct (connects to actual .ui names). But Rules.md is stale — anyone reading it would expect `expectedValue` and `transmitLastMode` as widget names. Not a runtime bug, but a documentation-vs-reality mismatch that will cause confusion during maintenance.

**Fix:** Update Rules.md widget table to match actual .ui names: `expectedMV` and `transmitLastMV`.

---

## LOW ISSUES (3)

### 🔵 LOW-1: BAUD_RATE Combo Box Is Misleading

The `mainwindow.ui` has BAUD_RATE with two items: `9600` and `115200`. But the spec (and `serialcomm.cpp`) hardcodes 9600 baud. The `115200` option is non-functional and misleading.

**Fix:** Either remove the 115200 item from the .ui, or disable/hide the BAUD_RATE combo entirely and show "9600" as a label.

---

### 🔵 LOW-2: .ui COM_PORT Has Stale Placeholder Items

The .ui has hardcoded items "COM 1", "COM 2", "COM 3", "COM 4" (note the space). At runtime `populateComPorts()` clears these and repopulates with real ports (e.g., "COM1" without space). No runtime bug, but the stale .ui items could confuse Designer users.

**Fix:** Remove the hardcoded items from the .ui — let `populateComPorts()` handle everything.

---

### 🔵 LOW-3: Rules.md Wire Examples Use Old Headers

Every wire example in Rules.md shows `41 42` (old A B headers), but the frame structure section defines `0x4D 0x56` (M V). Several example checksums are also wrong (e.g., TXMT_PARAMS shows `9A`, correct is `92`). These are documentation errors, not code errors, but they will mislead anyone cross-checking.

---

## PASSED CHECKS ✅

| Check | Verdict |
|---|---|
| All 11 command codes (102–112) defined correctly | ✅ PASS |
| All 5 response codes (200, 201, 212, 254, 255) defined correctly | ✅ PASS |
| SIZE values match spec for every message | ✅ PASS |
| Checksum formula: `(-sum) & 0xFF` | ✅ PASS |
| Checksum verification: `sum % 256 == 0` | ✅ PASS |
| Little-endian encoding for multi-byte fields | ✅ PASS |
| EXPECTED_V range validation 150–1500 | ✅ PASS |
| PARALLAX range validation (tripod 0/1, offsets 0–160) | ✅ PASS |
| LAST_V decode: result byte + raw/16.0 conversion | ✅ PASS |
| PARAMS decode: 6 data bytes, LE velocity + tripod + offsets | ✅ PASS |
| SYSTEM_TEST_RESULTS decode: LE flags, bit definitions 0–5 | ✅ PASS |
| ACK/NACK decode: extracts acknowledged/rejected command code | ✅ PASS |
| Response timeout: 2s standard, 5s for PERFORM_SYSTEM_TEST | ✅ PASS |
| `expectsDataResponse()` covers all 5 data-response commands | ✅ PASS |
| Inter-byte timeout: 1s, single-shot, restarted on each byte | ✅ PASS |
| Parser state machine: WAIT_HEADER_1 → WAIT_HEADER_2 → WAIT_SIZE → COLLECTING | ✅ PASS |
| False-header recovery: 0x4D in WAIT_HEADER_2 stays (treats as new H1) | ✅ PASS* |
| Invalid byte in WAIT_HEADER_2 → reset to WAIT_HEADER_1 | ✅ PASS* |
| SIZE range check: 2–255 | ✅ PASS |
| `ParsedMessage` registered as metatype in main.cpp | ✅ PASS |
| ExpectedVDialog: QSpinBox 150–1500, default 500, " m/s" suffix | ✅ PASS |
| State transitions on ACK: MEASURE→MEASURING, STOP→IDLE, ENTER_TEST→SYSTEM_TEST, EXIT_TEST→IDLE | ✅ PASS |
| EXPECTED_V only committed after ACK (pending → confirmed) | ✅ PASS |
| Power-up BIT: 5s passive listen window, clears on receipt or timeout | ✅ PASS |
| Buttons disabled during BIT window (`m_awaitingBit` gate) | ✅ PASS |
| `sendCommand()` guards: empty frame, not connected, waiting response | ✅ PASS |
| Log colors: SEND=#2196F3, RECV=#4CAF50, ERROR=#F44336, info=#9E9E9E | ✅ PASS |
| Timestamps: hh:mm:ss.zzz format | ✅ PASS |
| Max log blocks: 500 | ✅ PASS |
| Win32 serial: 9600 8N1, no flow control, non-blocking reads, 20ms poll | ✅ PASS |
| Port enumeration via QueryDosDevice COM1–COM255 | ✅ PASS |
| `\\.\` prefix for COM ports (required for COM10+) | ✅ PASS |
| All 13 buttons wired with explicit connect() (Method 2) | ✅ PASS |
| CMake: Qt6 Core/Gui/Widgets, C++17, AUTOUIC/AUTOMOC/AUTORCC | ✅ PASS |

*\* Parser scans for 0x41/0x42 currently — logic is correct but needs header value fix per CRIT-1.*

---

## Summary

| Severity | Count | Action Required |
|---|---|---|
| 🔴 CRITICAL | 2 | Must fix before hardware testing |
| 🟡 MEDIUM | 2 | Should fix to match spec |
| 🔵 LOW | 3 | Cleanup / documentation |
| ✅ PASSED | 33 | No action |

**Bottom line:** The architecture, state machine, parsing logic, checksum math, timing, and GUI wiring are all solid. The two critical issues are (1) wrong header bytes (0x41/0x42 instead of 0x4D/0x56) which will prevent *all* communication with the VR, and (2) the missing device-presence handshake which allows false-connect on empty ports.
