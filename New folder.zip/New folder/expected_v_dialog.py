"""
VELOCITY RADAR — Expected Velocity Input Dialog (Layer 5)

Loads Expected_v.ui from PySide6 Qt Designer.
Validates input: integer in range 150–1500.
"""

import os
from PySide6.QtWidgets import QDialog, QMessageBox
from PySide6.QtCore import QFile
from PySide6.QtUiTools import QUiLoader

from protocol import EXPECTED_V_MIN, EXPECTED_V_MAX


class ExpectedVDialog(QDialog):
    """Dialog for entering expected velocity value."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._velocity = 0

        # Load the .ui file
        ui_path = os.path.join(os.path.dirname(__file__), "ui", "Expected_v.ui")

        if os.path.exists(ui_path):
            # Load from .ui file using QUiLoader
            loader = QUiLoader()
            ui_file = QFile(ui_path)
            ui_file.open(QFile.ReadOnly)
            self._ui_widget = loader.load(ui_file, self)
            ui_file.close()

            # Get widget references from loaded .ui
            self._text_edit = self._ui_widget.findChild(
                __import__('PySide6.QtWidgets', fromlist=['QTextEdit']).QTextEdit,
                "textEdit")
            self._ok_btn = self._ui_widget.findChild(
                __import__('PySide6.QtWidgets', fromlist=['QPushButton']).QPushButton,
                "pushButton")
            self._cancel_btn = self._ui_widget.findChild(
                __import__('PySide6.QtWidgets', fromlist=['QPushButton']).QPushButton,
                "pushButton_2")

            # Fix the "Cancle" typo in button text
            if self._cancel_btn:
                self._cancel_btn.setText("Cancel")

            self.setWindowTitle("Set Expected Velocity")
            self.setFixedSize(self._ui_widget.size())

            # Layout the loaded widget inside this dialog
            from PySide6.QtWidgets import QVBoxLayout
            layout = QVBoxLayout(self)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(self._ui_widget)
        else:
            # Fallback: build programmatically if .ui file not found
            self._build_programmatic()

        # Connect buttons
        if self._ok_btn:
            self._ok_btn.clicked.connect(self._on_ok)
        if self._cancel_btn:
            self._cancel_btn.clicked.connect(self.reject)

    def _build_programmatic(self):
        """Fallback: build dialog in code if .ui file is missing."""
        from PySide6.QtWidgets import (QVBoxLayout, QHBoxLayout,
                                        QLabel, QTextEdit, QPushButton)
        self.setWindowTitle("Set Expected Velocity")
        self.setFixedSize(400, 200)

        title = QLabel(f"Enter Expected Velocity ({EXPECTED_V_MIN}–{EXPECTED_V_MAX}):", self)
        title.setStyleSheet("font-weight: bold; font-size: 11pt;")

        self._text_edit = QTextEdit(self)
        self._text_edit.setFixedHeight(35)
        self._text_edit.setPlaceholderText("e.g. 500")
        self._text_edit.setTabChangesFocus(True)

        hint = QLabel(f"Range: {EXPECTED_V_MIN} – {EXPECTED_V_MAX}", self)
        hint.setStyleSheet("color: #7F8C8D; font-size: 9pt;")

        self._ok_btn = QPushButton("OK", self)
        self._cancel_btn = QPushButton("Cancel", self)
        self._ok_btn.setFixedWidth(90)
        self._cancel_btn.setFixedWidth(90)

        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        btn_layout.addWidget(self._ok_btn)
        btn_layout.addWidget(self._cancel_btn)

        main_layout = QVBoxLayout(self)
        main_layout.addWidget(title)
        main_layout.addWidget(self._text_edit)
        main_layout.addWidget(hint)
        main_layout.addStretch()
        main_layout.addLayout(btn_layout)

    def velocity(self) -> int:
        return self._velocity

    def _on_ok(self):
        text = self._text_edit.toPlainText().strip()

        try:
            value = int(text)
        except ValueError:
            QMessageBox.warning(self, "Invalid Input",
                                "Please enter a valid integer value.")
            self._text_edit.setFocus()
            return

        if value < EXPECTED_V_MIN or value > EXPECTED_V_MAX:
            QMessageBox.warning(self, "Out of Range",
                                f"Expected velocity must be between "
                                f"{EXPECTED_V_MIN} and {EXPECTED_V_MAX}.\n"
                                f"You entered: {value}")
            self._text_edit.setFocus()
            return

        self._velocity = value
        self.accept()
