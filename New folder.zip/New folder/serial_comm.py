"""
VELOCITY RADAR — Serial Communication (Layer 4)

Wraps serial port for async I/O over RS-422.
Feeds incoming bytes to MessageParser automatically.
Manages response timeout timer (2s normal, 5s for PERFORM_SYSTEM_TEST).

Supports TWO backends:
  1. PySide6.QtSerialPort (preferred — async, native Qt integration)
  2. pyserial (fallback — uses QTimer-based polling)

Auto-detects which is available at import time.
"""

import sys
from PySide6.QtCore import QObject, QTimer, Signal

from protocol import *
from message_parser import MessageParser, ParsedMessage

# =========================================================================
#  Backend Detection
# =========================================================================
try:
    from PySide6.QtSerialPort import QSerialPort, QSerialPortInfo
    HAS_QT_SERIAL = True
except ImportError:
    HAS_QT_SERIAL = False

if not HAS_QT_SERIAL:
    try:
        import serial
        import serial.tools.list_ports
        HAS_PYSERIAL = True
    except ImportError:
        HAS_PYSERIAL = False
else:
    HAS_PYSERIAL = False


# =========================================================================
#  SerialComm Class
# =========================================================================

class SerialComm(QObject):
    """Serial communication wrapper with timeout management."""

    # Signals
    message_received  = Signal(object)   # ParsedMessage
    response_timeout  = Signal(int)      # pending command code
    port_opened       = Signal(str, int) # port_name, baud_rate
    port_closed       = Signal()
    port_error        = Signal(str)      # error description
    raw_data_sent     = Signal(bytes)    # for hex logging
    raw_data_received = Signal(bytes)    # for hex logging
    parse_error_sig   = Signal(str)      # parser error

    def __init__(self, parent=None):
        super().__init__(parent)

        self._parser = MessageParser(self)
        self._response_timer = QTimer(self)
        self._response_timer.setSingleShot(True)

        self._pending_command_code = 0
        self._waiting_for_response = False
        self._port_name = ""
        self._baud_rate = DEFAULT_BAUD_RATE
        self._is_open = False

        # Connect parser signals
        self._parser.message_received.connect(self._on_parser_message)
        self._parser.parse_error.connect(self._on_parser_error)

        # Connect timeout
        self._response_timer.timeout.connect(self._on_response_timeout)

        # Backend-specific setup
        if HAS_QT_SERIAL:
            self._serial = QSerialPort(self)
            self._serial.readyRead.connect(self._on_ready_read_qt)
            self._serial.errorOccurred.connect(self._on_serial_error_qt)
            self._backend = "QtSerialPort"
            self._poll_timer = None
        elif HAS_PYSERIAL:
            self._serial = None  # serial.Serial instance, created on open
            self._backend = "pyserial"
            # Poll timer for pyserial (no async readyRead signal)
            self._poll_timer = QTimer(self)
            self._poll_timer.setInterval(20)  # 50 Hz polling
            self._poll_timer.timeout.connect(self._on_poll_pyserial)
        else:
            self._serial = None
            self._backend = "none"
            self._poll_timer = None

    @property
    def backend_name(self) -> str:
        return self._backend

    def is_open(self) -> bool:
        return self._is_open

    def current_port_name(self) -> str:
        return self._port_name

    def current_baud_rate(self) -> int:
        return self._baud_rate

    # =====================================================================
    #  Port Control
    # =====================================================================

    def open_port(self, port_name: str, baud_rate: int) -> bool:
        if self._is_open:
            self.close_port()

        self._port_name = port_name
        self._baud_rate = baud_rate

        if self._backend == "QtSerialPort":
            return self._open_qt(port_name, baud_rate)
        elif self._backend == "pyserial":
            return self._open_pyserial(port_name, baud_rate)
        else:
            self.port_error.emit("No serial backend available. "
                                 "Install PySide6-QtSerialPort or pyserial.")
            return False

    def close_port(self):
        self._response_timer.stop()
        self._waiting_for_response = False
        self._parser.reset()

        if self._backend == "QtSerialPort":
            if self._serial.isOpen():
                self._serial.close()
        elif self._backend == "pyserial":
            if self._poll_timer:
                self._poll_timer.stop()
            if self._serial and self._serial.is_open:
                self._serial.close()
            self._serial = None

        self._is_open = False
        self.port_closed.emit()

    # =====================================================================
    #  Sending
    # =====================================================================

    def send_message(self, message: bytes, command_code: int):
        if not self._is_open:
            self.port_error.emit("Cannot send: serial port is not open")
            return

        if self._backend == "QtSerialPort":
            written = self._serial.write(message)
            if written != len(message):
                self.port_error.emit(
                    f"Write error: sent {written} of {len(message)} bytes")
                return
        elif self._backend == "pyserial":
            try:
                self._serial.write(message)
            except Exception as e:
                self.port_error.emit(f"Write error: {e}")
                return

        self.raw_data_sent.emit(message)

        # Start response timeout
        self._pending_command_code = command_code
        self._waiting_for_response = True
        timeout = response_timeout(command_code)
        self._response_timer.start(timeout)

    # =====================================================================
    #  Port Discovery (static)
    # =====================================================================

    @staticmethod
    def available_ports() -> list:
        if HAS_QT_SERIAL:
            return [info.portName() for info in QSerialPortInfo.availablePorts()]
        elif HAS_PYSERIAL:
            return [p.device for p in serial.tools.list_ports.comports()]
        else:
            return []

    # =====================================================================
    #  QtSerialPort Backend
    # =====================================================================

    def _open_qt(self, port_name, baud_rate):
        self._serial.setPortName(port_name)
        self._serial.setBaudRate(baud_rate)
        self._serial.setDataBits(QSerialPort.DataBits.Data8)
        self._serial.setParity(QSerialPort.Parity.NoParity)
        self._serial.setStopBits(QSerialPort.StopBits.OneStop)
        self._serial.setFlowControl(QSerialPort.FlowControl.NoFlowControl)

        if not self._serial.open(QSerialPort.OpenModeFlag.ReadWrite):
            self.port_error.emit(
                f"Failed to open {port_name}: {self._serial.errorString()}")
            return False

        self._parser.reset()
        self._is_open = True
        self.port_opened.emit(port_name, baud_rate)
        return True

    def _on_ready_read_qt(self):
        data = bytes(self._serial.readAll())
        if data:
            self.raw_data_received.emit(data)
            self._parser.process_bytes(data)

    def _on_serial_error_qt(self, error):
        if error == QSerialPort.SerialPortError.NoError:
            return
        error_map = {
            QSerialPort.SerialPortError.DeviceNotFoundError: "Device not found",
            QSerialPort.SerialPortError.PermissionError: "Permission denied",
            QSerialPort.SerialPortError.OpenError: "Failed to open port",
            QSerialPort.SerialPortError.WriteError: "Write error",
            QSerialPort.SerialPortError.ReadError: "Read error",
            QSerialPort.SerialPortError.ResourceError: "Port disconnected (cable removed?)",
        }
        msg = error_map.get(error, f"Serial error code {error}")
        self.port_error.emit(msg)

        if error == QSerialPort.SerialPortError.ResourceError:
            self._response_timer.stop()
            self._waiting_for_response = False
            self._parser.reset()
            if self._serial.isOpen():
                self._serial.close()
            self._is_open = False
            self.port_closed.emit()

    # =====================================================================
    #  pyserial Backend
    # =====================================================================

    def _open_pyserial(self, port_name, baud_rate):
        try:
            self._serial = serial.Serial(
                port=port_name,
                baudrate=baud_rate,
                bytesize=serial.EIGHTBITS,
                parity=serial.PARITY_NONE,
                stopbits=serial.STOPBITS_ONE,
                timeout=0,  # Non-blocking reads
            )
        except Exception as e:
            self.port_error.emit(f"Failed to open {port_name}: {e}")
            return False

        self._parser.reset()
        self._is_open = True
        self._poll_timer.start()
        self.port_opened.emit(port_name, baud_rate)
        return True

    def _on_poll_pyserial(self):
        if not self._serial or not self._serial.is_open:
            return
        try:
            data = self._serial.read(256)
            if data:
                self.raw_data_received.emit(data)
                self._parser.process_bytes(data)
        except Exception as e:
            self.port_error.emit(f"Read error: {e}")
            self._poll_timer.stop()
            self._is_open = False
            self.port_closed.emit()

    # =====================================================================
    #  Common Handlers
    # =====================================================================

    def _on_parser_message(self, msg):
        self._response_timer.stop()
        self._waiting_for_response = False
        self.message_received.emit(msg)

    def _on_parser_error(self, error_desc):
        self.parse_error_sig.emit(error_desc)

    def _on_response_timeout(self):
        if self._waiting_for_response:
            code = self._pending_command_code
            self._waiting_for_response = False
            self.response_timeout.emit(code)
