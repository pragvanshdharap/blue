"""
VELOCITY RADAR — Message Parser (Layer 3)

Byte-by-byte state machine:
    WAIT_HEADER_1 → WAIT_HEADER_2 → WAIT_SIZE → COLLECTING

Validates checksum, emits messageReceived(ParsedMessage) signal.
Static decode functions extract typed dataclasses.
"""

from dataclasses import dataclass
from enum import Enum, auto
from PySide6.QtCore import QObject, Signal

from protocol import *


# =========================================================================
#  Parsed Message & Decoded Response Dataclasses
# =========================================================================

@dataclass
class ParsedMessage:
    code: int          # Message code (e.g., 254=ACK, 200=LAST_V)
    data: bytes        # Data bytes only (excludes SIZE, CODE, CHECKSUM)
    size: int          # Original SIZE field value

@dataclass
class AckData:
    acknowledged_code: int
    valid: bool = False

@dataclass
class NackData:
    rejected_code: int
    valid: bool = False

@dataclass
class LastVData:
    result: int = 0             # 0=OK, -1=error
    raw_velocity: int = 0       # Raw wire value
    real_velocity: float = 0.0  # raw / 16.0
    valid: bool = False

@dataclass
class ParamsData:
    expected_v: int = 0
    tripod: int = 0
    x: int = 0
    y: int = 0
    z: int = 0
    valid: bool = False

@dataclass
class SystemTestData:
    flags: int = 0
    valid: bool = False


# =========================================================================
#  Parser State Machine
# =========================================================================

class _State(Enum):
    WAIT_HEADER_1 = auto()
    WAIT_HEADER_2 = auto()
    WAIT_SIZE     = auto()
    COLLECTING    = auto()


class MessageParser(QObject):
    """Byte-by-byte parser for the velocity radar protocol."""

    # Signals
    message_received = Signal(object)   # ParsedMessage
    parse_error      = Signal(str)      # Error description

    def __init__(self, parent=None):
        super().__init__(parent)
        self._state = _State.WAIT_HEADER_1
        self._size = 0
        self._bytes_expected = 0
        self._buffer = bytearray()

    def reset(self):
        """Reset parser to initial state."""
        self._state = _State.WAIT_HEADER_1
        self._size = 0
        self._bytes_expected = 0
        self._buffer.clear()

    def process_bytes(self, data: bytes):
        """Feed raw bytes from serial port. May emit signals."""
        for byte in data:
            self._process_byte(byte)

    def _process_byte(self, byte: int):
        if self._state == _State.WAIT_HEADER_1:
            if byte == HEADER_1:
                self._state = _State.WAIT_HEADER_2

        elif self._state == _State.WAIT_HEADER_2:
            if byte == HEADER_2:
                self._state = _State.WAIT_SIZE
            elif byte == HEADER_1:
                pass  # Could be start of new frame — stay in WAIT_HEADER_2
            else:
                self._state = _State.WAIT_HEADER_1  # False header

        elif self._state == _State.WAIT_SIZE:
            self._size = byte
            if self._size < 2:
                self.parse_error.emit(
                    f"Invalid SIZE field: {self._size} (minimum is 2)")
                self._state = _State.WAIT_HEADER_1
                return
            self._bytes_expected = self._size - 1  # CODE + DATA + CHECKSUM
            self._buffer = bytearray()
            self._state = _State.COLLECTING

        elif self._state == _State.COLLECTING:
            self._buffer.append(byte)
            self._bytes_expected -= 1
            if self._bytes_expected == 0:
                self._validate_and_emit()
                self._state = _State.WAIT_HEADER_1

    def _validate_and_emit(self):
        """Validate checksum and emit messageReceived or parseError."""
        # Checksum verification: (SIZE + CODE + DATA... + CHECKSUM) mod 256 == 0
        checksum_sum = self._size
        for b in self._buffer:
            checksum_sum = (checksum_sum + b) & 0xFF

        if checksum_sum != 0:
            self.parse_error.emit(
                f"Checksum validation failed (sum={checksum_sum}, expected 0)")
            return

        # Extract fields from buffer: [CODE][DATA_1]...[DATA_M][CHECKSUM]
        code = self._buffer[0]
        data_length = self._size - 3  # SIZE - 1(SIZE) - 1(CODE) - 1(CHECKSUM)
        data = bytes(self._buffer[1:1 + data_length]) if data_length > 0 else b""

        msg = ParsedMessage(code=code, data=data, size=self._size)
        self.message_received.emit(msg)

    # =====================================================================
    #  Static Decode Functions
    # =====================================================================

    @staticmethod
    def decode_ack(msg: ParsedMessage) -> AckData:
        result = AckData(acknowledged_code=0)
        if msg.code != RSP_ACK or len(msg.data) != 1:
            return result
        result.acknowledged_code = msg.data[0]
        result.valid = True
        return result

    @staticmethod
    def decode_nack(msg: ParsedMessage) -> NackData:
        result = NackData(rejected_code=0)
        if msg.code != RSP_NACK or len(msg.data) != 1:
            return result
        result.rejected_code = msg.data[0]
        result.valid = True
        return result

    @staticmethod
    def decode_last_v(msg: ParsedMessage) -> LastVData:
        result = LastVData()
        if msg.code != RSP_LAST_V or len(msg.data) != 3:
            return result
        # RESULT byte (signed: 0=OK, 0xFF=-1=error)
        result.result = msg.data[0] if msg.data[0] < 128 else msg.data[0] - 256
        # Velocity: uint16 little-endian
        result.raw_velocity = msg.data[1] | (msg.data[2] << 8)
        result.real_velocity = result.raw_velocity / 16.0
        result.valid = True
        return result

    @staticmethod
    def decode_params(msg: ParsedMessage) -> ParamsData:
        result = ParamsData()
        if msg.code != RSP_PARAMS or len(msg.data) != 6:
            return result
        result.expected_v = msg.data[0] | (msg.data[1] << 8)
        result.tripod = msg.data[2]
        result.x = msg.data[3]
        result.y = msg.data[4]
        result.z = msg.data[5]
        result.valid = True
        return result

    @staticmethod
    def decode_system_test_results(msg: ParsedMessage) -> SystemTestData:
        result = SystemTestData()
        if msg.code != RSP_SYSTEM_TEST_RESULTS or len(msg.data) != 2:
            return result
        result.flags = msg.data[0] | (msg.data[1] << 8)
        result.valid = True
        return result
