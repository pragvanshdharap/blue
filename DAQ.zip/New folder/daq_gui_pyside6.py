#!/usr/bin/env python3
"""
DAQ GUI (PySide6) for STM32 + Dual ADS131M08 over UART

Features:
- Serial port picker + baud picker, Connect/Disconnect
- Expects CSV lines: timestamp_ms,ch0,...,ch15
- Live plot (Matplotlib in Qt) with selectable channels (0..15)
- Rolling window (seconds) control
- Start/Stop logging to CSV with header and periodic flush
- Status bar with basic stats (lines/sec, buffer size)
- Robust serial thread with auto-retry and error messages

Install:
  pip install PySide6 pyserial matplotlib numpy

Run:
  python daq_gui_pyside6.py

Author: ChatGPT
"""
import sys
import time
import csv
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

import numpy as np

from PySide6 import QtCore, QtWidgets
from PySide6.QtCore import Qt, Signal, Slot, QThread, QTimer
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QSpinBox, QCheckBox, QFileDialog, QLineEdit, QGroupBox, QGridLayout,
    QDoubleSpinBox, QStatusBar
)

# Matplotlib Qt canvas
import matplotlib
matplotlib.use("QtAgg")
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure

# Serial
try:
    import serial
    from serial.tools import list_ports
except Exception as e:
    serial = None
    list_ports = None

EXPECTED_COLS = 17  # timestamp + 16 channels

@dataclass
class RingBuffers:
    maxlen: int
    ts: deque = field(default_factory=lambda: deque(maxlen=10000))
    ch: List[deque] = field(default_factory=list)

    def __post_init__(self):
        self.ts = deque(maxlen=self.maxlen)
        self.ch = [deque(maxlen=self.maxlen) for _ in range(16)]

class SerialWorker(QThread):
    line_parsed = Signal(float, list)   # ts_ms, [ch0..ch15]
    status_msg = Signal(str)
    connected = Signal(bool)

    def __init__(self, port: str, baud: int, parent=None):
        super().__init__(parent)
        self._port = port
        self._baud = baud
        self._running = True
        self._ser = None

    def stop(self):
        self._running = False
        try:
            if self._ser and self._ser.is_open:
                self._ser.close()
        except Exception:
            pass

    def run(self):
        if serial is None:
            self.status_msg.emit("pyserial not installed. pip install pyserial")
            self.connected.emit(False)
            return

        def open_serial():
            while self._running:
                try:
                    s = serial.Serial(self._port, self._baud, timeout=1)
                    return s
                except Exception as e:
                    self.status_msg.emit(f"Open {self._port} failed: {e}. Retrying...")
                    time.sleep(1.5)
            return None

        self._ser = open_serial()
        if not self._ser:
            self.connected.emit(False)
            return
        self.connected.emit(True)
        self.status_msg.emit(f"Connected {self._port} @ {self._baud}")

        buf = bytearray()
        last_emit = time.time()
        while self._running:
            try:
                chunk = self._ser.read(4096)
                if not chunk:
                    # timeout, loop
                    continue
                buf.extend(chunk)
                # parse lines
                while True:
                    try:
                        nl = buf.index(b'\n')
                    except ValueError:
                        break
                    line = buf[:nl+1]
                    del buf[:nl+1]
                    try:
                        text = line.decode('utf-8', errors='ignore').strip()
                    except Exception:
                        continue
                    if not text:
                        continue
                    parts = [p.strip() for p in text.split(',')]
                    if len(parts) != EXPECTED_COLS:
                        continue
                    try:
                        ts = float(parts[0])
                        vals = [float(x) for x in parts[1:]]
                    except ValueError:
                        continue
                    self.line_parsed.emit(ts, vals)

                # Occasional heartbeat
                now = time.time()
                if now - last_emit > 2.0:
                    self.status_msg.emit("Streaming...")
                    last_emit = now
            except Exception as e:
                self.status_msg.emit(f"Serial error: {e}. Reconnecting...")
                try:
                    if self._ser and self._ser.is_open:
                        self._ser.close()
                except Exception:
                    pass
                time.sleep(1.5)
                self._ser = open_serial()
                if not self._ser:
                    break

        # cleanup
        try:
            if self._ser and self._ser.is_open:
                self._ser.close()
        except Exception:
            pass
        self.connected.emit(False)
        self.status_msg.emit("Disconnected.")

class MplCanvas(FigureCanvas):
    def __init__(self, parent=None):
        fig = Figure(figsize=(8, 4), dpi=100)
        self.ax = fig.add_subplot(111)
        super().__init__(fig)
        self.setParent(parent)

class DAQWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("STM32 DAQ — Dual ADS131M08 (UART)")
        self.resize(1100, 650)

        self.worker: SerialWorker | None = None
        self.connected = False

        # Buffers
        self.window_secs = 10.0
        self.sample_cap = int(self.window_secs * 20000)  # heuristic ceiling
        self.buffers = RingBuffers(maxlen=max(2000, self.sample_cap))

        # UI layout
        self.canvas = MplCanvas(self)
        self.canvas.ax.set_title("Live Data")
        self.canvas.ax.set_xlabel("Time (s)")
        self.canvas.ax.set_ylabel("Counts (raw)")
        self.canvas.ax.grid(True)

        # Controls
        top = QHBoxLayout()

        # Port/baud
        self.port_combo = QComboBox()
        self.refresh_ports()
        self.baud_combo = QComboBox()
        self.baud_combo.addItems([str(b) for b in (115200, 230400, 460800, 921600, 1500000)])
        self.baud_combo.setCurrentText("921600")
        self.btn_connect = QPushButton("Connect")
        self.btn_disconnect = QPushButton("Disconnect")
        self.btn_disconnect.setEnabled(False)

        # Window seconds
        self.spin_window = QDoubleSpinBox()
        self.spin_window.setRange(1.0, 120.0)
        self.spin_window.setValue(self.window_secs)
        self.spin_window.setSuffix(" s")

        # Logging
        self.log_path_edit = QLineEdit()
        self.log_path_edit.setPlaceholderText("daq_log.csv")
        self.btn_browse = QPushButton("Browse…")
        self.btn_start_log = QPushButton("Start Logging")
        self.btn_stop_log = QPushButton("Stop Logging")
        self.btn_stop_log.setEnabled(False)

        # Channels group
        ch_group = QGroupBox("Channels")
        grid = QGridLayout()
        self.ch_checks: List[QCheckBox] = []
        for i in range(16):
            cb = QCheckBox(f"ch{i}")
            cb.setChecked(i in (0,1,8,9))  # default shown
            self.ch_checks.append(cb)
            grid.addWidget(cb, i//8, i%8)  # two rows of 8
        ch_group.setLayout(grid)

        # Assemble top bar
        top.addWidget(QLabel("Port:"))
        top.addWidget(self.port_combo)
        top.addWidget(QLabel("Baud:"))
        top.addWidget(self.baud_combo)
        top.addWidget(self.btn_connect)
        top.addWidget(self.btn_disconnect)
        top.addSpacing(20)
        top.addWidget(QLabel("Window:"))
        top.addWidget(self.spin_window)
        top.addSpacing(20)
        top.addWidget(QLabel("Log CSV:"))
        top.addWidget(self.log_path_edit, 1)
        top.addWidget(self.btn_browse)
        top.addWidget(self.btn_start_log)
        top.addWidget(self.btn_stop_log)

        # Status
        self.status = QStatusBar()
        self.lbl_rate = QLabel("Lines/s: 0")
        self.lbl_buf = QLabel("Buf: 0")
        self.status.addWidget(self.lbl_rate)
        self.status.addPermanentWidget(self.lbl_buf)

        # Main layout
        lay = QVBoxLayout(self)
        lay.addLayout(top)
        lay.addWidget(ch_group)
        lay.addWidget(self.canvas)
        lay.addWidget(self.status)

        # Plot lines dict
        self.lines = {}  # idx -> Line2D
        self._setup_lines()

        # Logging
        self.logging = False
        self.log_file = None
        self.log_writer = None
        self.lines_written = 0
        self.flush_every = 50

        # Timers
        self.last_count = 0
        self.lines_count = 0
        self.timer_plot = QTimer(self)
        self.timer_plot.setInterval(50)  # 20 FPS
        self.timer_plot.timeout.connect(self.update_plot)
        self.timer_plot.start()

        self.timer_stat = QTimer(self)
        self.timer_stat.setInterval(1000)
        self.timer_stat.timeout.connect(self.update_stats)
        self.timer_stat.start()

        # Signals
        self.btn_connect.clicked.connect(self.on_connect)
        self.btn_disconnect.clicked.connect(self.on_disconnect)
        self.spin_window.valueChanged.connect(self.on_window_changed)
        self.btn_browse.clicked.connect(self.on_browse)
        self.btn_start_log.clicked.connect(self.on_start_log)
        self.btn_stop_log.clicked.connect(self.on_stop_log)

    def refresh_ports(self):
        self.port_combo.clear()
        if list_ports is None:
            self.port_combo.addItem("pyserial missing")
            return
        ports = list(list_ports.comports())
        if not ports:
            self.port_combo.addItem("No ports")
            return
        for p in ports:
            self.port_combo.addItem(p.device)

    def _setup_lines(self):
        self.canvas.ax.cla()
        self.canvas.ax.grid(True)
        self.canvas.ax.set_xlabel("Time (s)")
        self.canvas.ax.set_ylabel("Counts (raw)")
        shown = self.selected_channels()
        self.lines = {}
        for idx in shown:
            (ln,) = self.canvas.ax.plot([], [], label=f"ch{idx}")
            self.lines[idx] = ln
        self.canvas.ax.legend(loc="upper right")
        self.canvas.draw_idle()

    def selected_channels(self):
        return [i for i, cb in enumerate(self.ch_checks) if cb.isChecked()]

    @Slot()
    def on_connect(self):
        if self.connected:
            return
        port = self.port_combo.currentText().strip()
        if not port or port in ("No ports", "pyserial missing"):
            self.status.showMessage("Select a valid serial port", 3000)
            return
        try:
            baud = int(self.baud_combo.currentText())
        except ValueError:
            baud = 921600
        self.worker = SerialWorker(port, baud)
        self.worker.line_parsed.connect(self.on_line)
        self.worker.status_msg.connect(self.status.showMessage)
        self.worker.connected.connect(self.on_connected_changed)
        self.worker.start()

    @Slot()
    def on_disconnect(self):
        if self.worker:
            self.worker.stop()
            self.worker.wait(1500)
            self.worker = None

    @Slot(bool)
    def on_connected_changed(self, ok: bool):
        self.connected = ok
        self.btn_connect.setEnabled(not ok)
        self.btn_disconnect.setEnabled(ok)
        self.status.showMessage("Connected" if ok else "Disconnected")

    @Slot(float, list)
    def on_line(self, ts_ms: float, vals: list):
        # Append to buffers
        self.buffers.ts.append(ts_ms)
        for i in range(16):
            self.buffers.ch[i].append(vals[i])
        self.lines_count += 1

        # Logging
        if self.logging and self.log_writer:
            row = [f"{ts_ms:.0f}"] + [f"{v:.0f}" for v in vals]
            try:
                self.log_writer.writerow(row)
                self.lines_written += 1
                if (self.lines_written % self.flush_every) == 0:
                    self.log_file.flush()
            except Exception as e:
                self.status.showMessage(f"CSV write error: {e}", 5000)

    @Slot(float)
    def on_window_changed(self, value: float):
        self.window_secs = float(value)
        self.sample_cap = int(max(2000, self.window_secs * 20000))
        self.buffers = RingBuffers(maxlen=self.sample_cap)  # reset buffers
        self._setup_lines()

    @Slot()
    def on_browse(self):
        path, _ = QFileDialog.getSaveFileName(self, "Choose CSV file", "daq_log.csv", "CSV files (*.csv)")
        if path:
            self.log_path_edit.setText(path)

    @Slot()
    def on_start_log(self):
        if self.logging:
            return
        path = self.log_path_edit.text().strip() or "daq_log.csv"
        try:
            self.log_file = open(path, "w", newline="")
            self.log_writer = csv.writer(self.log_file)
            header = ["timestamp_ms"] + [f"ch{i}" for i in range(16)]
            self.log_writer.writerow(header)
            self.log_file.flush()
            self.logging = True
            self.lines_written = 0
            self.btn_start_log.setEnabled(False)
            self.btn_stop_log.setEnabled(True)
            self.status.showMessage(f"Logging → {path}")
        except Exception as e:
            self.status.showMessage(f"Open CSV failed: {e}", 5000)

    @Slot()
    def on_stop_log(self):
        if not self.logging:
            return
        try:
            self.log_file.flush()
            self.log_file.close()
        except Exception:
            pass
        self.log_file = None
        self.log_writer = None
        self.logging = False
        self.btn_start_log.setEnabled(True)
        self.btn_stop_log.setEnabled(False)
        self.status.showMessage("Logging stopped")

    def update_stats(self):
        # lines per second
        now = self.lines_count
        lps = now - self.last_count
        self.last_count = now
        self.lbl_rate.setText(f"Lines/s: {lps}")
        self.lbl_buf.setText(f"Buf: {len(self.buffers.ts)}")

    def update_plot(self):
        if len(self.buffers.ts) < 2:
            return
        ts_ms = np.array(self.buffers.ts, dtype=float)
        t = (ts_ms - ts_ms[0]) / 1000.0
        tmax = t[-1]
        tmin = max(0.0, tmax - self.window_secs)
        mask = t >= tmin
        t_win = t[mask]

        shown = self.selected_channels()
        # If channel selection changed, rebuild lines
        if set(shown) != set(self.lines.keys()):
            self._setup_lines()

        y_min, y_max = None, None
        for idx in shown:
            y = np.array(self.buffers.ch[idx], dtype=float)
            # align lengths
            if len(y) >= len(t):
                y = y[-len(t):]
            y = y[mask[-len(y):]] if len(y) >= len(mask) else y[mask[:len(y)]]
            self.lines[idx].set_data(t_win[:len(y)], y[:len(t_win)])
            if y.size:
                ymin_c, ymax_c = float(np.min(y)), float(np.max(y))
                y_min = ymin_c if y_min is None else min(y_min, ymin_c)
                y_max = ymax_c if y_max is None else max(y_max, ymax_c)

        if t_win.size:
            self.canvas.ax.set_xlim(t_win[0], t_win[-1])
        if y_min is not None and y_max is not None:
            if y_min == y_max:
                y_min -= 1.0
                y_max += 1.0
            self.canvas.ax.set_ylim(y_min, y_max)

        self.canvas.draw_idle()

    def closeEvent(self, event):
        try:
            self.on_stop_log()
        except Exception:
            pass
        if self.worker:
            self.worker.stop()
            self.worker.wait(1500)
        event.accept()

def main():
    app = QApplication(sys.argv)
    w = DAQWindow()
    w.show()
    sys.exit(app.exec())

if __name__ == "__main__":
    main()
