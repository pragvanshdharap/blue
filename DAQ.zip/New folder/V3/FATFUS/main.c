/* main.c — STM32F746G-DISCO + Dual ADS131M08 + SD CSV logging (polling) */

#include "main.h"
#include "ads131m08.h"
#include "fatfs.h"
#include <stdio.h>
#include <string.h>

/* HAL handles (CubeMX generated) */
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern UART_HandleTypeDef huart1;

/* Ads handles (same as you used earlier) */
ADS131_Handle_t ads1 = {
    .hspi = &hspi1,
    .CS_Port = GPIOA, .CS_Pin = GPIO_PIN_4,
    .RESET_Port = GPIOB, .RESET_Pin = GPIO_PIN_0,
    .DRDY_Port = GPIOB, .DRDY_Pin = GPIO_PIN_1,
    .crc_enable = 1
};
ADS131_Handle_t ads2 = {
    .hspi = &hspi2,
    .CS_Port = GPIOC, .CS_Pin = GPIO_PIN_6,
    .RESET_Port = GPIOC, .RESET_Pin = GPIO_PIN_7,
    .DRDY_Port = GPIOC, .DRDY_Pin = GPIO_PIN_8,
    .crc_enable = 0
};

int32_t adc1_samples[ADS131M08_NUM_CHANNELS];
int32_t adc2_samples[ADS131M08_NUM_CHANNELS];

static FIL      g_logFile;
static FATFS    g_fs;
static uint8_t  g_sd_ok = 0;
static uint32_t g_line_count = 0;
static const uint32_t SYNC_EVERY_N_LINES = 100;

// Forward decls (from section above)
static int SD_OpenLog(void);
static int SD_WriteCSVLine(const char *line);
static void SD_CloseLog(void);

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();
    MX_USART1_UART_Init();
    MX_SDMMC1_SD_Init();  // CubeMX generated if SDMMC1 used
    MX_FATFS_Init();      // CubeMX generated

    ADS131_CS_HIGH(&ads1);
    ADS131_CS_HIGH(&ads2);

    // --- Init ADCs ---
    if (ADS131M08_Init(&ads1) != HAL_OK)
        HAL_UART_Transmit(&huart1,(uint8_t*)"ADS1 init FAIL\r\n",16,HAL_MAX_DELAY);
    else
        HAL_UART_Transmit(&huart1,(uint8_t*)"ADS1 init OK\r\n",14,HAL_MAX_DELAY);

    if (ADS131M08_Init(&ads2) != HAL_OK)
        HAL_UART_Transmit(&huart1,(uint8_t*)"ADS2 init FAIL\r\n",16,HAL_MAX_DELAY);
    else
        HAL_UART_Transmit(&huart1,(uint8_t*)"ADS2 init OK\r\n",14,HAL_MAX_DELAY);

    HAL_Delay(50); // settle

    // --- Open SD CSV ---
    if (SD_OpenLog() != 0) {
        HAL_UART_Transmit(&huart1,(uint8_t*)"SD open failed\r\n",16,HAL_MAX_DELAY);
        // You can still continue with UART-only logging
    } else {
        HAL_UART_Transmit(&huart1,(uint8_t*)"SD logging ON\r\n",15,HAL_MAX_DELAY);
    }

    char csv_line[256];

    while (1) {
        // Poll DRDY (active low)
        if ((HAL_GPIO_ReadPin(ads1.DRDY_Port, ads1.DRDY_Pin) == GPIO_PIN_RESET) ||
            (HAL_GPIO_ReadPin(ads2.DRDY_Port, ads2.DRDY_Pin) == GPIO_PIN_RESET)) {

            HAL_StatusTypeDef st1 = ADS131M08_ReadDataFrame(&ads1, adc1_samples);
            HAL_StatusTypeDef st2 = ADS131M08_ReadDataFrame(&ads2, adc2_samples);

            if ((st1 == HAL_OK) && (st2 == HAL_OK)) {
                uint32_t ts = HAL_GetTick();

                // Build CSV line: timestamp_ms,ch0..ch15
                int len = snprintf(csv_line, sizeof(csv_line), "%lu", (unsigned long)ts);
                for (int i = 0; i < ADS131M08_NUM_CHANNELS; ++i)
                    len += snprintf(csv_line + len, sizeof(csv_line) - len, ",%ld", (long)adc1_samples[i]);
                for (int i = 0; i < ADS131M08_NUM_CHANNELS; ++i)
                    len += snprintf(csv_line + len, sizeof(csv_line) - len, ",%ld", (long)adc2_samples[i]);
                len += snprintf(csv_line + len, sizeof(csv_line) - len, "\r\n");

                // UART mirror (optional)
                HAL_UART_Transmit(&huart1, (uint8_t*)csv_line, len, HAL_MAX_DELAY);

                // SD write
                if (g_sd_ok) {
                    if (SD_WriteCSVLine(csv_line) != 0) {
                        HAL_UART_Transmit(&huart1,(uint8_t*)"SD write err\r\n",13,HAL_MAX_DELAY);
                    }
                }
            } else {
                HAL_UART_Transmit(&huart1,(uint8_t*)"ADC frame read error\r\n",22,HAL_MAX_DELAY);
            }

            // Wait for DRDY to go high again before next read
            while ((HAL_GPIO_ReadPin(ads1.DRDY_Port, ads1.DRDY_Pin) == GPIO_PIN_RESET) ||
                   (HAL_GPIO_ReadPin(ads2.DRDY_Port, ads2.DRDY_Pin) == GPIO_PIN_RESET)) { /* spin */ }
        }
    }

    // (Not reached normally)
    SD_CloseLog();
    return 0;
}

/* ---- SD helpers (same as in the section above; include exactly once) ---- */

static int SD_OpenLog(void)
{
    FRESULT fr = f_mount(&g_fs, "", 1);
    if (fr != FR_OK) return -1;

    fr = f_open(&g_logFile, "log.csv", FA_WRITE | FA_CREATE_ALWAYS);
    if (fr != FR_OK) return -2;

    const char *hdr =
        "timestamp_ms"
        ",ch0,ch1,ch2,ch3,ch4,ch5,ch6,ch7"
        ",ch8,ch9,ch10,ch11,ch12,ch13,ch14,ch15\r\n";
    UINT bw = 0;
    fr = f_write(&g_logFile, hdr, (UINT)strlen(hdr), &bw);
    if (fr != FR_OK || bw != strlen(hdr)) return -3;

    g_sd_ok = 1;
    g_line_count = 0;
    return 0;
}

static int SD_WriteCSVLine(const char *line)
{
    if (!g_sd_ok) return -1;
    UINT bw = 0;
    FRESULT fr = f_write(&g_logFile, line, (UINT)strlen(line), &bw);
    if (fr != FR_OK || bw != strlen(line)) return -2;

    if ((++g_line_count % SYNC_EVERY_N_LINES) == 0) {
        if (f_sync(&g_logFile) != FR_OK) return -3;
    }
    return 0;
}

static void SD_CloseLog(void)
{
    if (g_sd_ok) {
        f_sync(&g_logFile);
        f_close(&g_logFile);
        f_mount(NULL, "", 0);
        g_sd_ok = 0;
    }
}
