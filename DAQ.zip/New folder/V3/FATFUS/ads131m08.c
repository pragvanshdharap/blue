/* ads131m08.c
 *
 * STM32F7 HAL driver implementation for ADS131M08
 * (based on ADS131M08 Rev. B datasheet:contentReference[oaicite:0]{index=0})
 *
 * Assumptions:
 *  - CubeMX configured SPI (mode 1) for ADS131M08
 *  - ADS131_Handle_t instances are provided for each ADC
 *  - ADS131M08_Init() is called before data reads
 *
 * Author: updated for two ADS131M08 devices
 */

#include "ads131m08.h"
#include "stm32f7xx_hal.h"
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

/* -------------------------
   CRC16 implementation (poly=0x8005)
   ------------------------- */
uint16_t ADS131M08_CalcCRC16(const uint8_t *data, uint16_t len) {
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)(data[i] << 8);
        for (uint8_t b = 0; b < 8; ++b) {
            if (crc & 0x8000) crc = (uint16_t)((crc << 1) ^ 0x8005);
            else crc <<= 1;
        }
    }
    return crc;
}

/* -------------------------
   Blocking SPI TxRx (used for short commands/writes)
   ------------------------- */
static HAL_StatusTypeDef spi_txrx_blocking(SPI_HandleTypeDef *hspi, uint8_t *tx, uint8_t *rx, uint16_t len) {
    return HAL_SPI_TransmitReceive(hspi, tx, rx, len, HAL_MAX_DELAY);
}

/* -------------------------
   Low-level command/reg access
   ------------------------- */
HAL_StatusTypeDef ADS131M08_SendCommand(ADS131_Handle_t *h, uint16_t cmd) {
    if (!h || !h->hspi) return HAL_ERROR;
    uint8_t tx[2] = { (uint8_t)(cmd >> 8), (uint8_t)(cmd & 0xFF) };
    uint8_t rx[2];
    ADS131_CS_LOW(h);
    HAL_StatusTypeDef st = spi_txrx_blocking(h->hspi, tx, rx, 2);
    ADS131_CS_HIGH(h);
    HAL_Delay(1);
    return st;
}

HAL_StatusTypeDef ADS131M08_WriteRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t value) {
    if (!h || !h->hspi) return HAL_ERROR;
    uint8_t tx[4];
    uint16_t wreg_cmd = ADS131M08_CMD_WREG(addr, 1);
    tx[0] = (uint8_t)(wreg_cmd >> 8);
    tx[1] = (uint8_t)(wreg_cmd & 0xFF);
    tx[2] = (uint8_t)(value >> 8);
    tx[3] = (uint8_t)(value & 0xFF);
    uint8_t rx[4];
    ADS131_CS_LOW(h);
    HAL_StatusTypeDef st = spi_txrx_blocking(h->hspi, tx, rx, 4);
    ADS131_CS_HIGH(h);
    HAL_Delay(1);
    return st;
}

HAL_StatusTypeDef ADS131M08_ReadRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t *value) {
    if (!h || !h->hspi || !value) return HAL_ERROR;
    uint16_t rreg_cmd = ADS131M08_CMD_RREG(addr, 1);
    uint8_t tx_cmd[2] = { (uint8_t)(rreg_cmd >> 8), (uint8_t)(rreg_cmd & 0xFF) };
    uint8_t rx[2] = {0};
    ADS131_CS_LOW(h);
    if (HAL_SPI_Transmit(h->hspi, tx_cmd, 2, HAL_MAX_DELAY) != HAL_OK) {
        ADS131_CS_HIGH(h);
        return HAL_ERROR;
    }
    if (HAL_SPI_Receive(h->hspi, rx, 2, HAL_MAX_DELAY) != HAL_OK) {
        ADS131_CS_HIGH(h);
        return HAL_ERROR;
    }
    ADS131_CS_HIGH(h);
    *value = ((uint16_t)rx[0] << 8) | rx[1];
    HAL_Delay(1);
    return HAL_OK;
}

/* -------------------------
   High-level initialization (blocking)
   ------------------------- */
HAL_StatusTypeDef ADS131M08_Init(ADS131_Handle_t *h) {
    if (!h) return HAL_ERROR;
    /* Ensure CS is high */
    ADS131_CS_HIGH(h);

    /* Optional hardware reset */
    if (h->RESET_Port) {
        HAL_GPIO_WritePin(h->RESET_Port, h->RESET_Pin, GPIO_PIN_RESET);
        HAL_Delay(5);
        HAL_GPIO_WritePin(h->RESET_Port, h->RESET_Pin, GPIO_PIN_SET);
        HAL_Delay(5);
    }
    /* Send RESET command */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_RESET);
    HAL_Delay(5);
    /* Send UNLOCK if required */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_UNLOCK);
    HAL_Delay(2);

    /* Configure MODE register: 24-bit mode, timeout, DRDY as pulse */
    uint16_t mode_init = ADS131M08_MODE_TIMEOUT | ADS131M08_MODE_DRDY_PULSE | ADS131M08_MODE_WLENGTH_24;
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_MODE, mode_init);

    /* Configure CLOCK register: set OSR=512 (~8kSPS @8.192MHz) and high-res mode */
    /* (Enable channels after WLENGTH=32 is set) */
    uint16_t clock_init = (uint16_t)(ADS131M08_CLOCK_OSR_512 | ADS131M08_CLOCK_PWR_HR);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_CLOCK, clock_init);

    /* Set PGA gains to unity */
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_GAIN1, 0x0000u);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_GAIN2, 0x0000u);

    /* Final MODE: switch to 32-bit output (MSB sign-extended), timeout, DRDY pulse */
    /* (WLENGTH=32 for sign-extension as per datasheet:contentReference[oaicite:1]{index=1}) */
    uint16_t mode_final = (uint16_t)(ADS131M08_MODE_WLENGTH_32 | ADS131M08_MODE_TIMEOUT | ADS131M08_MODE_DRDY_PULSE);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_MODE, mode_final);

    /* Re-write CLOCK to enable all channels now that WLENGTH=32 is set */
    uint16_t clock_final = (uint16_t)(ADS131M08_CLOCK_OSR_512 | ADS131M08_CLOCK_PWR_HR | ADS131M08_CLOCK_CH_ALL);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_CLOCK, clock_final);

    /* Optional: LOCK and START conversions */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_LOCK);
    HAL_Delay(2);
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_START);
    HAL_Delay(2);

    return HAL_OK;
}

/* -------------------------
   Blocking read of one 32-bit data frame
   ------------------------- */
HAL_StatusTypeDef ADS131M08_ReadDataFrame(ADS131_Handle_t *h, int32_t samples[ADS131M08_NUM_CHANNELS]) {
    if (!h || !h->hspi || !samples) return HAL_ERROR;
    uint8_t tx[FRAME_BYTES_32] = {0};
    uint8_t rx[FRAME_BYTES_32] = {0};

    ADS131_CS_LOW(h);
    if (HAL_SPI_TransmitReceive(h->hspi, tx, rx, FRAME_BYTES_32, HAL_MAX_DELAY) != HAL_OK) {
        ADS131_CS_HIGH(h);
        return HAL_ERROR;
    }
    ADS131_CS_HIGH(h);

    /* Parse 32-bit words: word0=status, words1-8 = CH0..CH7, word9=CRC */
    for (int ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
        uint8_t *w = &rx[(1 + ch) * 4];
        int32_t v = (int32_t)((w[0] << 24) | (w[1] << 16) | (w[2] << 8) | w[3]);
        samples[ch] = v;
    }
    if (h->crc_enable) {
        /* CRC word is in last 2 bytes of the last 32-bit word */
        uint16_t received_crc = ((uint16_t)rx[FRAME_BYTES_32 - 4] << 8) | rx[FRAME_BYTES_32 - 3];
        uint16_t calc = ADS131M08_CalcCRC16(rx, FRAME_BYTES_32 - 4);
        if (received_crc != calc) {
            return HAL_ERROR;  /* CRC mismatch */
        }
    }
    return HAL_OK;
}

/* DMA/streaming functions removed (using blocking reads instead) */
