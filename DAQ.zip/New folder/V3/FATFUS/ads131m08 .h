#ifndef __ADS131M08_H__
#define __ADS131M08_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f7xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/* -------------------------
   Basic constants & sizes
   ------------------------- */
#define ADS131M08_NUM_CHANNELS      8U

/* 24-bit frame: STATUS(3 bytes) + 8 channels * 3 bytes = 27 bytes (without CRC).
   If CRC enabled, add 2 bytes (total 29). */
#define ADS131M08_FRAME_BYTES_24         27U
#define ADS131M08_FRAME_BYTES_24_WITH_CRC 29U

/* 32-bit framing: STATUS(4 bytes) + 8 channel words + CRC word = 10 words = 40 bytes */
#define ADS131M08_FRAME_WORDS_32    10U
#define ADS131M08_FRAME_BYTES_32    (ADS131M08_FRAME_WORDS_32 * 4U) /* 40 bytes */

/* Default reference / counts (for conversion) */
#define ADS131M08_REF_VOLTAGE_DEF   1.2f      /* internal REF (typical) */
#define ADS131M08_FULLSCALE_COUNTS  (8388608LL) /* 2^23 (24-bit) */

/* -------------------------
   Register addresses (datasheet)
   ------------------------- */
#define ADS131M08_REG_STATUS    0x00U
#define ADS131M08_REG_MODE      0x02U
#define ADS131M08_REG_CLOCK     0x03U
#define ADS131M08_REG_GAIN1     0x04U
#define ADS131M08_REG_GAIN2     0x05U
/* (Other registers can be defined here if used) */

/* -------------------------
   SPI command words (16-bit)
   NOTE: Verify these against your ADS131M08 datasheet/revision.
   ------------------------- */
#define ADS131M08_CMD_NULL      0x0000U
#define ADS131M08_CMD_RESET     0x0011U   /* Reset command (example) */
#define ADS131M08_CMD_STANDBY   0x0022U
#define ADS131M08_CMD_WAKEUP    0x0033U
#define ADS131M08_CMD_LOCK      0x0555U
#define ADS131M08_CMD_UNLOCK    0x0666U
#define ADS131M08_CMD_START     0x0008U   /* START command: verify in datasheet */

/* WREG/RREG command builder (16-bit) */
#define ADS131M08_CMD_WREG(addr,n)  ((uint16_t)(0x6000U | (((uint16_t)((addr) & 0x1FU)) << 8) | (((uint16_t)((n) - 1U)) & 0x00FFU)))
#define ADS131M08_CMD_RREG(addr,n)  ((uint16_t)(0xA000U | (((uint16_t)((addr) & 0x1FU)) << 8) | (((uint16_t)((n) - 1U)) & 0x00FFU)))

/* -------------------------
   MODE register bit masks
   - WLENGTH bits: output word length (16/24/32 bits)
   - TIMEOUT/DRDY format: see datasheet
   ------------------------- */
#define ADS131M08_MODE_RXCRC_EN       (1U << 12)  /* enable CRC on input commands (example bit) */
#define ADS131M08_MODE_WLENGTH_24     (0x0000U)   /* WLENGTH = 24 bits (default) */
#define ADS131M08_MODE_WLENGTH_32     (0x0300U)   /* WLENGTH = 32 bits (MSB sign-extend) */
#define ADS131M08_MODE_TIMEOUT        (1U << 4)
#define ADS131M08_MODE_DRDY_PULSE     (1U << 0)

/* -------------------------
   CLOCK register bit masks
   - High byte [15:8]: channel enable mask (0xFF00 to enable all channels)
   - Low bits: OSR[2:0] in [4:2], PWR[1:0] in [1:0]
   ------------------------- */
#define ADS131M08_CLOCK_CH_ALL        0xFF00U  /* high byte=0xFF to enable all 8 channels */

/* OSR (oversampling ratio) settings for fCLKIN=8.192MHz (datasheet Table 8-2):
   0b000 = 128 (32kSPS)
   0b001 = 256 (16kSPS)
   0b010 = 512 (8kSPS)
   0b011 = 1024 (4kSPS, default)
   ... */
#define ADS131M08_CLOCK_OSR_128      (0U << 2)  /* OSR = 128 (32kSPS) */
#define ADS131M08_CLOCK_OSR_256      (1U << 2)  /* OSR = 256 (16kSPS) */
#define ADS131M08_CLOCK_OSR_512      (2U << 2)  /* OSR = 512 ( 8kSPS) */
#define ADS131M08_CLOCK_OSR_1024     (3U << 2)  /* OSR = 1024 (4kSPS) */
#define ADS131M08_CLOCK_OSR_2048     (4U << 2)  /* OSR = 2048 (2kSPS) */
#define ADS131M08_CLOCK_OSR_4096     (5U << 2)  /* OSR = 4096 (1kSPS) */
#define ADS131M08_CLOCK_OSR_8192     (6U << 2)  /* OSR = 8192 (0.5kSPS) */

#define ADS131M08_CLOCK_PWR_HR       (2U << 0)  /* PWR = 2 (High-resolution mode) */

/* -------------------------
   ADS131 handle structure
   - hspi: SPI handle (CubeMX)
   - CS_Port/CS_Pin: chip-select GPIO
   - RESET_Port/RESET_Pin: optional reset GPIO (set NULL/0 if unused)
   - DRDY_Port/DRDY_Pin: data-ready GPIO
   - crc_enable: set=1 to verify output CRC on data frames
   ------------------------- */
typedef struct {
    SPI_HandleTypeDef *hspi;
    GPIO_TypeDef *CS_Port;
    uint16_t CS_Pin;
    GPIO_TypeDef *RESET_Port;
    uint16_t RESET_Pin;
    GPIO_TypeDef *DRDY_Port;
    uint16_t DRDY_Pin;
    uint8_t crc_enable;
} ADS131_Handle_t;

#define ADS131_CS_LOW(h)   HAL_GPIO_WritePin((h)->CS_Port, (h)->CS_Pin, GPIO_PIN_RESET)
#define ADS131_CS_HIGH(h)  HAL_GPIO_WritePin((h)->CS_Port, (h)->CS_Pin, GPIO_PIN_SET)

/* -------------------------
   Public API prototypes (ads131m08.c)
   ------------------------- */
HAL_StatusTypeDef ADS131M08_SendCommand(ADS131_Handle_t *h, uint16_t cmd);
HAL_StatusTypeDef ADS131M08_WriteRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t value);
HAL_StatusTypeDef ADS131M08_ReadRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t *value);

HAL_StatusTypeDef ADS131M08_Init(ADS131_Handle_t *h);
HAL_StatusTypeDef ADS131M08_ReadDataFrame(ADS131_Handle_t *h, int32_t samples[ADS131M08_NUM_CHANNELS]);

float ADS131M08_CountsToVoltage(int32_t counts, float vref, uint8_t pga_gain);

uint16_t ADS131M08_CalcCRC16(const uint8_t *data, uint16_t len);

#ifdef __cplusplus
}
#endif
#endif /* __ADS131M08_H__ */
