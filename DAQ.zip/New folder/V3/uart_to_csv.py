#!/usr/bin/env python3
"""
UART-to-CSV logger for STM32 dual ADS131M08 DAQ

Reads CSV lines from a serial port (UART) and writes them to a CSV file.
Assumes the MCU prints lines in the format:
    timestamp_ms,ch0,ch1,...,ch15\r\n

Features:
- Auto-append header if missing
- Robust line parsing and validation (17 columns expected by default)
- Periodic flush (--flush-every N)
- Optional file rotation by size (--rotate-mb)
- Reconnect loop on serial disconnect/errors
- Cross-platform (Windows/Linux/macOS)

Usage examples:
  python uart_to_csv.py -p COM5 -b 921600 -o daq_log.csv
  python uart_to_csv.py -p /dev/ttyUSB0 -b 115200 -o daq_log.csv --flush-every 50 --rotate-mb 100

Install dependency:
  pip install pyserial
"""
import argparse
import csv
import io
import os
import sys
import time
from datetime import datetime
from pathlib import Path

try:
    import serial
    from serial.tools import list_ports
except Exception as e:
    print("ERROR: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
    raise

EXPECTED_COLS = 17  # timestamp_ms + 16 channels

def parse_args():
    ap = argparse.ArgumentParser(description="UART-to-CSV logger for STM32 DAQ")
    ap.add_argument("-p","--port", required=False, default=None,
                    help="Serial port (e.g., COM5 or /dev/ttyUSB0). If omitted, tries to auto-pick.")
    ap.add_argument("-b","--baud", type=int, default=921600, help="Baud rate (default: 921600)")
    ap.add_argument("-o","--outfile", required=False, default="daq_log.csv",
                    help="Output CSV path (default: daq_log.csv)")
    ap.add_argument("--flush-every", type=int, default=50,
                    help="Flush file every N lines (default: 50)")
    ap.add_argument("--rotate-mb", type=float, default=0.0,
                    help="Rotate file when size exceeds this many MB (0 = disable)")
    ap.add_argument("--append", action="store_true",
                    help="Append to existing file instead of overwrite (keeps header if present)")
    ap.add_argument("--strict", action="store_true",
                    help="Strict mode: drop lines with wrong column count or non-numeric values")
    ap.add_argument("--print", dest="echo", action="store_true",
                    help="Echo received lines to stdout")
    ap.add_argument("--no-header", action="store_true",
                    help="Do not write header to CSV (assume upstream provides it)")
    ap.add_argument("--cols", type=int, default=EXPECTED_COLS,
                    help=f"Expected number of columns per line (default: {EXPECTED_COLS})")
    return ap.parse_args()

def pick_port():
    ports = list(list_ports.comports())
    if not ports:
        return None
    # Prefer first with 'USB' or 'Serial' in description, else first one
    for p in ports:
        desc = (p.description or "").lower()
        if "usb" in desc or "serial" in desc or "uart" in desc:
            return p.device
    return ports[0].device

def open_serial(port, baud):
    while True:
        try:
            ser = serial.Serial(port=port, baudrate=baud, timeout=1)
            # Make sure we treat input as text lines
            return ser
        except serial.SerialException as e:
            print(f"[{datetime.now().isoformat(timespec='seconds')}] Could not open {port}: {e}")
            print("Retrying in 2 seconds... (Ctrl+C to abort)")
            time.sleep(2)

def rotate_if_needed(path: Path, rotate_mb: float, file_handle):
    if rotate_mb <= 0:
        return file_handle, path
    try:
        size = path.stat().st_size if path.exists() else 0
    except FileNotFoundError:
        size = 0
    if size < rotate_mb * 1024 * 1024:
        return file_handle, path
    # rotate: close, rename, open new
    try:
        file_handle.flush()
    except Exception:
        pass
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    rotated = path.with_name(f"{path.stem}_{ts}{path.suffix}")
    try:
        path.replace(rotated)
        print(f"[rotate] {path.name} -> {rotated.name}")
    except Exception as e:
        print(f"[rotate] failed to rotate: {e}")
    # reopen new file
    fh = open(path, "w", newline="")
    return fh, path

def ensure_header(writer, fh, path: Path, no_header: bool, expected_cols: int, append: bool):
    if no_header:
        return
    header = ["timestamp_ms"] + [f"ch{i}" for i in range(expected_cols-1)]
    # If appending, only write header if file is empty and doesn't have one
    need_header = True
    if append and path.exists():
        try:
            if path.stat().st_size > 0:
                # Peek the first line to see if header is present
                with open(path, "r", newline="") as check:
                    first = check.readline().strip()
                    if first.replace(" ", "") == ",".join(header).replace(" ", ""):
                        need_header = False
        except Exception:
            pass
    if need_header:
        writer.writerow(header)
        fh.flush()

def validate_row(parts, strict):
    if strict:
        if len(parts) == 0:
            return False
        # Drop empty, whitespace-only, or wrong column count
        if len(parts) != EXPECTED_COLS:
            return False
        # Check numeric
        for p in parts:
            try:
                float(p)
            except ValueError:
                return False
        return True
    else:
        # non-strict: attempt to coerce; if not enough cols, drop
        if len(parts) != EXPECTED_COLS:
            return False
        return True

def main():
    args = parse_args()
    port = args.port or pick_port()
    if not port:
        print("No serial ports found. Specify with --port.", file=sys.stderr)
        sys.exit(2)

    out_path = Path(args.outfile).expanduser().resolve()
    mode = "a" if args.append else "w"
    fh = open(out_path, mode, newline="")
    writer = csv.writer(fh)

    ensure_header(writer, fh, out_path, args.no_header, args.cols, args.append)

    print(f"Listening on {port} @ {args.baud} → {out_path}")
    print("Press Ctrl+C to stop.")

    lines_since_flush = 0
    try:
        while True:
            ser = open_serial(port, args.baud)
            try:
                # Use io.TextIOWrapper for proper newline handling and decoding
                sio = io.TextIOWrapper(ser, encoding="utf-8", newline="")
                for raw in sio:
                    line = raw.strip()
                    if not line:
                        continue
                    if args.echo:
                        print(line)
                    parts = [p.strip() for p in line.split(",")]
                    if not validate_row(parts, args.strict):
                        # You can print a warning or skip silently
                        continue
                    writer.writerow(parts)
                    lines_since_flush += 1

                    if args.flush_every > 0 and (lines_since_flush % args.flush_every) == 0:
                        fh.flush()
                        lines_since_flush = 0

                    # rotation
                    newfh, out_path = rotate_if_needed(out_path, args.rotate_mb, fh)
                    if newfh is not fh:
                        fh.close()
                        fh = newfh
                        writer = csv.writer(fh)
                        ensure_header(writer, fh, out_path, args.no_header, args.cols, False)
            except serial.SerialException as e:
                print(f"[{datetime.now().isoformat(timespec='seconds')}] Serial error: {e}")
                print("Re-opening serial in 2 seconds...")
                time.sleep(2)
            except UnicodeDecodeError:
                # Skip malformed bytes; port speed or MCU noise can cause this
                continue
            finally:
                try:
                    ser.close()
                except Exception:
                    pass
    except KeyboardInterrupt:
        print("\nStopping...")
    finally:
        try:
            fh.flush()
            fh.close()
        except Exception:
            pass

if __name__ == "__main__":
    main()
