/* main.c - updated integration for ADS131M08 driver (STM32F746G-DISCO)
 * ADS131M08: 8-channel, 24-bit ADC:contentReference[oaicite:2]{index=2}.
 *
 * Assumes:
 *  - CubeMX has configured SPI1 (hspi1) and SPI2 (hspi2), USART1 (huart1),
 *    and GPIO for CS and DRDY.
 *  - ads131m08.h/c added to project.
 */
#include "main.h"
#include "ads131m08.h"
#include <stdio.h>

/* HAL handles (CubeMX generated) */
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern UART_HandleTypeDef huart1;

/* ADS handles (configure pins to match your board) */
ADS131_Handle_t ads1 = {
    .hspi = &hspi1,
    .CS_Port = GPIOA, .CS_Pin = GPIO_PIN_4,
    .RESET_Port = GPIOB, .RESET_Pin = GPIO_PIN_0,
    .DRDY_Port = GPIOB, .DRDY_Pin = GPIO_PIN_1,
    .crc_enable = 1
};

ADS131_Handle_t ads2 = {
    .hspi = &hspi2,
    .CS_Port = GPIOC, .CS_Pin = GPIO_PIN_6,
    .RESET_Port = GPIOC, .RESET_Pin = GPIO_PIN_7,
    .DRDY_Port = GPIOC, .DRDY_Pin = GPIO_PIN_8,
    .crc_enable = 0
};

int32_t adc1_samples[ADS131M08_NUM_CHANNELS];
int32_t adc2_samples[ADS131M08_NUM_CHANNELS];

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    /* CubeMX generated init functions */
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();
    MX_USART1_UART_Init();
    /* ... other inits ... */

    /* Bring CS pins high */
    ADS131_CS_HIGH(&ads1);
    ADS131_CS_HIGH(&ads2);

    /* Initialize ADCs (register writes via SPI) */
    if (ADS131M08_Init(&ads1) == HAL_OK) {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS1 init OK\r\n", 14, HAL_MAX_DELAY);
    } else {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS1 init FAIL\r\n", 16, HAL_MAX_DELAY);
    }
    if (ADS131M08_Init(&ads2) == HAL_OK) {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS2 init OK\r\n", 14, HAL_MAX_DELAY);
    } else {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS2 init FAIL\r\n", 16, HAL_MAX_DELAY);
    }

    /* Let ADC filters/reference settle */
    HAL_Delay(50);

    /* Main loop: poll DRDY signals and read data frames */
    while (1) {
        /* Check if either ADC DRDY (active low) */
        if ((HAL_GPIO_ReadPin(ads1.DRDY_Port, ads1.DRDY_Pin) == GPIO_PIN_RESET) ||
            (HAL_GPIO_ReadPin(ads2.DRDY_Port, ads2.DRDY_Pin) == GPIO_PIN_RESET)) {
            /* Read full frame from both ADCs */
            HAL_StatusTypeDef st1 = ADS131M08_ReadDataFrame(&ads1, adc1_samples);
            HAL_StatusTypeDef st2 = ADS131M08_ReadDataFrame(&ads2, adc2_samples);
            if ((st1 == HAL_OK) && (st2 == HAL_OK)) {
                uint32_t ts = HAL_GetTick();  /* timestamp in ms */

                /* Optional: convert raw counts to engineering units */
                /* e.g., float voltage0 = ADS131M08_CountsToVoltage(adc1_samples[0],
                                       ADS131M08_REF_VOLTAGE_DEF, 1U); */

                /* Prepare CSV line: timestamp_ms,ch0..ch15 */
                char csv_line[192];
                int len = snprintf(csv_line, sizeof(csv_line), "%lu", (unsigned long)ts);
                for (int i = 0; i < ADS131M08_NUM_CHANNELS; ++i) {
                    len += snprintf(csv_line + len, sizeof(csv_line) - len, ",%ld", (long)adc1_samples[i]);
                }
                for (int i = 0; i < ADS131M08_NUM_CHANNELS; ++i) {
                    len += snprintf(csv_line + len, sizeof(csv_line) - len, ",%ld", (long)adc2_samples[i]);
                }
                len += snprintf(csv_line + len, sizeof(csv_line) - len, "\r\n");

                /* Transmit CSV line via UART */
                HAL_UART_Transmit(&huart1, (uint8_t*)csv_line, len, HAL_MAX_DELAY);
                /* TODO: Append csv_line to SD card via FATFS */
            } else {
                const char err_msg[] = "ADC frame read error\r\n";
                HAL_UART_Transmit(&huart1, (uint8_t*)err_msg, sizeof(err_msg)-1, HAL_MAX_DELAY);
            }
            /* Wait for DRDY signals to go inactive before next read */
            while ((HAL_GPIO_ReadPin(ads1.DRDY_Port, ads1.DRDY_Pin) == GPIO_PIN_RESET) ||
                   (HAL_GPIO_ReadPin(ads2.DRDY_Port, ads2.DRDY_Pin) == GPIO_PIN_RESET)) {
                /* busy wait */
            }
        }
    }
}
