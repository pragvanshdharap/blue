#!/usr/bin/env python3
"""
UART-to-CSV Live Viewer for STM32 Dual ADS131M08 DAQ

Reads CSV lines from a serial port:
    timestamp_ms,ch0,ch1,...,ch15

- Writes to CSV with periodic flush + optional rotation
- Live plots selected channels (default: ch0, ch1, ch8, ch9)
- Rolling window in seconds (default: 10s)
- Threaded serial reader with a queue/deque buffer
- Auto-reconnect on serial errors/disconnect

Install:
  pip install pyserial matplotlib numpy

Run examples:
  python uart_to_csv_live.py -p COM5 -b 921600 -o daq_log.csv --plot-ch 0 1 8 9 --window 10
  python uart_to_csv_live.py -p /dev/ttyUSB0 -b 460800 -o logs/daq_log.csv --rotate-mb 200 --flush-every 20

Notes:
- Expects exactly 17 columns (timestamp + 16 channels). Use --cols to change if you add fields.
- If incoming lines are too fast for live plotting, you can reduce plotted channels or increase --window.
"""

import argparse
import csv
import io
import os
import sys
import time
import threading
from collections import deque
from datetime import datetime
from pathlib import Path

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation

try:
    import serial
    from serial.tools import list_ports
except Exception:
    print("ERROR: pyserial is required. Install with: pip install pyserial", file=sys.stderr)
    raise

EXPECTED_COLS_DEFAULT = 17  # timestamp_ms + 16 channels

def pick_port():
    ports = list(list_ports.comports())
    if not ports:
        return None
    for p in ports:
        desc = (p.description or "").lower()
        if "usb" in desc or "serial" in desc or "uart" in desc:
            return p.device
    return ports[0].device

def open_serial(port, baud):
    while True:
        try:
            ser = serial.Serial(port=port, baudrate=baud, timeout=1)
            return ser
        except serial.SerialException as e:
            print(f"[{datetime.now().isoformat(timespec='seconds')}] Could not open {port}: {e}")
            print("Retrying in 2 seconds... (Ctrl+C to abort)")
            time.sleep(2)

def rotate_if_needed(path: Path, rotate_mb: float, file_handle):
    if rotate_mb <= 0:
        return file_handle, path
    try:
        size = path.stat().st_size if path.exists() else 0
    except FileNotFoundError:
        size = 0
    if size < rotate_mb * 1024 * 1024:
        return file_handle, path
    try:
        file_handle.flush()
    except Exception:
        pass
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    rotated = path.with_name(f"{path.stem}_{ts}{path.suffix}")
    try:
        path.replace(rotated)
        print(f"[rotate] {path.name} -> {rotated.name}")
    except Exception as e:
        print(f"[rotate] failed to rotate: {e}")
    fh = open(path, "w", newline="")
    return fh, path

def parse_args():
    ap = argparse.ArgumentParser(description="UART-to-CSV live viewer/logger for STM32 DAQ")
    ap.add_argument("-p","--port", default=None, help="Serial port (e.g., COM5 or /dev/ttyUSB0). Auto-pick if omitted.")
    ap.add_argument("-b","--baud", type=int, default=921600, help="Baud rate (default: 921600)")
    ap.add_argument("-o","--outfile", default="daq_log.csv", help="Output CSV path (default: daq_log.csv)")
    ap.add_argument("--flush-every", type=int, default=50, help="Flush every N lines (default: 50)")
    ap.add_argument("--rotate-mb", type=float, default=0.0, help="Rotate file when size exceeds MB (0=off)")
    ap.add_argument("--append", action="store_true", help="Append to existing file")
    ap.add_argument("--no-header", action="store_true", help="Do not write header row")
    ap.add_argument("--cols", type=int, default=EXPECTED_COLS_DEFAULT, help="Expected column count (default 17)")
    ap.add_argument("--plot-ch", type=int, nargs="+", default=[0,1,8,9], help="Channel indices to plot (0..15)")
    ap.add_argument("--window", type=float, default=10.0, help="Rolling window in seconds for plotting (default 10s)")
    ap.add_argument("--max-points", type=int, default=100000, help="Max points to retain per series")
    ap.add_argument("--no-echo", action="store_true", help="Do not echo incoming lines")
    return ap.parse_args()

def ensure_header(writer, fh, path: Path, no_header: bool, expected_cols: int, append: bool):
    if no_header:
        return
    header = ["timestamp_ms"] + [f"ch{i}" for i in range(expected_cols-1)]
    need_header = True
    if append and path.exists():
        try:
            if path.stat().st_size > 0:
                with open(path, "r", newline="") as check:
                    first = check.readline().strip()
                    if first.replace(" ", "") == ",".join(header).replace(" ", ""):
                        need_header = False
        except Exception:
            pass
    if need_header:
        writer.writerow(header)
        fh.flush()

def serial_reader_thread(port, baud, expected_cols, deque_ts, deque_ch, stop_evt, echo):
    """Continuously read lines from serial and push parsed values into deques."""
    while not stop_evt.is_set():
        ser = open_serial(port, baud)
        try:
            sio = io.TextIOWrapper(ser, encoding="utf-8", newline="")
            for raw in sio:
                if stop_evt.is_set():
                    break
                line = raw.strip()
                if not line:
                    continue
                if not echo:
                    pass
                else:
                    print(line)
                parts = [p.strip() for p in line.split(",")]
                if len(parts) != expected_cols:
                    continue
                # Parse to floats (timestamp as float ms, channels as float)
                try:
                    ts = float(parts[0])
                    vals = [float(x) for x in parts[1:]]
                except ValueError:
                    continue
                deque_ts.append(ts)
                for i, v in enumerate(vals):
                    deque_ch[i].append(v)
                # Cap size to avoid RAM blow-up
                cap = deque_ch[0].maxlen
                # (deque enforces cap automatically)
        except serial.SerialException as e:
            if stop_evt.is_set():
                break
            print(f"[{datetime.now().isoformat(timespec='seconds')}] Serial error: {e}")
            print("Re-opening in 2 seconds...")
            time.sleep(2)
        except UnicodeDecodeError:
            # skip malformed bytes
            continue
        finally:
            try:
                ser.close()
            except Exception:
                pass

def csv_writer_thread(outfile, flush_every, rotate_mb, no_header, append, expected_cols,
                      deque_lines, stop_evt):
    """Write raw CSV lines handed off from main to disk with rotation/flush."""
    path = Path(outfile).expanduser().resolve()
    mode = "a" if append else "w"
    fh = open(path, mode, newline="")
    writer = csv.writer(fh)
    if not no_header:
        header = ["timestamp_ms"] + [f"ch{i}" for i in range(expected_cols-1)]
        if not (append and path.exists() and path.stat().st_size > 0):
            writer.writerow(header)
            fh.flush()
    lines_since_flush = 0
    while not stop_evt.is_set():
        try:
            line = deque_lines.popleft()
        except IndexError:
            time.sleep(0.01)
            continue
        writer.writerow(line)
        lines_since_flush += 1
        if flush_every > 0 and (lines_since_flush % flush_every) == 0:
            fh.flush()
            lines_since_flush = 0
        newfh, path = rotate_if_needed(path, rotate_mb, fh)
        if newfh is not fh:
            fh.close()
            fh = newfh
            writer = csv.writer(fh)
            if not no_header:
                header = ["timestamp_ms"] + [f"ch{i}" for i in range(expected_cols-1)]
                writer.writerow(header)
                fh.flush()
    try:
        fh.flush()
        fh.close()
    except Exception:
        pass

def main():
    args = parse_args()
    port = args.port or pick_port()
    if not port:
        print("No serial ports found. Use --port.", file=sys.stderr)
        sys.exit(2)

    # Buffers for plotting and CSV
    maxlen = min(max(1000, int(args.window * 20000)), args.max_points)  # heuristic cap
    deque_ts = deque(maxlen=maxlen)
    # 16 channels (fixed), each with its own deque
    deque_ch = [deque(maxlen=maxlen) for _ in range(args.cols-1)]
    deque_lines = deque(maxlen=10_000)  # stage lines for CSV writer

    # Start serial reader
    stop_evt = threading.Event()
    th_reader = threading.Thread(target=serial_reader_thread,
                                 args=(port, args.baud, args.cols, deque_ts, deque_ch, stop_evt, not args.no_echo),
                                 daemon=True)
    th_reader.start()

    # Start CSV writer (build rows from buffers in the animation callback)
    th_writer = threading.Thread(target=csv_writer_thread,
                                 args=(args.outfile, args.flush_every, args.rotate_mb,
                                       args.no_header, args.append, args.cols,
                                       deque_lines, stop_evt),
                                 daemon=True)
    th_writer.start()

    # Set up plotting
    plot_indices = [i for i in args.plot_ch if 0 <= i < (args.cols-1)]
    if not plot_indices:
        plot_indices = [0]

    fig, ax = plt.subplots()
    lines = {}
    for idx in plot_indices:
        line_obj, = ax.plot([], [], label=f"ch{idx}")
        lines[idx] = line_obj

    ax.set_title("STM32 DAQ Live")
    ax.set_xlabel("time (s)")
    ax.set_ylabel("counts (raw)")
    ax.legend(loc="upper right")
    ax.grid(True)

    t0_pc = time.time()

    def animate(_frame):
        # Build arrays for time window
        if len(deque_ts) < 2:
            return list(lines.values())
        ts_ms = np.array(deque_ts, dtype=float)
        ts = (ts_ms - ts_ms[0]) / 1000.0  # seconds from start
        # Limit to the last args.window seconds
        if ts[-1] - ts[0] > args.window:
            tmin = ts[-1] - args.window
        else:
            tmin = 0.0
        mask = ts >= tmin
        ts_win = ts[mask]

        # Update each selected channel
        y_min, y_max = None, None
        for idx in plot_indices:
            y = np.array(deque_ch[idx], dtype=float)
            y = y[mask[-len(y):]] if len(y) >= len(mask) else y[mask[:len(y)]]
            lines[idx].set_data(ts_win[:len(y)], y[:len(ts_win)])
            if y.size:
                ymin_c, ymax_c = float(np.min(y)), float(np.max(y))
                y_min = ymin_c if y_min is None else min(y_min, ymin_c)
                y_max = ymax_c if y_max is None else max(y_max, ymax_c)

        # Adjust axes
        if ts_win.size:
            ax.set_xlim(ts_win[0], ts_win[-1])
        if y_min is not None and y_max is not None:
            if y_min == y_max:
                y_min -= 1.0
                y_max += 1.0
            ax.set_ylim(y_min, y_max)

        # Hand off newest complete row to CSV writer
        # If lengths match expected, build latest line [ts_ms, ch0..ch15]
        if len(deque_ts) and all(len(dc) for dc in deque_ch[:16]):
            latest_idx = len(deque_ts) - 1
            try:
                row = [f"{deque_ts[latest_idx]:.0f}"] + [f"{deque_ch[i][latest_idx]:.0f}" for i in range(args.cols-1)]
                deque_lines.append(row)
            except IndexError:
                pass

        return list(lines.values())

    ani = FuncAnimation(fig, animate, interval=50, blit=False)  # ~20 FPS
    try:
        plt.show()
    finally:
        stop_evt.set()
        th_reader.join(timeout=2.0)
        th_writer.join(timeout=2.0)

if __name__ == "__main__":
    main()
