ADS131M08.c

/* ads131m08.c
 *
 * STM32F7 HAL driver implementation for ADS131M08
 * Matches the ads131m08.h header provided earlier.
 *
 * Assumptions:
 *  - CubeMX configured SPI peripherals (mode 1) and DMA for those SPI instances.
 *  - ADS131_Handle_t instances are created in the application and point to proper hspi & GPIOs.
 *  - The application will call ADS131M08_GlobalInit() to register handles for DMA streaming.
 *
 * Integration notes (add these to your project):
 *  - In HAL GPIO EXTI callback: when DRDY pin fires, call ADS131M08_StartDMAFrameRead(&your_handle);
 *  - In HAL SPI TxRx Complete callback, call ADS131M08_DMACompleteCallback(hspi);
 *
 * Author: merged/updated for user's project
 */

#include "ads131m08.h"
#include "stm32f7xx_hal.h"
#include <string.h>
#include <stdint.h>
#include <stdbool.h>

/* -------------------------
   Internal constants
   ------------------------- */
#define ADS_INTERNAL_MAX_DEVICES   2U   /* currently supporting up to 2 ADC boards */
#define FRAME_WORDS_32             ADS131M08_FRAME_WORDS_32
#define FRAME_BYTES_32             ADS131M08_FRAME_BYTES_32
#define FRAME_BYTES_24             ADS131M08_FRAME_BYTES_24
#define FRAME_BYTES_24_CRC         ADS131M08_FRAME_BYTES_24_WITH_CRC

/* -------------------------
   Internal DMA state type
   ------------------------- */
typedef struct {
    ADS131_Handle_t *h;            /* associated handle */
    uint8_t wl_bits;               /* 24 or 32 (word size mode) */
    uint8_t rx_buf[FRAME_BYTES_32];/* big enough for 32-bit frame (40 bytes) */
    uint8_t tx_buf[FRAME_BYTES_32];
    volatile bool dma_active;
    volatile bool frame_ready;
    volatile bool dma_error;
} ADS_DMA_State_t;

/* Static arrays for up to two devices */
static ADS_DMA_State_t dma_states[ADS_INTERNAL_MAX_DEVICES];
static ADS131_Handle_t *registered_handles[ADS_INTERNAL_MAX_DEVICES];
static uint8_t registered_count = 0U;

/* -------------------------
   CRC16 implementation (poly=0x8005 or 0x1021 depending on family)
   Using the CRC used in the merged code (poly 0x8005, init 0xFFFF).
   Exposed via ADS131M08_CalcCRC16.
   ------------------------- */
uint16_t ADS131M08_CalcCRC16(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFF;
    for (uint16_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)(data[i] << 8);
        for (uint8_t b = 0; b < 8; ++b) {
            if (crc & 0x8000) crc = (uint16_t)((crc << 1) ^ 0x8005);
            else crc <<= 1;
        }
    }
    return crc;
}

/* -------------------------
   Helper: small blocking SPI TxRx (8-bit)
   This is used for register writes/reads which are short.
   ------------------------- */
static HAL_StatusTypeDef spi_txrx_blocking(SPI_HandleTypeDef *hspi, uint8_t *tx, uint8_t *rx, uint16_t len)
{
    return HAL_SPI_TransmitReceive(hspi, tx, rx, len, HAL_MAX_DELAY);
}

/* -------------------------
   Map handle -> internal DMA state index
   returns index (0..registered_count-1) or -1 if not found
   ------------------------- */
static int find_state_index_for_handle(ADS131_Handle_t *h)
{
    for (uint8_t i = 0; i < registered_count; ++i) {
        if (registered_handles[i] == h) return (int)i;
    }
    return -1;
}

/* -------------------------
   Low-level command/reg access
   - SendCommand: sends a 16-bit command (MSB first) as two bytes
   - WriteRegister: sends WREG for 1 register using 4 bytes (CMD, 0x00, reg_hi, reg_lo)
   - ReadRegister: uses RREG and reads 2 bytes back
   ------------------------- */
HAL_StatusTypeDef ADS131M08_SendCommand(ADS131_Handle_t *h, uint16_t cmd)
{
    if (!h || !h->hspi) return HAL_ERROR;
    uint8_t tx[2] = { (uint8_t)(cmd >> 8), (uint8_t)(cmd & 0xFF) };
    uint8_t rx[2];
    ADS131_CS_LOW(h);
    HAL_StatusTypeDef st = spi_txrx_blocking(h->hspi, tx, rx, 2);
    ADS131_CS_HIGH(h);
    HAL_Delay(1);
    return st;
}

HAL_StatusTypeDef ADS131M08_WriteRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t value)
{
    if (!h || !h->hspi) return HAL_ERROR;
    uint8_t tx[4];
    /* Build: [WREG_cmd|addr] [0x00] [reg_hi] [reg_lo]
       Using macro builder from header: ADS131M08_CMD_WREG(addr,1) produces 16-bit command */
    uint16_t wreg_cmd = ADS131M08_CMD_WREG(addr, 1);
    tx[0] = (uint8_t)(wreg_cmd >> 8);
    tx[1] = (uint8_t)(wreg_cmd & 0xFF);
    tx[2] = (uint8_t)(value >> 8);
    tx[3] = (uint8_t)(value & 0xFF);

    uint8_t rx[4];
    ADS131_CS_LOW(h);
    HAL_StatusTypeDef st = spi_txrx_blocking(h->hspi, tx, rx, 4);
    ADS131_CS_HIGH(h);
    HAL_Delay(1);
    return st;
}

HAL_StatusTypeDef ADS131M08_ReadRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t *value)
{
    if (!h || !h->hspi || !value) return HAL_ERROR;
    uint16_t rreg_cmd = ADS131M08_CMD_RREG(addr, 1);
    uint8_t tx_cmd[2] = { (uint8_t)(rreg_cmd >> 8), (uint8_t)(rreg_cmd & 0xFF) };
    uint8_t rx[2] = {0};
    ADS131_CS_LOW(h);
    if (HAL_SPI_Transmit(h->hspi, tx_cmd, 2, HAL_MAX_DELAY) != HAL_OK) {
        ADS131_CS_HIGH(h);
        return HAL_ERROR;
    }
    if (HAL_SPI_Receive(h->hspi, rx, 2, HAL_MAX_DELAY) != HAL_OK) {
        ADS131_CS_HIGH(h);
        return HAL_ERROR;
    }
    ADS131_CS_HIGH(h);
    *value = ((uint16_t)rx[0] << 8) | rx[1];
    HAL_Delay(1);
    return HAL_OK;
}

/* -------------------------
   High-level initialization sequence (blocking)
   - Sends reset/unlock, then config registers
   - Leaves ADC running (START) at end
   - Uses values consistent with earlier discussion (OSR=1024, WLENGTH->32 after initial writes)
   ------------------------- */
HAL_StatusTypeDef ADS131M08_Init(ADS131_Handle_t *h)
{
    if (!h) return HAL_ERROR;

    /* ensure CS high */
    ADS131_CS_HIGH(h);

    /* Optional reset pin */
    if (h->RESET_Port) {
        HAL_GPIO_WritePin(h->RESET_Port, h->RESET_Pin, GPIO_PIN_RESET);
        HAL_Delay(5);
        HAL_GPIO_WritePin(h->RESET_Port, h->RESET_Pin, GPIO_PIN_SET);
        HAL_Delay(5);
    }

    /* Send RESET command (if header's value matches your board) */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_RESET);
    HAL_Delay(5);

    /* Unlock sequence (common in ADS devices) */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_UNLOCK);
    HAL_Delay(2);

    /* Write MODE initially (keep 24-bit/default WLENGTH for initial safe writes)
       Example mode value: enable TIMEOUT, DRDY pulse (use header macros or edit) */
    uint16_t mode_init = ADS131M08_MODE_TIMEOUT | ADS131M08_MODE_DRDY_PULSE | ADS131M08_MODE_WLENGTH_24;
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_MODE, mode_init);

    /* CLOCK register: set OSR=1024 and PWR=HR but keep channels disabled until final step.
       The exact bit positions depend on your datasheet; use the CLOCK macros in the header */
    uint16_t clock_init = (uint16_t)(ADS131M08_CLOCK_OSR_1024 | ADS131M08_CLOCK_PWR_HR);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_CLOCK, clock_init);

    /* GAIN registers: set unity (0x0000) as default */
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_GAIN1, 0x0000u);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_GAIN2, 0x0000u);

    /* If CRC needs to be enabled on the device input frames, set RXCRC_EN in MODE now
       and write with input CRC appended if required by device. For simplicity we set WLENGTH=32.
    */
    uint16_t mode_final = (uint16_t)(ADS131M08_MODE_WLENGTH_32 | ADS131M08_MODE_TIMEOUT | ADS131M08_MODE_DRDY_PULSE);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_MODE, mode_final);

    /* Re-write CLOCK to enable all channels now that WLENGTH is configured */
    uint16_t clock_final = (uint16_t)(ADS131M08_CLOCK_OSR_1024 | ADS131M08_CLOCK_PWR_HR | ADS131M08_CLOCK_CH_ALL);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_CLOCK, clock_final);

    /* Optionally LOCK and START */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_LOCK);
    HAL_Delay(2);
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_START);
    HAL_Delay(2);

    return HAL_OK;
}

/* -------------------------
   Blocking read of a single data frame (24-bit or 32-bit depending on wl_bits)
   - samples[] must be array of ADS131M08_NUM_CHANNELS
   - If CRC enabled, verify and return HAL_ERROR on CRC mismatch
   ------------------------- */
HAL_StatusTypeDef ADS131M08_ReadDataFrame(ADS131_Handle_t *h, int32_t samples[ADS131M08_NUM_CHANNELS])
{
    if (!h || !h->hspi || !samples) return HAL_ERROR;

    /* We'll assume WLENGTH = 32 in normal streaming; but keep support for 24 if needed.
       Try to read 32-bit frame first (40 bytes). If device is in 24-bit mode, user should call
       with appropriate mechanism; here we attempt 32-bit read. */
    uint8_t tx[FRAME_BYTES_32];
    uint8_t rx[FRAME_BYTES_32];
    memset(tx, 0, sizeof(tx));
    memset(rx, 0, sizeof(rx));

    ADS131_CS_LOW(h);
    if (HAL_SPI_TransmitReceive(h->hspi, tx, rx, FRAME_BYTES_32, HAL_MAX_DELAY) != HAL_OK) {
        ADS131_CS_HIGH(h);
        return HAL_ERROR;
    }
    ADS131_CS_HIGH(h);

    /* Parse 32-bit words: word0=status, word1..8=ch0..7, word9=CRC word (if used) */
    for (int ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
        uint8_t *w = &rx[(1 + ch) * 4];
        int32_t v = (int32_t)((w[0] << 24) | (w[1] << 16) | (w[2] << 8) | w[3]);
        samples[ch] = v;
    }

    if (h->crc_enable) {
        /* CRC word usually in last 2 bytes of last 32-bit word — adjust if datasheet says differently */
        uint16_t received_crc = ((uint16_t)rx[FRAME_BYTES_32 - 4] << 8) | rx[FRAME_BYTES_32 - 3];
        uint16_t calc = ADS131M08_CalcCRC16(rx, FRAME_BYTES_32 - 4);
        if (received_crc != calc) return HAL_ERROR;
    }

    return HAL_OK;
}

/* -------------------------
   DMA streaming helpers
   - ADS131M08_DMAStateInit: initialize state for a single handle (user may provide state_ptr but internal state used)
   - ADS131M08_GlobalInit: register up to two handles for streaming
   - ADS131M08_StartDMAFrameRead: assert CS and start DMA TxRx (non-blocking)
   - ADS131M08_DMACompleteCallback: called from HAL_SPI_TxRxCpltCallback to mark completion and deassert CS
   - ADS131M08_FrameReady / ProcessFrameIfReady: query & parse frames in main loop
   ------------------------- */

/* Initialize a single handle's DMA state (optional per-handle registration) */
void ADS131M08_DMAStateInit(ADS131_Handle_t *h, void *state_ptr_unused, uint8_t wl_bits)
{
    if (!h) return;
    /* If we have space, register this handle */
    if (registered_count < ADS_INTERNAL_MAX_DEVICES) {
        registered_handles[registered_count] = h;
        dma_states[registered_count].h = h;
        dma_states[registered_count].wl_bits = wl_bits;
        dma_states[registered_count].dma_active = false;
        dma_states[registered_count].frame_ready = false;
        dma_states[registered_count].dma_error = false;
        memset(dma_states[registered_count].rx_buf, 0, sizeof(dma_states[registered_count].rx_buf));
        memset(dma_states[registered_count].tx_buf, 0, sizeof(dma_states[registered_count].tx_buf));
        registered_count++;
    }
}

/* Register two handles (convenience) */
void ADS131M08_GlobalInit(ADS131_Handle_t *h1, ADS131_Handle_t *h2, uint8_t wl_bits)
{
    registered_count = 0U;
    if (h1) ADS131M08_DMAStateInit(h1, NULL, wl_bits);
    if (h2) ADS131M08_DMAStateInit(h2, NULL, wl_bits);
}

/* Start non-blocking DMA frame read for a given handle (asserts CS here) */
void ADS131M08_StartDMAFrameRead(ADS131_Handle_t *h)
{
    if (!h || !h->hspi) return;
    int idx = find_state_index_for_handle(h);
    if (idx < 0) return;
    ADS_DMA_State_t *s = &dma_states[idx];

    if (s->dma_active) return; /* already active */

    /* prepare TX zeros sized for chosen WL */
    memset(s->tx_buf, 0, sizeof(s->tx_buf));

    /* assert CS and start DMA TxRx */
    ADS131_CS_LOW(h);

    HAL_StatusTypeDef st;
    if (s->wl_bits == 32) {
        /* start DMA for FRAME_BYTES_32 bytes */
        st = HAL_SPI_TransmitReceive_DMA(h->hspi, s->tx_buf, s->rx_buf, FRAME_BYTES_32);
    } else {
        /* 24-bit frame path: use FRAME_BYTES_24 or FRAME_BYTES_24_CRC if CRC used */
        uint16_t len = h->crc_enable ? FRAME_BYTES_24_CRC : FRAME_BYTES_24;
        st = HAL_SPI_TransmitReceive_DMA(h->hspi, s->tx_buf, s->rx_buf, len);
    }

    if (st == HAL_OK) {
        s->dma_active = true;
        s->dma_error = false;
        s->frame_ready = false;
    } else {
        /* if failed, deassert CS immediately */
        ADS131_CS_HIGH(h);
        s->dma_error = true;
        s->dma_active = false;
    }
}

/* This should be called from HAL_SPI_TxRxCpltCallback(hspi) */
void ADS131M08_DMACompleteCallback(SPI_HandleTypeDef *hspi)
{
    if (!hspi) return;
    /* find which state uses this hspi */
    for (uint8_t i = 0; i < registered_count; ++i) {
        ADS_DMA_State_t *s = &dma_states[i];
        if (s->h && s->h->hspi == hspi) {
            /* transfer completed: deassert CS, mark frame ready */
            ADS131_CS_HIGH(s->h);
            s->dma_active = false;
            s->frame_ready = true;
            s->dma_error = false;
            break;
        }
    }
}

/* Query whether a frame is ready for this handle */
bool ADS131M08_FrameReady(ADS131_Handle_t *h)
{
    if (!h) return false;
    int idx = find_state_index_for_handle(h);
    if (idx < 0) return false;
    return dma_states[idx].frame_ready;
}

/* Parse the ready frame into out_samples and clear the ready flag
   - out_samples must be pre-allocated with ADS131M08_NUM_CHANNELS entries
*/
void ADS131M08_ProcessFrameIfReady(ADS131_Handle_t *h, int32_t out_samples[ADS131M08_NUM_CHANNELS])
{
    if (!h || !out_samples) return;
    int idx = find_state_index_for_handle(h);
    if (idx < 0) return;
    ADS_DMA_State_t *s = &dma_states[idx];
    if (!s->frame_ready) return;

    if (s->wl_bits == 32) {
        /* parse 32-bit words */
        for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
            uint8_t *w = &s->rx_buf[(1 + ch) * 4]; /* word1..8 */
            int32_t val = (int32_t)((w[0] << 24) | (w[1] << 16) | (w[2] << 8) | w[3]);
            out_samples[ch] = val;
        }
        /* CRC verification (optional) */
        if (h->crc_enable) {
            /* assume CRC is two MSB bytes of last 32-bit word (check datasheet) */
            uint16_t received_crc = ((uint16_t)s->rx_buf[FRAME_BYTES_32 - 4] << 8) | s->rx_buf[FRAME_BYTES_32 - 3];
            uint16_t calc = ADS131M08_CalcCRC16(s->rx_buf, FRAME_BYTES_32 - 4);
            if (received_crc != calc) {
                /* CRC mismatch: mark error and zero samples */
                s->dma_error = true;
                for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) out_samples[ch] = 0;
            }
        }
    } else {
        /* parse 24-bit frame (status 3 bytes + 8*3 bytes) */
        uint8_t *rx = s->rx_buf;
        for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
            uint32_t idx_byte = 3U + (uint32_t)ch * 3U;
            int32_t raw24 = ((int32_t)rx[idx_byte] << 16) | ((int32_t)rx[idx_byte + 1] << 8) | (int32_t)rx[idx_byte + 2];
            if (raw24 & 0x00800000) raw24 |= 0xFF000000; /* sign-extend */
            out_samples[ch] = raw24;
        }
        if (h->crc_enable) {
            uint16_t received_crc = ((uint16_t)rx[FRAME_BYTES_24_CRC - 2] << 8) | rx[FRAME_BYTES_24_CRC - 1];
            uint16_t calc = ADS131M08_CalcCRC16(rx, FRAME_BYTES_24_CRC - 2);
            if (received_crc != calc) {
                s->dma_error = true;
                for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) out_samples[ch] = 0;
            }
        }
    }

    /* clear ready flag */
    s->frame_ready = false;
}

/* -------------------------
   Utility: Convert counts -> differential voltage
   counts: signed ADC counts (24-bit sign-extended in int32)
   vref: reference voltage (typ 1.2V if using internal)
   pga_gain: numeric gain (1,2,4,...)
   ------------------------- */
float ADS131M08_CountsToVoltage(int32_t counts, float vref, uint8_t pga_gain)
{
    float fs = vref / (float)pga_gain;
    return ((float)counts) * (fs / (float)ADS131M08_FULLSCALE_COUNTS);
}

/* -------------------------
   Optional helper: to be called from HAL callbacks in user app
   Example usage (add to your user code):
     void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi) { ADS131M08_DMACompleteCallback(hspi); }
     void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin) {
         if (GPIO_Pin == DRDY_PIN) {
             ADS131M08_StartDMAFrameRead(&ads1_handle);
             ADS131M08_StartDMAFrameRead(&ads2_handle);
         }
     }
   ------------------------- */
