/* ads131m08.h
 *
 * ADS131M08 STM32F7 HAL driver header
 *
 * - Provides ADS131_Handle_t structure
 * - Register address macros and WREG/RREG helper macros
 * - Command macros (RESET, UNLOCK, LOCK, START, etc.) — verify with your datasheet
 * - Frame/word size constants for 24-bit and 32-bit modes
 * - Public API prototypes for functions implemented in ads131m08.c
 *
 * Usage:
 *  - Include this header in your project and ensure CubeMX has configured SPI and DMA.
 *  - Configure ADS131_Handle_t instances for each ADC (hspi pointer, CS gpio, RESET gpio, DRDY pin).
 *  - Call ADS131M08_Init(), then use DMA read path (DRDY EXTI) or blocking reads per your choice.
 */

#ifndef __ADS131M08_H__
#define __ADS131M08_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f7xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

/* -------------------------
   Basic constants & sizes
   ------------------------- */
#define ADS131M08_NUM_CHANNELS      8U

/* 24-bit frame: STATUS(3 bytes) + 8 channels * 3 bytes = 27 bytes (without CRC).
   If CRC enabled, add 2 bytes at end (total 29). */
#define ADS131M08_FRAME_BYTES_24    27U
#define ADS131M08_FRAME_BYTES_24_WITH_CRC 29U

/* 32-bit framing: STATUS(1 word) + 8 channel words + CRC word = 10 words = 40 bytes */
#define ADS131M08_FRAME_WORDS_32    10U
#define ADS131M08_FRAME_BYTES_32    (ADS131M08_FRAME_WORDS_32 * 4U) /* 40 bytes */

/* Default reference / counts (useful helpers) */
#define ADS131M08_REF_VOLTAGE_DEF   1.2f      /* internal REF (typ) */
#define ADS131M08_FULLSCALE_COUNTS  (8388608LL) /* 2^23 */

/* -------------------------
   Register addresses (datasheet)
   ------------------------- */
#define ADS131M08_REG_STATUS    0x00U
#define ADS131M08_REG_MODE      0x02U
#define ADS131M08_REG_CLOCK     0x03U
#define ADS131M08_REG_GAIN1     0x04U
#define ADS131M08_REG_GAIN2     0x05U
/* Add more register addresses here if you use them (CHn_CFG, CFG, etc.) */

/* -------------------------
   SPI command words (16-bit style)
   NOTE: these are common example values — please verify with your ADS131M08 datasheet/revision.
   ------------------------- */
#define ADS131M08_CMD_NULL      0x0000U
#define ADS131M08_CMD_RESET     0x0011U   /* reset command (common example) */
#define ADS131M08_CMD_STANDBY   0x0022U
#define ADS131M08_CMD_WAKEUP    0x0033U
#define ADS131M08_CMD_LOCK      0x0555U
#define ADS131M08_CMD_UNLOCK    0x0666U
#define ADS131M08_CMD_START     0x0008U   /* START command: verify in datasheet and change if needed */

/* WREG/RREG command builders (16-bit command words)
   Format:
     WREG cmd (binary): 011 aaaaa nnnnnnn  -> 0x6000 | (addr << 8) | (n-1)
     RREG cmd (binary): 101 aaaaa nnnnnnn  -> 0xA000 | (addr << 8) | (n-1)
*/
#define ADS131M08_CMD_WREG(addr,n)  ((uint16_t)(0x6000U | (((uint16_t)((addr) & 0x1FU)) << 8) | (((uint16_t)((n) - 1U)) & 0x00FFU)))
#define ADS131M08_CMD_RREG(addr,n)  ((uint16_t)(0xA000U | (((uint16_t)((addr) & 0x1FU)) << 8) | (((uint16_t)((n) - 1U)) & 0x00FFU)))

/* -------------------------
   MODE register bit masks (examples)
   - WLENGTH bits: determine 24-bit or 32-bit output
   - TIMEOUT/DRDY format: device-specific bits — consult datasheet
   ------------------------- */
#define ADS131M08_MODE_RXCRC_EN       (1U << 12)  /* enable input CRC checking (example position) */
#define ADS131M08_MODE_WLENGTH_24     (0x0000U)   /* WLENGTH = 00/01 depending on device - keep default 24-bit */
#define ADS131M08_MODE_WLENGTH_32    (0x0300U)   /* WLENGTH bits set for 32-bit sign-extend (example) */
#define ADS131M08_MODE_TIMEOUT        (1U << 4)
#define ADS131M08_MODE_DRDY_PULSE     (1U << 0)

/* -------------------------
   CLOCK register bit masks (examples)
   - Channel bits are in high byte (bits 15:8). OSR/PWR are in low bits.
   ------------------------- */
#define ADS131M08_CLOCK_CH_ALL        0xFF00U  /* channel enable mask (write 0xFF in high byte to disable/enable based on datasheet) */
#define ADS131M08_CLOCK_OSR_1024      (3U << 2) /* example OSR field for 1024 (verify in datasheet) */
#define ADS131M08_CLOCK_PWR_HR        (2U << 0) /* example PWR field for high-res */

/* -------------------------
   ADS131 handle structure
   - hspi: pointer to SPI handle (CubeMX generated)
   - CS_Port / CS_Pin: chip-select GPIO
   - RESET_Port / RESET_Pin: optional reset pin; set to NULL/0 if unused
   - DRDY_Port / DRDY_Pin: DRDY pin (used for EXTI identification)
   - crc_enable: set to 1 to enable CRC verification on frames
   ------------------------- */
typedef struct {
    SPI_HandleTypeDef *hspi;
    GPIO_TypeDef *CS_Port;
    uint16_t CS_Pin;
    GPIO_TypeDef *RESET_Port;   /* optional */
    uint16_t RESET_Pin;
    GPIO_TypeDef *DRDY_Port;    /* optional (for EXTI pin check) */
    uint16_t DRDY_Pin;
    uint8_t crc_enable;         /* 0 = disabled, 1 = enabled */
} ADS131_Handle_t;

/* -------------------------
   Convenience macros to control CS
   (If your project already defines macros, you can use those instead.)
   ------------------------- */
#define ADS131_CS_LOW(h)   HAL_GPIO_WritePin((h)->CS_Port, (h)->CS_Pin, GPIO_PIN_RESET)
#define ADS131_CS_HIGH(h)  HAL_GPIO_WritePin((h)->CS_Port, (h)->CS_Pin, GPIO_PIN_SET)

/* -------------------------
   Public API prototypes (implemented in ads131m08.c)
   ------------------------- */

/* Low-level command/reg access */
HAL_StatusTypeDef ADS131M08_SendCommand(ADS131_Handle_t *h, uint16_t cmd);
HAL_StatusTypeDef ADS131M08_WriteRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t value);
HAL_StatusTypeDef ADS131M08_ReadRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t *value);

/* High-level control */
HAL_StatusTypeDef ADS131M08_Init(ADS131_Handle_t *h);
HAL_StatusTypeDef ADS131M08_ReadDataFrame(ADS131_Handle_t *h, int32_t samples[ADS131M08_NUM_CHANNELS]);

/* DMA streaming helpers */
void ADS131M08_DMAStateInit(ADS131_Handle_t *h, void *state_ptr, uint8_t wl_bits); /* state_ptr typed in .c */
void ADS131M08_GlobalInit(ADS131_Handle_t *h1, ADS131_Handle_t *h2, uint8_t wl_bits);
void ADS131M08_StartDMAFrameRead(ADS131_Handle_t *h);
void ADS131M08_DMACompleteCallback(SPI_HandleTypeDef *hspi); /* call from HAL_SPI_TxRxCpltCallback */
bool ADS131M08_FrameReady(ADS131_Handle_t *h);
void ADS131M08_ProcessFrameIfReady(ADS131_Handle_t *h, int32_t out_samples[ADS131M08_NUM_CHANNELS]);

/* Utility */
float ADS131M08_CountsToVoltage(int32_t counts, float vref, uint8_t pga_gain);

/* CRC utility (exported in case you want to call directly) */
uint16_t ADS131M08_CalcCRC16(const uint8_t *data, uint16_t len);

/* -------------------------
   Notes:
   - This header is intended to match the merged implementation in ads131m08.c that
     uses HAL SPI/DMA (CubeMX-generated peripherals).
   - Verify the command values (RESET/LOCK/UNLOCK/START/etc.) against your ADS131M08
     datasheet / board documentation. The macros above use commonly-seen example values,
     but some designs or revisions may differ.
   ------------------------- */

#ifdef __cplusplus
}
#endif

#endif /* __ADS131M08_H__ */
