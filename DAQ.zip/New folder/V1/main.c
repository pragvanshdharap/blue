/* main.c - updated integration for ADS131M08 driver (STM32F767ZI)
 *
 * Assumes:
 *  - CubeMX has configured SPI1 (hspi1) and SPI2 (hspi2), USART1 (huart1), GPIO, DMA, EXTI
 *  - ads131m08.h + ads131m08.c are added to the project
 */

#include "main.h"
#include "ads131m08.h"
#include <stdio.h>

/* HAL handles (CubeMX generated) */
extern SPI_HandleTypeDef hspi1;
extern SPI_HandleTypeDef hspi2;
extern UART_HandleTypeDef huart1;

/* ADS handles (configure pins to match your board) */
ADS131_Handle_t ads1 = {
    .hspi = &hspi1,
    .CS_Port = GPIOA, .CS_Pin = GPIO_PIN_4,
    .RESET_Port = GPIOB, .RESET_Pin = GPIO_PIN_0,
    .DRDY_Port = GPIOB, .DRDY_Pin = GPIO_PIN_1,
    .crc_enable = 1
};

ADS131_Handle_t ads2 = {
    .hspi = &hspi2,
    .CS_Port = GPIOC, .CS_Pin = GPIO_PIN_6,
    .RESET_Port = GPIOC, .RESET_Pin = GPIO_PIN_7,
    .DRDY_Port = GPIOC, .DRDY_Pin = GPIO_PIN_8,
    .crc_enable = 0
};

int32_t adc1_samples[ADS131M08_NUM_CHANNELS];
int32_t adc2_samples[ADS131M08_NUM_CHANNELS];

int main(void)
{
    HAL_Init();
    SystemClock_Config();

    /* CubeMX generated init functions */
    MX_GPIO_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();
    MX_USART1_UART_Init();
    /* ... other inits ... */

    /* Bring CS high initially */
    ADS131_CS_HIGH(&ads1);
    ADS131_CS_HIGH(&ads2);

    /* Initialize ADCs (blocking register writes) */
    if (ADS131M08_Init(&ads1) == HAL_OK) {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS1 init OK\r\n", 14, HAL_MAX_DELAY);
    } else {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS1 init FAIL\r\n", 16, HAL_MAX_DELAY);
    }

    if (ADS131M08_Init(&ads2) == HAL_OK) {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS2 init OK\r\n", 14, HAL_MAX_DELAY);
    } else {
        HAL_UART_Transmit(&huart1, (uint8_t *)"ADS2 init FAIL\r\n", 16, HAL_MAX_DELAY);
    }

    /* Let ADC internal filters/reference settle a bit before streaming */
    HAL_Delay(50);

    /* Register devices for DMA streaming: use WLENGTH=32 (32-bit sign-extended frames) */
    ADS131M08_GlobalInit(&ads1, &ads2, 32);

    /* Main loop: process frames when ready (DMA completion + CRC done) */
    while (1) {
        if (ADS131M08_FrameReady(&ads1)) {
            ADS131M08_ProcessFrameIfReady(&ads1, adc1_samples);
            char buf[96];
            int n = snprintf(buf, sizeof(buf), "ADC1 CH0=%ld CH1=%ld\r\n", (long)adc1_samples[0], (long)adc1_samples[1]);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, n, HAL_MAX_DELAY);
        }

        if (ADS131M08_FrameReady(&ads2)) {
            ADS131M08_ProcessFrameIfReady(&ads2, adc2_samples);
            char buf[96];
            int n = snprintf(buf, sizeof(buf), "ADC2 CH0=%ld CH1=%ld\r\n", (long)adc2_samples[0], (long)adc2_samples[1]);
            HAL_UART_Transmit(&huart1, (uint8_t*)buf, n, HAL_MAX_DELAY);
        }

        /* avoid busy spinning - give time to other tasks/ISRs */
        HAL_Delay(1);
    }
}

/* EXTI callback for DRDY - configured in CubeMX to call HAL_GPIO_EXTI_Callback */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    /* support either a shared DRDY pin or separate DRDY pins */
    if ((GPIO_Pin == ads1.DRDY_Pin) || (GPIO_Pin == ads2.DRDY_Pin)) {
        /* Start DMA reads for both ADCs (they have separate SPI instances).
           ADS131M08_StartDMAFrameRead internally checks dma_active and will not
           start a new transfer if one is already in progress. */
        ADS131M08_StartDMAFrameRead(&ads1);
        ADS131M08_StartDMAFrameRead(&ads2);
    }
}

/* HAL SPI DMA complete callback: forward to our handler (called by HAL) */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    ADS131M08_DMACompleteCallback(hspi);
}
