/* ads131m08.h
 * ADS131M08 STM32 HAL driver header (datasheet-accurate)
 *
 * This header reflects the official register map, field positions, and command
 * words from TI ADS131M08 (SBAS950B, Rev. Feb 2021).
 *
 * - ID/STATUS/MODE/CLOCK/GAINx/CFG/THRSHLD/CHx_* addresses
 * - Correct command opcodes (RESET, STANDBY, WAKEUP, LOCK=0x0555, UNLOCK=0x0655)
 * - MODE.WLENGTH encodings; CLOCK.OSR and PWR fields
 * - CRC type options + seed
 */

#ifndef __ADS131M08_H__
#define __ADS131M08_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f7xx_hal.h"
#include <stdint.h>
#include <stdbool.h>

#define ADS131M08_NUM_CHANNELS      8U

/* ---------- SPI frame sizing helpers ----------
 * 24-bit output: STATUS(3) + 8*3 = 27B + CRC(2) = 29B
 * 32-bit WL (MSB sign-extend or LSB pad): 10 words total:
 *   [0]=STATUS, [1..8]=CH0..CH7, [9]=CRC word => 40 bytes
 */
#define ADS131M08_FRAME_BYTES_24            27U
#define ADS131M08_FRAME_BYTES_24_WITH_CRC   29U
#define ADS131M08_FRAME_WORDS_32            10U
#define ADS131M08_FRAME_BYTES_32           (ADS131M08_FRAME_WORDS_32 * 4U) /* 40 bytes */

/* Conversion helpers */
#define ADS131M08_FULLSCALE_COUNTS   (8388608L) /* 2^23 (24-bit signed) */

/* ------------ Register map (addresses) ------------ */
/* Device settings / indicators */
#define ADS131M08_REG_ID             0x00u  /* RO */
#define ADS131M08_REG_STATUS         0x01u  /* RO */

/* Global settings */
#define ADS131M08_REG_MODE           0x02u
#define ADS131M08_REG_CLOCK          0x03u
#define ADS131M08_REG_GAIN1          0x04u
#define ADS131M08_REG_GAIN2          0x05u
#define ADS131M08_REG_CFG            0x06u
#define ADS131M08_REG_THRSHLD_MSB    0x07u
#define ADS131M08_REG_THRSHLD_LSB    0x08u

/* Channel-specific (repeat every 7 regs per channel) */
#define ADS131M08_REG_CHn_CFG(ch)       (0x09u + (uint8_t)(ch)*7u)  /* ch=0..7 */
#define ADS131M08_REG_CHn_OCAL_MSB(ch)  (0x0Au + (uint8_t)(ch)*7u)
#define ADS131M08_REG_CHn_OCAL_LSB(ch)  (0x0Bu + (uint8_t)(ch)*7u)
#define ADS131M08_REG_CHn_GCAL_MSB(ch)  (0x0Cu + (uint8_t)(ch)*7u)
#define ADS131M08_REG_CHn_GCAL_LSB(ch)  (0x0Du + (uint8_t)(ch)*7u)
/* (Some docs include up to 0x30 for CH7 blocks; unused offsets are reserved) */

/* ------------ STATUS register (0x01) bits ------------ */
/* [15] LOCK, [14] F_RESYNC, [13] REG_MAP, [12] CRC_ERR, [11] CRC_TYPE,
   [10] RESET, [9:8] WLENGTH, [7:0] DRDY7..DRDY0 */
#define ADS131M08_STATUS_LOCK          (1u << 15)
#define ADS131M08_STATUS_F_RESYNC      (1u << 14)
#define ADS131M08_STATUS_REG_MAP       (1u << 13)
#define ADS131M08_STATUS_CRC_ERR       (1u << 12)
#define ADS131M08_STATUS_CRC_TYPE      (1u << 11)
#define ADS131M08_STATUS_RESET         (1u << 10)
#define ADS131M08_STATUS_WLENGTH_Pos   8u
#define ADS131M08_STATUS_WLENGTH_Msk   (3u << ADS131M08_STATUS_WLENGTH_Pos)
#define ADS131M08_STATUS_DRDY(ch)      (1u << (ch)) /* ch 0..7 => bits 0..7 */

/* ------------ MODE register (0x02) bits ------------ */
/* [13] REG_CRC_EN, [12] RX_CRC_EN, [11] CRC_TYPE,
 * [10] RESET (sticky indicator), [9:8] WLENGTH,
 * [4] TIMEOUT, [3:2] DRDY_SEL, [1] DRDY_HiZ, [0] DRDY_FMT */
#define ADS131M08_MODE_REG_CRC_EN      (1u << 13)
#define ADS131M08_MODE_RX_CRC_EN       (1u << 12)
#define ADS131M08_MODE_CRC_TYPE_ANSI   (1u << 11)  /* 0=CCITT, 1=ANSI */
#define ADS131M08_MODE_RESET_BIT       (1u << 10)  /* write 0 to clear STATUS.reset */
#define ADS131M08_MODE_WLENGTH_Pos     8u
#define ADS131M08_MODE_WLENGTH_Msk     (3u << ADS131M08_MODE_WLENGTH_Pos)
#define ADS131M08_MODE_WLENGTH_16      (0u << ADS131M08_MODE_WLENGTH_Pos)
#define ADS131M08_MODE_WLENGTH_24      (1u << ADS131M08_MODE_WLENGTH_Pos)      /* default */
#define ADS131M08_MODE_WLENGTH_32_ZP   (2u << ADS131M08_MODE_WLENGTH_Pos)      /* 32-bit, LSB zero-pad */
#define ADS131M08_MODE_WLENGTH_32_SE   (3u << ADS131M08_MODE_WLENGTH_Pos)      /* 32-bit, MSB sign-extend */
#define ADS131M08_MODE_TIMEOUT_EN      (1u << 4)
#define ADS131M08_MODE_DRDY_SEL_Pos    2u
#define ADS131M08_MODE_DRDY_SEL_Msk    (3u << ADS131M08_MODE_DRDY_SEL_Pos)
#define ADS131M08_MODE_DRDY_MOST_LAG   (0u << ADS131M08_MODE_DRDY_SEL_Pos)     /* default */
#define ADS131M08_MODE_DRDY_OR_ALL     (1u << ADS131M08_MODE_DRDY_SEL_Pos)
#define ADS131M08_MODE_DRDY_MOST_LEAD  (2u << ADS131M08_MODE_DRDY_SEL_Pos)
#define ADS131M08_MODE_DRDY_MOST_LEAD2 (3u << ADS131M08_MODE_DRDY_SEL_Pos)
#define ADS131M08_MODE_DRDY_HIZ        (1u << 1)   /* 0=logic high when idle, 1=HiZ */
#define ADS131M08_MODE_DRDY_FMT_PULSE  (1u << 0)   /* 0=level-low, 1=low pulse */

/* ------------ CLOCK register (0x03) bits ------------ */
/* [15:8] CH7_EN..CH0_EN, [7] XTAL_DIS, [6] EXTREF_EN, [4:2] OSR, [1:0] PWR */
#define ADS131M08_CLOCK_CH_EN(ch)      (1u << (8u + (uint8_t)(ch)))   /* ch 0..7 */
#define ADS131M08_CLOCK_XTAL_DIS       (1u << 7)
#define ADS131M08_CLOCK_EXTREF_EN      (1u << 6)
#define ADS131M08_CLOCK_OSR_Pos        2u
#define ADS131M08_CLOCK_OSR_Msk        (7u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_OSR_128        (0u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_OSR_256        (1u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_OSR_512        (2u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_OSR_1024       (3u << ADS131M08_CLOCK_OSR_Pos) /* reset default */
#define ADS131M08_CLOCK_OSR_2048       (4u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_OSR_4096       (5u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_OSR_8192       (6u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_OSR_16256      (7u << ADS131M08_CLOCK_OSR_Pos)
#define ADS131M08_CLOCK_PWR_Pos        0u
#define ADS131M08_CLOCK_PWR_Msk        (3u << ADS131M08_CLOCK_PWR_Pos)
#define ADS131M08_CLOCK_PWR_VLP        (0u << ADS131M08_CLOCK_PWR_Pos)
#define ADS131M08_CLOCK_PWR_LP         (1u << ADS131M08_CLOCK_PWR_Pos)
#define ADS131M08_CLOCK_PWR_HR         (2u << ADS131M08_CLOCK_PWR_Pos) /* reset default */
#define ADS131M08_CLOCK_PWR_HR2        (3u << ADS131M08_CLOCK_PWR_Pos)

/* ------------ GAIN registers (0x04, 0x05) -------------
 * PGAGAINx[2:0] fields per channel in GAIN1/GAIN2 (packed).
 * Encodings are device-specific; leave as raw 3-bit fields from datasheet.
 */

/* ------------ Commands (16-bit words) -------------
 * Response occurs in following frame. RREG/WREG words follow the formats below.
 */
#define ADS131M08_CMD_NULL         0x0000u
#define ADS131M08_CMD_RESET        0x0011u
#define ADS131M08_CMD_STANDBY      0x0022u
#define ADS131M08_CMD_WAKEUP       0x0033u
#define ADS131M08_CMD_LOCK         0x0555u
#define ADS131M08_CMD_UNLOCK       0x0655u

/* RREG: 101a aaaa annn nnnn ; WREG: 011a aaaa annn nnnn then data word(s)
   nnn nnnn = (count-1). Single-register read returns data as next-frame response word. */
#define ADS131M08_CMD_WREG(addr, n)  ((uint16_t)(0x6000u | (((uint16_t)((addr)&0x1Fu))<<8) | (((uint16_t)((n)-1u))&0xFFu)))
#define ADS131M08_CMD_RREG(addr, n)  ((uint16_t)(0xA000u | (((uint16_t)((addr)&0x1Fu))<<8) | (((uint16_t)((n)-1u))&0xFFu)))

/* ------------ CRC -------------
 * Output CRC is always appended by the device; host may choose to verify.
 * MODE.CRC_TYPE: 0=CCITT (poly 0x1021), 1=ANSI (poly 0x8005). Seed=0xFFFF.
 */
typedef enum {
    ADS131M08_CRC_CCITT = 0,   /* x^16 + x^12 + x^5 + 1 (0x1021) */
    ADS131M08_CRC_ANSI  = 1    /* x^16 + x^15 + x^2 + 1 (0x8005) */
} ADS131M08_CRCType_t;

/* ------------ Handle ------------- */
typedef struct {
    SPI_HandleTypeDef *hspi;
    GPIO_TypeDef *CS_Port;   uint16_t CS_Pin;
    GPIO_TypeDef *RESET_Port;uint16_t RESET_Pin;  /* optional (tie NULL/0 if not used) */
    GPIO_TypeDef *DRDY_Port; uint16_t DRDY_Pin;   /* optional (for EXTI identification) */
    uint8_t verify_crc;      /* 0=skip verification; 1=verify output CRC word */
    ADS131M08_CRCType_t crc_type; /* which CRC algorithm to verify with */
} ADS131_Handle_t;

/* CS helpers */
#define ADS131_CS_LOW(h)   HAL_GPIO_WritePin((h)->CS_Port, (h)->CS_Pin, GPIO_PIN_RESET)
#define ADS131_CS_HIGH(h)  HAL_GPIO_WritePin((h)->CS_Port, (h)->CS_Pin, GPIO_PIN_SET)

/* -------- Public API -------- */
/* Commands / registers */
HAL_StatusTypeDef ADS131M08_SendCommand(ADS131_Handle_t *h, uint16_t cmd);
HAL_StatusTypeDef ADS131M08_WriteRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t value);
HAL_StatusTypeDef ADS131M08_ReadRegister (ADS131_Handle_t *h, uint8_t addr, uint16_t *value);

/* Device init / frame IO */
HAL_StatusTypeDef ADS131M08_Init(ADS131_Handle_t *h, uint8_t wl_32_signext, uint32_t clock_cfg, uint16_t mode_extra);
HAL_StatusTypeDef ADS131M08_ReadDataFrame_Blocking(ADS131_Handle_t *h, int32_t samples[ADS131M08_NUM_CHANNELS]);

/* DMA streaming helpers (use EXTI on DRDY to trigger) */
void ADS131M08_GlobalDMAInit(ADS131_Handle_t *h1, ADS131_Handle_t *h2, uint8_t use_wl32);
void ADS131M08_StartDMAFrameRead(ADS131_Handle_t *h);
void ADS131M08_DMA_CompleteCallback(SPI_HandleTypeDef *hspi);
bool ADS131M08_FrameReady(ADS131_Handle_t *h);
void ADS131M08_ParseReadyFrame(ADS131_Handle_t *h, int32_t out_samples[ADS131M08_NUM_CHANNELS]);

/* Utilities */
float    ADS131M08_CountsToVoltage(int32_t counts, float vref, uint8_t pga_gain);
uint16_t ADS131M08_CalcCRC16_ANSI(const uint8_t *data, uint16_t len);
uint16_t ADS131M08_CalcCRC16_CCITT(const uint8_t *data, uint16_t len);

#ifdef __cplusplus
}
#endif
#endif /* __ADS131M08_H__ */
