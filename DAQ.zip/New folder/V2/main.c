/* main.c — Dual ADS131M08 data logger (STM32F7 + FatFS)
 *
 * - SPI1 -> ADS1, SPI2 -> ADS2
 * - DRDY (EXTI) starts SPI DMA frame reads for both devices
 * - On DMA-complete, frames are parsed and converted to engineering units
 * - CSV logging to a file on storage (HDD/SD/USB via FatFS)
 *
 * Requires (CubeMX):
 *   - SPI1, SPI2 (8-bit, Mode 1: CPOL=0, CPHA=1)
 *   - DMA for SPI1 Rx/Tx and SPI2 Rx/Tx
 *   - GPIO for CS/RESET/DRDY pins below
 *   - EXTI on DRDY pins (falling edge)
 *   - USART1 (optional for prints)
 *   - FatFS middleware + a storage driver (SDIO/USB MSC/etc.)
 */

#include "main.h"
#include "ads131m08.h"
#include "fatfs.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

/* ---------- CubeMX extern handles ---------- */
extern SPI_HandleTypeDef  hspi1;
extern SPI_HandleTypeDef  hspi2;
extern UART_HandleTypeDef huart1;

/* ---------- Storage / logging config ---------- */
#define LOG_DRIVE        "0:"                 /* change to "1:" etc. later if you move to HDD/USB */
#define LOG_PATH         LOG_DRIVE "/datalog.csv"
#define LOG_FLUSH_LINES  1                    /* flush every N lines (1 = flush every line; increase for speed) */
#define LOG_LINE_MAX     512

static FATFS fs;
static FIL   logf;
static UINT  log_lines_since_sync = 0;
static uint8_t log_ready = 0;

/* ---------- ADC device wiring (adjust to your board) ---------- */
static ADS131_Handle_t ads1 = {
    .hspi      = &hspi1,
    .CS_Port   = GPIOA, .CS_Pin   = GPIO_PIN_4,   /* NSS/CS */
    .RESET_Port= GPIOB, .RESET_Pin= GPIO_PIN_0,   /* optional */
    .DRDY_Port = GPIOB, .DRDY_Pin = GPIO_PIN_1,   /* EXTI */
    .verify_crc= 1,
    .crc_type  = ADS131M08_CRC_ANSI
};
static ADS131_Handle_t ads2 = {
    .hspi      = &hspi2,
    .CS_Port   = GPIOC, .CS_Pin   = GPIO_PIN_6,
    .RESET_Port= GPIOC, .RESET_Pin= GPIO_PIN_7,
    .DRDY_Port = GPIOC, .DRDY_Pin = GPIO_PIN_8,
    .verify_crc= 1,
    .crc_type  = ADS131M08_CRC_ANSI
};

/* ---------- App-configurable ADC operating point ---------- */
/* Pick OSR/PWR to hit your target ODR with your master clock.
 * If MCLK is 8.192 MHz, OSR=256 ≈ 16 ksps, OSR=128 ≈ 32 ksps. Choose closest to 20 ksps.
 * You can change this later without touching driver code.
 */
#define ADC_OSR_FIELD   ADS131M08_CLOCK_OSR_256     /* try 256 first; switch to _128 if you need ~32 ksps */
#define ADC_PWR_FIELD   ADS131M08_CLOCK_PWR_HR      /* high-resolution */
#define ADC_CH_ENABLE   ( ADS131M08_CLOCK_CH_EN(0) | ADS131M08_CLOCK_CH_EN(1) | \
                          ADS131M08_CLOCK_CH_EN(2) | ADS131M08_CLOCK_CH_EN(3) | \
                          ADS131M08_CLOCK_CH_EN(4) | ADS131M08_CLOCK_CH_EN(5) | \
                          ADS131M08_CLOCK_CH_EN(6) | ADS131M08_CLOCK_CH_EN(7) )

/* MODE extras: keep DRDY default (level-low), enable TIMEOUT (driver sets), use 32-bit sign-extended frames */
#define MODE_EXTRA_BITS   (0u)

/* ---------- Raw sample buffers per device ---------- */
static int32_t adc1_raw[ADS131M08_NUM_CHANNELS];
static int32_t adc2_raw[ADS131M08_NUM_CHANNELS];

/* ============================================================
 * Sensor mapping + placeholder conversions (edit for your HW)
 * ============================================================ */

typedef enum {
    S_STRAIN,
    S_ACCEL,
    S_SHOCK,
    S_CURRENT,
    S_VOLTAGE,
    S_ACOUSTIC,
    S_TEMP,
    S_UNUSED
} sensor_t;

/* Map 16 channels: ADS1 ch0..7 then ADS2 ch0..7 (global ch8..15) */
static const sensor_t g_sensor_map[16] = {
    /* ADS1 */ S_STRAIN, S_ACCEL,  S_SHOCK,  S_CURRENT, S_VOLTAGE, S_ACOUSTIC, S_TEMP,   S_UNUSED,
    /* ADS2 */ S_STRAIN, S_ACCEL,  S_SHOCK,  S_CURRENT, S_VOLTAGE, S_ACOUSTIC, S_TEMP,   S_UNUSED
};

/* Per-sensor placeholder constants — replace with your calibrated values */
static const float VREF_ADC = 1.2f;       /* ADC reference (V) if internal ref used */
static const uint8_t PGA_GAIN = 1;        /* numeric gain (1,2,4,8,...) if you program PGA later */

/* Examples below — tune for your sensors */
static const float ACCEL_V_PER_G   = 0.5f;     /* 0.5 V/g  */
static const float SHOCK_V_PER_G   = 0.5f;
static const float CURR_V_PER_A    = 0.1f;     /* 0.1 V/A  */
static const float VOLT_DIV_RATIO  = 10.0f;    /* input scaled down by divider */
static const float MIC_V_PER_PA    = 0.05f;    /* 50 mV/Pa */
static const float TEMP_V_PER_DEG  = 0.01f;    /* 10 mV/°C */
static const float STRAIN_VEXC     = 3.3f;     /* bridge excitation */
static const float STRAIN_GAUGE_F  = 2.0f;     /* gauge factor */

/* Example: user asked for placeholder ConvertStrainGaugeVoltageToMPa() */
static float ConvertStrainGaugeVoltageToMPa(float v)
{
    /* Very rough placeholder. Replace with calibrated bridge->pressure mapping. */
    const float SENSITIVITY_MPA_PER_V = 50.0f; /* e.g. 50 MPa per volt differential */
    return v * SENSITIVITY_MPA_PER_V;
}

/* Other conversions — tune or replace as needed */
static float conv_strain_microstrain(float v)      { return (v / STRAIN_VEXC) / STRAIN_GAUGE_F * 1e6f; }
static float conv_accel_g(float v)                 { return v / ACCEL_V_PER_G; }
static float conv_shock_g(float v)                 { return v / SHOCK_V_PER_G; }
static float conv_current_A(float v)               { return v / CURR_V_PER_A; }
static float conv_voltage_V(float v_meas)          { return v_meas * VOLT_DIV_RATIO; }
static float conv_acoustic_Pa(float v)             { return v / MIC_V_PER_PA; }
static float conv_temperature_C(float v)           { return v / TEMP_V_PER_DEG; }

/* Channel dispatcher: convert raw counts -> volts -> engineering value */
static float convert_channel(uint8_t global_ch, int32_t counts)
{
    /* counts -> volts (differential) */
    float v = ADS131M08_CountsToVoltage(counts, VREF_ADC, PGA_GAIN);

    switch (g_sensor_map[global_ch]) {
        case S_STRAIN:
            /* choose one: strain in microstrain, or MPa via placeholder */
            //return conv_strain_microstrain(v);
            return ConvertStrainGaugeVoltageToMPa(v);
        case S_ACCEL:   return conv_accel_g(v);
        case S_SHOCK:   return conv_shock_g(v);
        case S_CURRENT: return conv_current_A(v);
        case S_VOLTAGE: return conv_voltage_V(v);
        case S_ACOUSTIC:return conv_acoustic_Pa(v);
        case S_TEMP:    return conv_temperature_C(v);
        default:        return v; /* raw volts if unused */
    }
}

/* ---------- local helpers ---------- */
static void log_write_line(const char *s)
{
    if (!log_ready) return;
    UINT bw = 0;
    f_write(&logf, s, (UINT)strlen(s), &bw);
    if (LOG_FLUSH_LINES > 0) {
        log_lines_since_sync++;
        if (log_lines_since_sync >= LOG_FLUSH_LINES) {
            f_sync(&logf);
            log_lines_since_sync = 0;
        }
    }
}

static void log_header_if_empty(void)
{
    if (!log_ready) return;
    if (f_size(&logf) == 0) {
        char hdr[LOG_LINE_MAX];
        int n = snprintf(hdr, sizeof(hdr),
                         "time_ms,dev,"
                         "ch0,ch1,ch2,ch3,ch4,ch5,ch6,ch7\r\n");
        log_write_line(hdr);
    }
}

/* ============================================================
 * main()
 * ============================================================ */
int main(void)
{
    HAL_Init();
    SystemClock_Config();

    /* CubeMX init (make sure these exist in your project) */
    MX_GPIO_Init();
    MX_DMA_Init();
    MX_SPI1_Init();
    MX_SPI2_Init();
    MX_USART1_UART_Init();
    /* Storage: MX_FATFS_Init() if CubeMX generated it, or mount manually below */

    /* Keep CS high initially */
    ADS131_CS_HIGH(&ads1);
    ADS131_CS_HIGH(&ads2);

    /* Mount filesystem + open CSV (append) */
    if (f_mount(&fs, LOG_DRIVE, 1) == FR_OK) {
        if (f_open(&logf, LOG_PATH, FA_OPEN_ALWAYS | FA_WRITE) == FR_OK) {
            f_lseek(&logf, f_size(&logf)); /* append mode */
            log_ready = 1;
            log_header_if_empty();
        }
    }

    /* Build CLOCK value: enable all channels + OSR + power mode */
    uint16_t clock_cfg = (uint16_t)(ADC_CH_ENABLE | ADC_OSR_FIELD | ADC_PWR_FIELD);

    /* Init both ADCs (32-bit sign-extended frames) */
    ADS131M08_Init(&ads1, 1 /* wl32 SE */, clock_cfg, MODE_EXTRA_BITS);
    ADS131M08_Init(&ads2, 1 /* wl32 SE */, clock_cfg, MODE_EXTRA_BITS);

    /* Short settle */
    HAL_Delay(50);

    /* Register both with the DMA engine in the driver */
    ADS131M08_GlobalDMAInit(&ads1, &ads2, 1 /* using 32-bit frames */);

    /* Main loop:
       The EXTI ISR will start DMA transfers. Here we just check for completed frames,
       parse, convert, and log. */
    char line[LOG_LINE_MAX];

    while (1) {
        uint8_t r1 = ADS131M08_FrameReady(&ads1);
        uint8_t r2 = ADS131M08_FrameReady(&ads2);

        if (r1) {
            ADS131M08_ParseReadyFrame(&ads1, adc1_raw);
        }
        if (r2) {
            ADS131M08_ParseReadyFrame(&ads2, adc2_raw);
        }

        /* If both arrived (ideal sync), log both; otherwise log whichever arrived */
        if (r1 || r2) {
            uint32_t t = HAL_GetTick();

            if (r1) {
                int n = snprintf(line, sizeof(line), "%lu,ADS1", (unsigned long)t);
                for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
                    float val = convert_channel(ch, adc1_raw[ch]);
                    n += snprintf(line + n, sizeof(line) - n, ",%.6f", (double)val);
                }
                n += snprintf(line + n, sizeof(line) - n, "\r\n");
                log_write_line(line);

                /* brief UART summary (optional) */
                char u[128];
                int m = snprintf(u, sizeof(u), "t=%lums ADS1 ch0=%.3f ch1=%.3f\r\n",
                                 (unsigned long)t,
                                 (double)convert_channel(0, adc1_raw[0]),
                                 (double)convert_channel(1, adc1_raw[1]));
                HAL_UART_Transmit(&huart1, (uint8_t*)u, m, HAL_MAX_DELAY);
            }

            if (r2) {
                int n = snprintf(line, sizeof(line), "%lu,ADS2", (unsigned long)t);
                for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
                    float val = convert_channel(8 + ch, adc2_raw[ch]); /* global ch 8..15 */
                    n += snprintf(line + n, sizeof(line) - n, ",%.6f", (double)val);
                }
                n += snprintf(line + n, sizeof(line) - n, "\r\n");
                log_write_line(line);

                char u[128];
                int m = snprintf(u, sizeof(u), "t=%lums ADS2 ch0=%.3f ch1=%.3f\r\n",
                                 (unsigned long)t,
                                 (double)convert_channel(8,  adc2_raw[0]),
                                 (double)convert_channel(9,  adc2_raw[1]));
                HAL_UART_Transmit(&huart1, (uint8_t*)u, m, HAL_MAX_DELAY);
            }
        }

        /* let other ISRs run */
        HAL_Delay(1);
    }
}

/* ============================================================
 * ISRs / HAL callbacks
 * ============================================================ */

/* EXTI callback: wire your DRDY pins to EXTI (falling edge).
 * Start one SPI DMA frame for each device when DRDY asserts.
 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if ((GPIO_Pin == ads1.DRDY_Pin) || (GPIO_Pin == ads2.DRDY_Pin)) {
        ADS131M08_StartDMAFrameRead(&ads1);
        ADS131M08_StartDMAFrameRead(&ads2);
    }
}

/* SPI DMA complete callback: forward to driver */
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi)
{
    ADS131M08_DMA_CompleteCallback(hspi);
}

/* (Optional) SPI error callback */
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi)
{
    const char *which = (hspi == &hspi1) ? "SPI1" : (hspi == &hspi2) ? "SPI2" : "SPI?";
    char b[48];
    int n = snprintf(b, sizeof(b), "%s DMA ERR\r\n", which);
    HAL_UART_Transmit(&huart1, (uint8_t*)b, n, 50);
}
