/* ads131m08.c
 * ADS131M08 STM32 HAL driver (datasheet-accurate)
 *
 * Key fixes vs previous draft:
 *  - Correct LOCK/UNLOCK command words (0x0555 / 0x0655)
 *  - MODE.WLENGTH encodings and 32-bit word framing
 *  - CLOCK.OSR and PWR fields; CHx enable bits (15..8)
 *  - CRC handling: device always appends an output CRC; host may verify
 *  - RESET command requires a full frame (no short frame)
 */

#include "ads131m08.h"
#include <string.h>

/* --------- Internal constants ---------- */
#define ADS_MAX_DEVICES          2u
#define FRAME_BYTES_24           ADS131M08_FRAME_BYTES_24
#define FRAME_BYTES_24_CRC       ADS131M08_FRAME_BYTES_24_WITH_CRC
#define FRAME_BYTES_32           ADS131M08_FRAME_BYTES_32

/* --------- Internal DMA state ---------- */
typedef struct {
    ADS131_Handle_t *h;
    uint8_t use_wl32;                 /* 0=24-bit, 1=32-bit (sign-extend recommended) */
    uint8_t rx[FRAME_BYTES_32];
    uint8_t tx[FRAME_BYTES_32];
    volatile uint8_t dma_active;
    volatile uint8_t frame_ready;
    volatile uint8_t dma_error;
} ads_dma_state_t;

static ads_dma_state_t s_states[ADS_MAX_DEVICES];
static ADS131_Handle_t *s_handles[ADS_MAX_DEVICES];
static uint8_t s_count = 0u;

/* --------- CRC (seed=0xFFFF) ---------- */
/* ANSI (0x8005) */
uint16_t ADS131M08_CalcCRC16_ANSI(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFu;
    for (uint16_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)((uint16_t)data[i] << 8);
        for (uint8_t b = 0; b < 8; ++b)
            crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x8005u) : (uint16_t)(crc << 1);
    }
    return crc;
}

/* CCITT (0x1021) */
uint16_t ADS131M08_CalcCRC16_CCITT(const uint8_t *data, uint16_t len)
{
    uint16_t crc = 0xFFFFu;
    for (uint16_t i = 0; i < len; ++i) {
        crc ^= (uint16_t)((uint16_t)data[i] << 8);
        for (uint8_t b = 0; b < 8; ++b)
            crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
    }
    return crc;
}

/* --------- small blocking TxRx helper ---------- */
static HAL_StatusTypeDef spi_txrx(SPI_HandleTypeDef *hspi, uint8_t *tx, uint8_t *rx, uint16_t n)
{
    return HAL_SPI_TransmitReceive(hspi, tx, rx, n, HAL_MAX_DELAY);
}

/* --------- state lookup ---------- */
static int find_state(ADS131_Handle_t *h)
{
    for (uint8_t i = 0; i < s_count; ++i)
        if (s_handles[i] == h) return (int)i;
    return -1;
}

/* --------- Commands / Reg access ---------- */
HAL_StatusTypeDef ADS131M08_SendCommand(ADS131_Handle_t *h, uint16_t cmd)
{
    if (!h || !h->hspi) return HAL_ERROR;

    /* RESET requires a full frame, others may work with short frames,
       but we always clock a full frame to keep parsing simple. */
    uint8_t tx[FRAME_BYTES_32] = {0};
    uint8_t rx[FRAME_BYTES_32] = {0};
    tx[0] = (uint8_t)(cmd >> 8);
    tx[1] = (uint8_t)(cmd & 0xFF);

    ADS131_CS_LOW(h);
    HAL_StatusTypeDef st = spi_txrx(h->hspi, tx, rx, FRAME_BYTES_32);
    ADS131_CS_HIGH(h);
    HAL_Delay(1);
    return st;
}

HAL_StatusTypeDef ADS131M08_WriteRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t value)
{
    if (!h || !h->hspi) return HAL_ERROR;

    /* Build a WREG frame header, then the 16-bit data word. We transmit a full frame. */
    uint16_t wreg = ADS131M08_CMD_WREG(addr, 1);
    uint8_t tx[FRAME_BYTES_32] = {0};
    uint8_t rx[FRAME_BYTES_32] = {0};
    tx[0] = (uint8_t)(wreg >> 8);
    tx[1] = (uint8_t)(wreg & 0xFF);
    /* For ADS131M08, the data word is 16-bit placed in the "command response" word position
       of the following frame. We just clock a full frame containing our data immediately: */
    tx[2] = (uint8_t)(value >> 8);
    tx[3] = (uint8_t)(value & 0xFF);

    ADS131_CS_LOW(h);
    HAL_StatusTypeDef st = spi_txrx(h->hspi, tx, rx, FRAME_BYTES_32);
    ADS131_CS_HIGH(h);
    HAL_Delay(1);
    return st;
}

HAL_StatusTypeDef ADS131M08_ReadRegister(ADS131_Handle_t *h, uint8_t addr, uint16_t *value)
{
    if (!h || !h->hspi || !value) return HAL_ERROR;

    uint16_t rreg = ADS131M08_CMD_RREG(addr, 1);
    uint8_t tx[FRAME_BYTES_32] = {0};
    uint8_t rx[FRAME_BYTES_32] = {0};

    /* Frame N: send RREG */
    tx[0] = (uint8_t)(rreg >> 8);
    tx[1] = (uint8_t)(rreg & 0xFF);
    ADS131_CS_LOW(h);
    if (spi_txrx(h->hspi, tx, rx, FRAME_BYTES_32) != HAL_OK) { ADS131_CS_HIGH(h); return HAL_ERROR; }
    ADS131_CS_HIGH(h);

    /* Frame N+1: shift out response (register contents appear in first response word) */
    memset(tx, 0, sizeof(tx));
    memset(rx, 0, sizeof(rx));
    ADS131_CS_LOW(h);
    if (spi_txrx(h->hspi, tx, rx, FRAME_BYTES_32) != HAL_OK) { ADS131_CS_HIGH(h); return HAL_ERROR; }
    ADS131_CS_HIGH(h);

    /* The device places the 16-bit RREG data in the command response word (bytes [0..1] here) */
    *value = ((uint16_t)rx[0] << 8) | (uint16_t)rx[1];
    return HAL_OK;
}

/* --------- Init sequence ----------
 * wl_32_signext: 0->24-bit frames, 1->32-bit (sign-extend) frames
 * clock_cfg: value to write to CLOCK (use macros to build)
 * mode_extra: additional MODE bits to OR with defaults (e.g., DRDY settings)
 */
HAL_StatusTypeDef ADS131M08_Init(ADS131_Handle_t *h, uint8_t wl_32_signext, uint32_t clock_cfg, uint16_t mode_extra)
{
    if (!h) return HAL_ERROR;

    ADS131_CS_HIGH(h);

    /* Optional hardware reset pin */
    if (h->RESET_Port) {
        HAL_GPIO_WritePin(h->RESET_Port, h->RESET_Pin, GPIO_PIN_RESET);
        HAL_Delay(5);
        HAL_GPIO_WritePin(h->RESET_Port, h->RESET_Pin, GPIO_PIN_SET);
        HAL_Delay(5);
    }

    /* RESET command (must clock a full frame) */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_RESET);
    HAL_Delay(2); /* tREGACQ: allow registers to assume defaults */

    /* UNLOCK to allow WREG */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_UNLOCK);
    HAL_Delay(1);

    /* MODE: start from defaults, configure WLENGTH and CRC type matching our verify setting */
    uint16_t mode = 0;
    /* Defaults after reset = 0x0510; we recompose explicitly: */
    /* Enable TIMEOUT, choose DRDY level or pulse via mode_extra, set WLENGTH */
    mode |= ADS131M08_MODE_TIMEOUT_EN;
    if (wl_32_signext)  mode |= ADS131M08_MODE_WLENGTH_32_SE;
    else                mode |= ADS131M08_MODE_WLENGTH_24;

    /* Choose CRC type to match h->crc_type */
    if (h->crc_type == ADS131M08_CRC_ANSI) mode |= ADS131M08_MODE_CRC_TYPE_ANSI;

    /* Optionally enable input CRC checking (host must append input CRC to commands if enabled). We keep disabled by default. */
    if (mode_extra & ADS131M08_MODE_RX_CRC_EN) mode |= ADS131M08_MODE_RX_CRC_EN;

    /* Merge DRDY options and any other fields from caller */
    mode |= (mode_extra & (ADS131M08_MODE_REG_CRC_EN | ADS131M08_MODE_DRDY_SEL_Msk |
                           ADS131M08_MODE_DRDY_HIZ | ADS131M08_MODE_DRDY_FMT_PULSE));

    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_MODE, mode);

    /* CLOCK: OSR + PWR + channel enables (caller provides full value) */
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_CLOCK, (uint16_t)clock_cfg);

    /* Unity gain by default */
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_GAIN1, 0x0000u);
    (void)ADS131M08_WriteRegister(h, ADS131M08_REG_GAIN2, 0x0000u);

    /* LOCK back (optional) */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_LOCK);
    HAL_Delay(1);

    /* WAKEUP to ensure conversion mode (if coming from standby) */
    (void)ADS131M08_SendCommand(h, ADS131M08_CMD_WAKEUP);
    HAL_Delay(1);

    return HAL_OK;
}

/* --------- Blocking read of one frame ---------- */
HAL_StatusTypeDef ADS131M08_ReadDataFrame_Blocking(ADS131_Handle_t *h, int32_t samples[ADS131M08_NUM_CHANNELS])
{
    if (!h || !h->hspi || !samples) return HAL_ERROR;

    uint8_t tx[FRAME_BYTES_32] = {0};
    uint8_t rx[FRAME_BYTES_32] = {0};

    ADS131_CS_LOW(h);
    HAL_StatusTypeDef st = spi_txrx(h->hspi, tx, rx, FRAME_BYTES_32);
    ADS131_CS_HIGH(h);
    if (st != HAL_OK) return st;

    /* Parse 32-bit words: word0=status, words1..8=CH0..7, word9=CRC (16-bit inside) */
    for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
        uint8_t *w = &rx[(1u + ch) * 4u];
        int32_t v = (int32_t)((uint32_t)w[0] << 24 |
                              (uint32_t)w[1] << 16 |
                              (uint32_t)w[2] <<  8 |
                              (uint32_t)w[3]);
        samples[ch] = v; /* in WL=32_SE this is sign-extended 24-bit */
    }

    if (h->verify_crc) {
        uint16_t rx_crc = ((uint16_t)rx[FRAME_BYTES_32 - 4] << 8) | (uint16_t)rx[FRAME_BYTES_32 - 3];
        /* CRC covers all bytes before the CRC word. Choose algorithm by MODE.CRC_TYPE we set. */
        uint16_t calc = (h->crc_type == ADS131M08_CRC_ANSI)
                        ? ADS131M08_CalcCRC16_ANSI(rx, FRAME_BYTES_32 - 4)
                        : ADS131M08_CalcCRC16_CCITT(rx, FRAME_BYTES_32 - 4);
        if (rx_crc != calc) return HAL_ERROR;
    }
    return HAL_OK;
}

/* --------- DMA streaming path ---------- */
static void register_handle(ADS131_Handle_t *h, uint8_t use_wl32)
{
    if (s_count >= ADS_MAX_DEVICES) return;
    s_handles[s_count] = h;
    ads_dma_state_t *s = &s_states[s_count];
    memset(s, 0, sizeof(*s));
    s->h = h;
    s->use_wl32 = use_wl32;
    s_count++;
}

void ADS131M08_GlobalDMAInit(ADS131_Handle_t *h1, ADS131_Handle_t *h2, uint8_t use_wl32)
{
    s_count = 0u;
    if (h1) register_handle(h1, use_wl32);
    if (h2) register_handle(h2, use_wl32);
}

void ADS131M08_StartDMAFrameRead(ADS131_Handle_t *h)
{
    if (!h || !h->hspi) return;
    int i = find_state(h);
    if (i < 0) return;
    ads_dma_state_t *s = &s_states[i];
    if (s->dma_active) return;

    memset(s->tx, 0, sizeof(s->tx));
    s->frame_ready = 0;
    s->dma_error = 0;

    ADS131_CS_LOW(h);
    if (HAL_SPI_TransmitReceive_DMA(h->hspi, s->tx, s->rx, FRAME_BYTES_32) == HAL_OK) {
        s->dma_active = 1;
    } else {
        ADS131_CS_HIGH(h);
        s->dma_active = 0;
        s->dma_error  = 1;
    }
}

void ADS131M08_DMA_CompleteCallback(SPI_HandleTypeDef *hspi)
{
    if (!hspi) return;
    for (uint8_t i = 0; i < s_count; ++i) {
        ads_dma_state_t *s = &s_states[i];
        if (s->h && s->h->hspi == hspi) {
            ADS131_CS_HIGH(s->h);
            s->dma_active = 0;
            s->frame_ready = 1;
            return;
        }
    }
}

bool ADS131M08_FrameReady(ADS131_Handle_t *h)
{
    int i = find_state(h);
    if (i < 0) return false;
    return s_states[i].frame_ready != 0;
}

void ADS131M08_ParseReadyFrame(ADS131_Handle_t *h, int32_t out_samples[ADS131M08_NUM_CHANNELS])
{
    if (!h || !out_samples) return;
    int i = find_state(h);
    if (i < 0) return;
    ads_dma_state_t *s = &s_states[i];
    if (!s->frame_ready) return;

    /* Parse channels from the DMA RX buffer */
    for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) {
        uint8_t *w = &s->rx[(1u + ch) * 4u];
        int32_t v = (int32_t)((uint32_t)w[0] << 24 |
                              (uint32_t)w[1] << 16 |
                              (uint32_t)w[2] <<  8 |
                              (uint32_t)w[3]);
        out_samples[ch] = v;
    }

    if (h->verify_crc) {
        uint16_t rx_crc = ((uint16_t)s->rx[FRAME_BYTES_32 - 4] << 8) | (uint16_t)s->rx[FRAME_BYTES_32 - 3];
        uint16_t calc = (h->crc_type == ADS131M08_CRC_ANSI)
                        ? ADS131M08_CalcCRC16_ANSI(s->rx, FRAME_BYTES_32 - 4)
                        : ADS131M08_CalcCRC16_CCITT(s->rx, FRAME_BYTES_32 - 4);
        if (rx_crc != calc) {
            s->dma_error = 1;
            for (uint8_t ch = 0; ch < ADS131M08_NUM_CHANNELS; ++ch) out_samples[ch] = 0;
        }
    }

    s->frame_ready = 0;
}

/* --------- Utilities ---------- */
float ADS131M08_CountsToVoltage(int32_t counts, float vref, uint8_t pga_gain)
{
    /* Differential full-scale is +/- (vref / gain) at ADC input (see front-end notes). */
    float fs = vref / (float)(pga_gain ? pga_gain : 1);
    return ((float)counts) * (fs / (float)ADS131M08_FULLSCALE_COUNTS);
}
