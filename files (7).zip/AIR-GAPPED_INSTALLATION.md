# 🔌 AIR-GAPPED INSTALLATION GUIDE
## Download on Connected PC → Transfer to Offline PC

---

## OVERVIEW

Your situation:
- ✅ Offline PC: Has VS Code ready, no internet
- ❌ Offline PC: Cannot download anything
- ✅ Connected PC: Has internet, can download
- 🎯 Goal: Download all dependencies on connected PC, transfer via USB drive

This guide walks through:
1. What to download on connected PC
2. How to organize downloads
3. What to install on offline PC (in correct order)
4. How to set up the project

---

## STEP 1: CONNECTED PC - Download Everything

You'll need a **USB flash drive (32 GB+)** for all downloads (~9 GB total).

### A. Visual Studio Community 2022 Installer

**On connected PC:**

1. Go to: https://visualstudio.microsoft.com/vs/community/
2. Click "Download Visual Studio Community 2022"
3. Run downloaded installer `vs_community__xxxx.exe`
4. **IMPORTANT:** Do NOT click "Install" yet!
5. Select: "Download all → Install later"
6. Choose location: Your USB drive (e.g., `D:\VS2022_Installer\`)
7. Wait for complete download (~5-6 GB)
8. When done, you'll have `D:\VS2022_Installer\` folder with all files

**Size:** ~5-6 GB

---

### B. Qt 6.9.2 Full Installation

**This is tricky because Qt requires account login!**

**Option 1: Download Qt Installer (Easiest)**

1. Go to: https://www.qt.io/download-qt-installer
2. Download: `qt-unified-windows-x64-xxxx-online-installer.exe`
3. Copy to USB: `D:\Qt_Installer\`

**BUT:** This is only the **online installer** (~200 MB) — it will still try to download Qt files during installation.

**Option 2: Use Qt Maintenance Tool (Better for offline)**

If you have Qt installed on connected PC already:
1. Run: `C:\Qt\MaintenanceTool.exe`
2. Select: "Create offline installer"
3. Choose: Qt 6.9.2, MSVC 2022 64-bit, Qt Serial Port
4. Save to: `D:\Qt_Offline\`
5. Wait for download (~2-3 GB)

**Option 3: Download via Command Line (Advanced)**

```powershell
# Install aqtinstall (Python tool for offline Qt downloads)
pip install aqtinstall

# Download Qt 6.9.2 for MSVC 2022
aqt install-qt windows desktop 6.9.2 win64_msvc2022_64 -m serial -O D:\Qt_6.9.2\

# This downloads everything you need
# Takes 30-60 minutes
# Size: ~3 GB
```

**Size:** 2-3 GB

---

### C. CMake

**On connected PC:**

1. Go to: https://cmake.org/download/
2. Download: `cmake-3.xx.x-windows-x86_64.msi`
3. Copy to USB: `D:\CMake\`

**Size:** ~100 MB

---

### D. Ninja (Optional but Recommended)

**On connected PC:**

1. Go to: https://github.com/ninja-build/ninja/releases
2. Download latest: `ninja-win.zip`
3. Copy to USB: `D:\Ninja\`

**Size:** ~500 KB

---

### E. velocity_radar.zip Project

You already have this — copy to USB:
```
D:\Project\velocity_radar.zip
```

---

## USB DRIVE ORGANIZATION

After downloading, your USB should look like:

```
D:\ (USB Drive)
├── VS2022_Installer/          (5-6 GB)
│   ├── VisualStudio/
│   ├── installer/
│   └── (many more folders)
│
├── Qt_6.9.2/                  (2-3 GB, if using Option 3)
│   ├── 6.9.2/
│   ├── msvc2022_64/
│   └── ... (all Qt files)
│
├── Qt_Installer/              (200 MB, if using Option 1)
│   └── qt-unified-windows-x64-xxx-online-installer.exe
│
├── CMake/                      (100 MB)
│   └── cmake-3.xx.x-windows-x86_64.msi
│
├── Ninja/                      (500 KB)
│   └── ninja-win.zip
│
└── Project/                    (21 KB)
    └── velocity_radar.zip
```

**Total USB Size Used:** ~8-10 GB (so 32 GB USB is safe)

---

## STEP 2: TRANSFER TO OFFLINE PC

1. Plug USB drive into offline PC
2. Copy entire USB contents to: `C:\OfflineSetup\`
3. You now have all downloads locally!

---

## STEP 3: OFFLINE PC - Install Everything

### Install Order Matters!

```
1. Visual Studio 2022 (compiler)
   ↓
2. Qt 6.9.2 (framework)
   ↓
3. CMake (build tool)
   ↓
4. Ninja (optional, faster builds)
   ↓
5. Extract velocity_radar.zip
   ↓
6. Open in VS Code
   ↓
7. Build!
```

---

## DETAILED INSTALLATION STEPS (Offline PC)

### 1️⃣ Install Visual Studio Community 2022

**From offline files:**

```powershell
# Navigate to downloaded installer
cd C:\OfflineSetup\VS2022_Installer\

# Find the main installer executable
# It's named something like: vs_community__xxxxx.exe

# Run it:
.\vs_community__xxxxx.exe
```

**During installation:**
1. Select: "Desktop development with C++"
2. Click "Install"
3. Wait 30-60 minutes (it's installing locally, not downloading)
4. When done, restart PC

**Verify:**
```powershell
# Open "x64 Native Tools Command Prompt for VS 2022"
cl.exe --version
# Should show: Microsoft (R) C/C++ Optimizing Compiler Version 19.xx
```

---

### 2️⃣ Install Qt 6.9.2

**If you used Option 3 (complete offline download):**

```powershell
# Navigate to Qt folder
cd C:\OfflineSetup\Qt_6.9.2\

# Copy to C:\Qt\ (standard location)
# You may need to do this via File Explorer:
#   Source: C:\OfflineSetup\Qt_6.9.2\6.9.2
#   Destination: C:\Qt\6.9.2\

# This is just copying files locally (no download needed)
# Takes 10-20 minutes
```

**Verify:**
```powershell
dir "C:\Qt\6.9.2\msvc2022_64\bin\qmake.exe"
# Should exist

dir "C:\Qt\6.9.2\msvc2022_64\lib\cmake\Qt6SerialPort"
# Should exist (SerialPort module)
```

**If you used Option 1 (online installer):**

```powershell
# You'll need to run the installer, but it might try to download
cd C:\OfflineSetup\Qt_Installer\

# Run the installer
.\qt-unified-windows-x64-xxx-online-installer.exe

# When it tries to download:
# - Plug USB drive back in
# - Point to local cache folder on USB
# - This is more complex; Option 3 is recommended instead
```

---

### 3️⃣ Install CMake

**From offline files:**

```powershell
# Navigate to CMake installer
cd C:\OfflineSetup\CMake\

# Run the installer
.\cmake-3.xx.x-windows-x86_64.msi

# During installation:
# ☑ Check "Add CMake to system PATH"
# Click Install
```

**Verify:**
```powershell
cmake --version
# Should show: cmake version 3.xx.x
```

---

### 4️⃣ Install Ninja (Optional)

**From offline files:**

```powershell
# Extract ninja.zip
cd C:\OfflineSetup\Ninja\
Expand-Archive ninja-win.zip -DestinationPath "C:\Program Files\Ninja\"

# Add to PATH:
# Win+X → System → Advanced system settings
# → Environment Variables → Edit PATH
# → Add: C:\Program Files\Ninja
# → OK → Restart PC
```

**Verify (after restart):**
```powershell
ninja --version
# Should show: 1.xx.x
```

---

### 5️⃣ Extract Project

```powershell
# Navigate to project archive
cd C:\OfflineSetup\Project\

# Extract velocity_radar.zip
Expand-Archive velocity_radar.zip -DestinationPath "C:\MyProjects\"

# Result:
# C:\MyProjects\velocity_radar\
#   ├── CMakeLists.txt
#   ├── src\
#   └── ... (all source files)
```

---

## STEP 4: OFFLINE PC - Configure VS Code

Since you have VS Code already running, now configure it for this project:

### A. Open Project in VS Code

```powershell
cd C:\MyProjects\velocity_radar
code .
```

OR in VS Code:
- File → Open Folder
- Select: `C:\MyProjects\velocity_radar`

### B. Install VS Code Extensions (If Not Already Done)

Since you can't browse extensions online, you need the .vsix files.

**On connected PC:**
1. Download extensions as .vsix files
2. Copy to USB: `D:\VSCode_Extensions\`

**Required extensions:**
- C/C++ Extension Pack (Microsoft)
- CMake Tools (Microsoft)
- CMake (Microsoft)

**On offline PC:**
```powershell
# In VS Code:
# Ctrl + Shift + X (Extensions panel)
# Click "..." menu → Install from VSIX
# Select each .vsix file from USB

# Or via command line:
code --install-extension C:\OfflineSetup\VSCode_Extensions\ms-vscode.cpptools-1.xx.x.vsix
code --install-extension C:\OfflineSetup\VSCode_Extensions\ms-vscode.cmake-tools-1.xx.x.vsix
code --install-extension C:\OfflineSetup\VSCode_Extensions\ms-vscode.cmake-1.xx.x.vsix
```

### C. Create .vscode Configuration Files

Create these files in `C:\MyProjects\velocity_radar\.vscode\`:

**File 1: settings.json**
```json
{
    "C_Cpp.default.cppStandard": "c++17",
    "C_Cpp.default.cCompilerPath": "cl.exe",
    "C_Cpp.default.compilerPath": "cl.exe",
    "C_Cpp.default.intelliSenseEngine": "default",
    "cmake.configureOnOpen": true,
    "cmake.buildDirectory": "${workspaceFolder}/build",
    "cmake.preferredGenerator": "Ninja Multi-Config",
    "cmake.generator": "Ninja Multi-Config",
    "cmake.cmakePath": "cmake.exe"
}
```

**File 2: cmake-kits.json**
```json
[
    {
        "name": "Visual Studio Community 2022 - MSVC + Qt 6.9",
        "description": "MSVC 2022 with Qt 6.9.2 (x64)",
        "toolchainFile": null,
        "compilers": {
            "C": "cl.exe",
            "CXX": "cl.exe"
        },
        "cmakeSettings": {
            "CMAKE_PREFIX_PATH": "C:/Qt/6.9.2/msvc2022_64",
            "CMAKE_BUILD_TYPE": "Debug"
        },
        "environmentVariables": {
            "Qt6_DIR": "C:/Qt/6.9.2/msvc2022_64"
        }
    }
]
```

---

## STEP 5: OFFLINE PC - Build the Project

### A. Select CMake Kit

In VS Code:
1. Press: `Ctrl + Shift + P`
2. Type: `CMake: Select a Kit`
3. Choose: `Visual Studio Community 2022 - MSVC + Qt 6.9`

### B. Configure CMake

```
Ctrl + Shift + P → CMake: Configure
```

**Expected output:**
```
[main] Configuring folder: velocity_radar
[main] Invoking CMake
[main] CMake /path/to/CMakeLists.txt
[main] Configuring done
```

❌ **Error: "Qt6 not found"?**
- Verify: `C:\Qt\6.9.2\msvc2022_64\` exists
- Check cmake-kits.json CMAKE_PREFIX_PATH
- Run: `CMake: Delete Cache and Reconfigure`

### C. Build the Project

```
Ctrl + Shift + P → CMake: Build
```

**Expected output:**
```
[build] Building folder: velocity_radar
[build] cmake --build build --config Debug
[build] Built target VelocityRadar
[main] Build finished with exit code 0
```

### D. Run the Application

```
Ctrl + F5    (Debug with breakpoints)
OR
Ctrl + Shift + B   (Build only)
```

**App should launch!** 🎉

---

## TROUBLESHOOTING OFFLINE ISSUES

### Issue: CMake Says "Qt6 not found"

**Cause:** Qt path incorrect or Qt not in right location

**Fix:**
```powershell
# Verify Qt files exist:
dir "C:\Qt\6.9.2\msvc2022_64\lib\cmake\Qt6"

# If they don't exist, you need to re-download Qt properly
# Go back to Step 1 Option 3 (aqtinstall method)

# Or manually verify files:
dir "C:\Qt\6.9.2\msvc2022_64\bin\qmake.exe"
dir "C:\Qt\6.9.2\msvc2022_64\lib"
```

---

### Issue: "cl.exe not found" (MSVC Compiler)

**Cause:** Visual Studio not installed or not in PATH

**Fix:**
```powershell
# Verify Visual Studio installed:
dir "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Tools\MSVC"

# Run x64 Native Tools Command Prompt:
# Start Menu → "x64 Native Tools Command Prompt for VS 2022"
# Type: cl.exe --version

# If works here but not in VS Code:
# Restart VS Code
# Restart PC
```

---

### Issue: CMake Configure Works, But Build Fails

**Cause:** SerialPort module missing from Qt

**Fix:**
```
If you used Option 1 (online installer):
- You need to use Option 3 instead (aqtinstall)
- Or manually install SerialPort from Qt Installer

Verify it exists:
dir "C:\Qt\6.9.2\msvc2022_64\lib\cmake\Qt6SerialPort"
```

---

### Issue: Ninja Not Found (But build works with MSBuild)

**Cause:** Ninja not installed (optional anyway)

**Fix:** No problem! Just change cmake-kits.json:
```json
"cmake.preferredGenerator": "Visual Studio 17 2022"
```

Builds will be slower but work fine.

---

## SUMMARY: YOUR WORKFLOW

```
1. CONNECTED PC (with internet):
   ├─ Download VS2022, Qt6.9.2, CMake, Ninja
   ├─ Copy everything to USB drive
   └─ Transfer USB to offline PC

2. OFFLINE PC:
   ├─ Install Visual Studio 2022
   ├─ Install Qt 6.9.2 (copy files)
   ├─ Install CMake
   ├─ Install Ninja (optional)
   ├─ Extract velocity_radar.zip
   ├─ Configure VS Code (create .vscode files)
   ├─ Open project in VS Code
   ├─ Select CMake Kit
   ├─ Build (Ctrl + Shift + P → CMake: Build)
   └─ Run (Ctrl + F5)

3. READY TO USE:
   └─ App launches
   └─ Connect to your radar system
   └─ Use all 11 commands
```

---

## WHAT IF YOU DON'T HAVE ALL 32GB?

If your USB is smaller, here's the priority:

**MUST HAVE (7 GB minimum):**
1. VS2022 (5-6 GB) — ESSENTIAL
2. Qt 6.9.2 (2-3 GB) — ESSENTIAL
3. velocity_radar.zip (21 KB) — ESSENTIAL

**NICE TO HAVE:**
4. CMake (100 MB) — Can install online later
5. Ninja (500 KB) — Optional, not critical
6. VS Code Extensions .vsix files (100 MB) — Can install online later

**Strategy:** Use a 32 GB or larger USB, or make two transfers.

---

## FINAL CHECKLIST

**Connected PC:**
- ☐ Downloaded VS2022 installer (~5-6 GB)
- ☐ Downloaded or created offline Qt 6.9.2 (~2-3 GB)
- ☐ Downloaded CMake installer (~100 MB)
- ☐ Downloaded Ninja binary (~500 KB)
- ☐ Copied velocity_radar.zip (~21 KB)
- ☐ Organized on USB drive
- ☐ Transferred USB to offline PC

**Offline PC:**
- ☐ VS Code already running ✅
- ☐ Installed Visual Studio 2022
- ☐ Installed Qt 6.9.2 to C:\Qt\6.9.2\
- ☐ Installed CMake
- ☐ Installed Ninja (optional)
- ☐ Extracted velocity_radar.zip
- ☐ Created .vscode/settings.json
- ☐ Created .vscode/cmake-kits.json
- ☐ CMake Kit selected in VS Code
- ☐ Project builds successfully
- ☐ App runs!

---

## YOU'RE READY! 🚀

Once everything is installed on your offline PC:
1. Open VS Code with project
2. Select CMake Kit: "Visual Studio Community 2022 - MSVC + Qt 6.9"
3. Build: `Ctrl + Shift + P` → `CMake: Build`
4. Run: `Ctrl + F5`
5. Connect to your radar system!

No internet needed on offline PC anymore! 🔌

---

## QUICK REFERENCE: Download Links for Connected PC

```
Visual Studio 2022:
  https://visualstudio.microsoft.com/vs/community/

Qt 6.9.2 (if using aqtinstall):
  pip install aqtinstall
  aqt install-qt windows desktop 6.9.2 win64_msvc2022_64 -m serial

CMake:
  https://cmake.org/download/

Ninja:
  https://github.com/ninja-build/ninja/releases

velocity_radar.zip:
  (You already have this)
```

Good luck! 🚀
