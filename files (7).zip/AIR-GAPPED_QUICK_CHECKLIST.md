# ✅ AIR-GAPPED INSTALLATION CHECKLIST

## Your Situation
- ✅ Offline PC: Has VS Code ready
- ✅ Connected PC: Has internet
- 🎯 Goal: Download all software on connected PC, transfer to offline PC via USB

---

## PART 1: CONNECTED PC (Has Internet)

### 📥 Downloads Required

```
☐ USB Flash Drive (32 GB+)
☐ Visual Studio Community 2022 installer
☐ Qt 6.9.2 (complete offline files)
☐ CMake installer
☐ Ninja binary (optional)
☐ velocity_radar.zip (you already have)
```

### 🔗 Download Links to Use

**Visual Studio 2022 (5-6 GB):**
```
https://visualstudio.microsoft.com/vs/community/

Step: Click "Download" → Run installer → 
      Select "Download all → Install later" → 
      Choose USB drive location
```

**Qt 6.9.2 Offline (2-3 GB) - RECOMMENDED METHOD:**
```
1. Install aqtinstall on connected PC:
   pip install aqtinstall

2. Download Qt offline package:
   aqt install-qt windows desktop 6.9.2 win64_msvc2022_64 -m serial -O D:\Qt_6.9.2\
   
   Takes: 30-60 minutes
   Size: ~3 GB
   Result: D:\Qt_6.9.2\ contains all files
   
3. Copy D:\Qt_6.9.2\ to USB
```

**CMake (100 MB):**
```
https://cmake.org/download/

Download: cmake-3.xx.x-windows-x86_64.msi
Copy to USB: D:\CMake\
```

**Ninja (500 KB) - Optional:**
```
https://github.com/ninja-build/ninja/releases

Download: ninja-win.zip
Copy to USB: D:\Ninja\
```

**velocity_radar.zip (21 KB):**
```
You already have this from the original delivery
Copy to USB: D:\Project\velocity_radar.zip
```

### 📁 USB Organization

After downloads, USB should look like:

```
D:\ (USB Drive)
├── VS2022_Installer/               [5-6 GB]
│   ├── VisualStudio/
│   ├── installer/
│   └── (many folders with VS files)
│
├── Qt_6.9.2/                       [2-3 GB]
│   ├── 6.9.2/
│   ├── msvc2022_64/
│   └── (all Qt framework files)
│
├── CMake/                          [100 MB]
│   └── cmake-3.xx.x-windows-x86_64.msi
│
├── Ninja/                          [500 KB]
│   └── ninja-win.zip
│
└── Project/                        [21 KB]
    └── velocity_radar.zip

TOTAL: ~8-10 GB (32 GB USB is safe)
```

### ✅ Connected PC Checklist

```
☐ Visual Studio 2022 downloaded to USB (5-6 GB)
☐ Qt 6.9.2 downloaded to USB (2-3 GB)
   ☐ Verify: C:\Qt_6.9.2\6.9.2\bin\qmake.exe exists
   ☐ Verify: C:\Qt_6.9.2\6.9.2\lib\cmake\Qt6SerialPort exists
☐ CMake downloaded to USB (100 MB)
☐ Ninja downloaded to USB (500 KB) [optional]
☐ velocity_radar.zip copied to USB (21 KB)
☐ USB organized in folders (shown above)
☐ USB drive safely ejected
```

---

## PART 2: TRANSFER TO OFFLINE PC

### 🔌 Physical Transfer

```
1. Plug USB into offline PC
2. Copy entire USB to:
   C:\OfflineSetup\
3. Folder should look like:
   C:\OfflineSetup\
   ├── VS2022_Installer/
   ├── Qt_6.9.2/
   ├── CMake/
   ├── Ninja/
   └── Project/
4. Eject USB (can now use for other things)
```

---

## PART 3: OFFLINE PC (No Internet Needed)

### 1️⃣ Install Visual Studio 2022

```
Command line:
cd C:\OfflineSetup\VS2022_Installer\
.\vs_community__xxxxx.exe

GUI steps:
1. Click "Desktop development with C++"
2. Click "Install"
3. Wait 30-60 minutes (local install, not downloading)
4. When done: Restart PC

Verify:
Open: "x64 Native Tools Command Prompt for VS 2022"
Type: cl.exe --version
Expected: "Microsoft (R) C/C++ Optimizing Compiler Version 19.xx"
```

☐ Visual Studio 2022 installed & verified

---

### 2️⃣ Install Qt 6.9.2

```
File Explorer:
1. Source: C:\OfflineSetup\Qt_6.9.2\6.9.2
2. Destination: C:\Qt\6.9.2
3. Copy (takes 10-20 minutes)

Verify file exists:
dir C:\Qt\6.9.2\msvc2022_64\bin\qmake.exe
dir C:\Qt\6.9.2\msvc2022_64\lib\cmake\Qt6SerialPort

Both should exist!
```

☐ Qt 6.9.2 installed & verified (qmake.exe exists)
☐ SerialPort module verified (Qt6SerialPort folder exists)

---

### 3️⃣ Install CMake

```
Command line:
cd C:\OfflineSetup\CMake\
.\cmake-3.xx.x-windows-x86_64.msi

GUI steps:
1. During installation: CHECK "Add CMake to system PATH"
2. Click Install
3. When done: Restart PC

Verify (after restart):
Command prompt:
cmake --version
Expected: "cmake version 3.xx.x"
```

☐ CMake installed & verified

---

### 4️⃣ Install Ninja (Optional)

```
Command line:
cd C:\OfflineSetup\Ninja\
Expand-Archive ninja-win.zip -DestinationPath "C:\Program Files\Ninja\"

Add to PATH:
1. Win+X → System
2. Advanced system settings
3. Environment Variables
4. Edit PATH variable
5. Add: C:\Program Files\Ninja
6. Click OK
7. Restart PC

Verify (after restart):
Command prompt:
ninja --version
Expected: "1.xx.x"
```

☐ Ninja installed & verified [optional]

---

### 5️⃣ Extract velocity_radar.zip

```
Command line:
cd C:\OfflineSetup\Project\
Expand-Archive velocity_radar.zip -DestinationPath "C:\MyProjects\"

Result:
C:\MyProjects\velocity_radar\
├── CMakeLists.txt
├── src\
│   ├── main.cpp
│   ├── mainwindow.cpp
│   ├── serialcomm.cpp
│   ├── messagebuilder.cpp
│   ├── messageparser.cpp
│   ├── expectedvdialog.cpp
│   ├── protocol.h
│   └── ui\
│       ├── mainwindow.ui
│       └── expected_v.ui
└── build\ (created after first build)
```

☐ velocity_radar.zip extracted to C:\MyProjects\

---

### 6️⃣ Configure VS Code

**Create file: C:\MyProjects\velocity_radar\.vscode\settings.json**

```json
{
    "C_Cpp.default.cppStandard": "c++17",
    "C_Cpp.default.cCompilerPath": "cl.exe",
    "C_Cpp.default.compilerPath": "cl.exe",
    "C_Cpp.default.intelliSenseEngine": "default",
    "cmake.configureOnOpen": true,
    "cmake.buildDirectory": "${workspaceFolder}/build",
    "cmake.preferredGenerator": "Ninja Multi-Config",
    "cmake.generator": "Ninja Multi-Config",
    "cmake.cmakePath": "cmake.exe"
}
```

**Create file: C:\MyProjects\velocity_radar\.vscode\cmake-kits.json**

```json
[
    {
        "name": "Visual Studio Community 2022 - MSVC + Qt 6.9",
        "description": "MSVC 2022 with Qt 6.9.2 (x64)",
        "toolchainFile": null,
        "compilers": {
            "C": "cl.exe",
            "CXX": "cl.exe"
        },
        "cmakeSettings": {
            "CMAKE_PREFIX_PATH": "C:/Qt/6.9.2/msvc2022_64",
            "CMAKE_BUILD_TYPE": "Debug"
        },
        "environmentVariables": {
            "Qt6_DIR": "C:/Qt/6.9.2/msvc2022_64"
        }
    }
]
```

☐ settings.json created
☐ cmake-kits.json created

---

### 7️⃣ Open in VS Code

```powershell
cd C:\MyProjects\velocity_radar
code .
```

OR:
1. Launch VS Code
2. File → Open Folder
3. Select: C:\MyProjects\velocity_radar
4. Wait for folder to load

☐ Project opened in VS Code

---

### 8️⃣ Select CMake Kit

In VS Code:

```
1. Ctrl + Shift + P
2. Type: CMake: Select a Kit
3. Choose: "Visual Studio Community 2022 - MSVC + Qt 6.9"
4. Wait for VS Code to show "CMake Tools: ready"
```

Expected output in VS Code Output panel:
```
[main] Configuring folder: velocity_radar
[main] Invoking CMake
[main] CMake /path/to/CMakeLists.txt
[main] Preset: default
[main] Build directory: velocity_radar/build
[main] Configuring done
```

❌ Error: "Qt6 not found"?
```
Fix:
1. Verify C:\Qt\6.9.2\msvc2022_64\ exists
2. Verify CMAKE_PREFIX_PATH in cmake-kits.json
3. Ctrl + Shift + P → CMake: Delete Cache and Reconfigure
4. Try again
```

☐ CMake Kit selected
☐ CMake configured (no errors)

---

### 9️⃣ Build the Project

In VS Code:

```
Ctrl + Shift + P → CMake: Build
```

Expected output:
```
[build] Building folder: velocity_radar
[build] cmake --build build --config Debug
[build] Built target VelocityRadar
[main] Build finished with exit code 0
```

❌ Build fails?
Check AIR-GAPPED_INSTALLATION.md → TROUBLESHOOTING section

☐ Project builds successfully

---

### 🔟 Run the Application

In VS Code:

```
Ctrl + F5    (Debug with breakpoints)
```

Expected:
- App window opens
- Title: "Velocity Radar Control"
- Status: "⚫ Disconnected" (red)
- State: "State: IDLE"
- Log panel shows initialization messages

☐ Application runs successfully

---

## FINAL VERIFICATION

### ✅ Everything Working?

```
☐ Visual Studio 2022 compiler (cl.exe works)
☐ Qt 6.9.2 installed (C:\Qt\6.9.2\ exists)
☐ SerialPort module present (Qt6SerialPort folder exists)
☐ CMake installed & in PATH
☐ Ninja installed & in PATH (optional)
☐ velocity_radar.zip extracted
☐ VS Code has .vscode/ configuration files
☐ VS Code opens project without errors
☐ CMake configures successfully
☐ Project builds without errors
☐ VelocityRadar.exe exists (C:\MyProjects\velocity_radar\build\Debug\)
☐ Application launches
☐ Com ports auto-detected
```

---

## 🚀 YOU'RE READY!

Next steps:
1. Connect your USB-to-RS422 adapter to the offline PC
2. Click "↻ Refresh" in app to detect COM port
3. Select COM port from dropdown
4. Click "Connect"
5. Click command buttons to test
6. Watch logs for responses

**No internet needed on offline PC anymore!** 🔌

---

## 💡 NOTES

- **First build time:** 1-2 minutes (slower on first build)
- **Rebuild time:** 10-30 seconds (faster on changes)
- **Total USB needed:** 32 GB (you'll use ~8-10 GB)
- **No network:** Completely offline after installation
- **Air-gapped:** Downloaded once, transferred once, works forever

---

## 🔧 TROUBLESHOOTING QUICK LINKS

| Problem | Section |
|---------|---------|
| Qt6 not found | AIR-GAPPED_INSTALLATION.md → Troubleshooting |
| cl.exe not found | Visual Studio 2022 not installed |
| Ninja not found | Optional - can use MSBuild instead |
| Build fails | Check AIR-GAPPED_INSTALLATION.md Troubleshooting |
| App won't start | Run from command line to see error message |
| COM port not detected | Check Device Manager, install USB adapter driver |

---

**Good luck! All software is now on your offline PC. No internet needed anymore!** 🚀
