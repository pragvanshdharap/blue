# 📥 EXACT DOWNLOAD COMMANDS - Connected PC

Use these exact commands on your **connected PC with internet** to download everything needed for offline PC.

---

## PREREQUISITES (Connected PC)

```powershell
# Install Python package for Qt downloads (one-time)
pip install aqtinstall

# Verify installation
aqt --version
```

---

## DOWNLOAD PROCEDURE

### Step 1: Prepare USB Drive

```powershell
# Plug in USB drive (let's say it's D:)

# Create folder structure on USB
mkdir D:\DownloadedSoftware\
mkdir D:\DownloadedSoftware\VS2022_Installer
mkdir D:\DownloadedSoftware\Qt_6.9.2
mkdir D:\DownloadedSoftware\CMake
mkdir D:\DownloadedSoftware\Ninja
mkdir D:\DownloadedSoftware\Project

# Verify structure
dir D:\DownloadedSoftware\
```

---

## DOWNLOAD 1: Visual Studio Community 2022 (5-6 GB)

### Option A: Using Browser (Easiest)

```
1. Open browser: https://visualstudio.microsoft.com/vs/community/
2. Click big blue "Download" button
3. Run downloaded file: vs_community__xxxx.exe

IMPORTANT: When installer opens, select:
   → "Download all, then install"
   → Choose location: D:\DownloadedSoftware\VS2022_Installer\
   
4. Wait for download to complete (may take 1-2 hours)
5. DO NOT CLICK INSTALL
6. Close installer when done
```

### Option B: Using Command Line (Advanced)

```powershell
# This requires Visual Studio bootstrapper
# Recommended to use Option A instead
# But if you want:

cd D:\DownloadedSoftware\VS2022_Installer\

# Download command (requires VS installer already downloaded from Option A)
# Just do Option A, it's easier
```

---

## DOWNLOAD 2: Qt 6.9.2 Offline (2-3 GB) - RECOMMENDED

### Use aqtinstall (Best for Air-Gapped)

```powershell
# This downloads Qt 6.9.2 complete offline package

cd D:\DownloadedSoftware\Qt_6.9.2\

# Download Qt 6.9.2 with Serial Port module
aqt install-qt windows desktop 6.9.2 win64_msvc2022_64 -m serial

# This command:
# - Downloads Qt 6.9.2 for Windows/Desktop
# - MSVC 2022 64-bit compiler version
# - Includes Serial Port module (CRITICAL!)
# - Saves to: D:\DownloadedSoftware\Qt_6.9.2\
#
# Takes: 30-60 minutes (depends on internet speed)
# Size: ~3 GB
```

**Explanation of command:**
```
aqt install-qt
  - Use aqt tool
  
windows desktop 6.9.2
  - Windows platform, desktop type, version 6.9.2
  
win64_msvc2022_64
  - Windows 64-bit, MSVC 2022 compiler, 64-bit
  
-m serial
  - Add module: Qt Serial Port (MUST HAVE for RS-422)
```

**Wait for command to finish!**

When done, verify:
```powershell
# Should exist:
dir D:\DownloadedSoftware\Qt_6.9.2\6.9.2\bin\qmake.exe
dir D:\DownloadedSoftware\Qt_6.9.2\6.9.2\lib\cmake\Qt6SerialPort

# Both should be present
```

---

## DOWNLOAD 3: CMake (100 MB)

### Using Browser

```
1. Open: https://cmake.org/download/
2. Find: "Windows x64 Installer" 
3. Download: cmake-3.xx.x-windows-x86_64.msi
4. Save to: D:\DownloadedSoftware\CMake\
```

### Using Command Line (PowerShell)

```powershell
cd D:\DownloadedSoftware\CMake\

# Download latest CMake
$url = "https://github.com/Kitware/CMake/releases/download/v3.28.0/cmake-3.28.0-windows-x86_64.msi"
Invoke-WebRequest -Uri $url -OutFile "cmake-3.28.0-windows-x86_64.msi"

# Verify download
dir cmake-3.28.0-windows-x86_64.msi
```

---

## DOWNLOAD 4: Ninja (500 KB) - OPTIONAL

### Using Browser

```
1. Open: https://github.com/ninja-build/ninja/releases
2. Find latest version
3. Download: ninja-win.zip
4. Save to: D:\DownloadedSoftware\Ninja\
```

### Using Command Line (PowerShell)

```powershell
cd D:\DownloadedSoftware\Ninja\

# Download latest Ninja
$url = "https://github.com/ninja-build/ninja/releases/download/v1.11.1/ninja-win.zip"
Invoke-WebRequest -Uri $url -OutFile "ninja-win.zip"

# Verify download
dir ninja-win.zip
```

---

## COPY PROJECT (21 KB)

```powershell
# Copy velocity_radar.zip to USB
copy velocity_radar.zip D:\DownloadedSoftware\Project\

# Or if you already downloaded it to another location
copy "C:\path\to\velocity_radar.zip" D:\DownloadedSoftware\Project\
```

---

## FINAL VERIFICATION (Connected PC)

After all downloads complete, verify folder structure:

```powershell
# Check all folders have files
dir D:\DownloadedSoftware\

# Should show:
# VS2022_Installer/       (5-6 GB) - many files
# Qt_6.9.2/              (2-3 GB) - many files
# CMake/                 (100 MB) - cmake-3.xx.x-windows-x86_64.msi
# Ninja/                 (500 KB) - ninja-win.zip
# Project/               (21 KB)  - velocity_radar.zip

# Verify each:
dir D:\DownloadedSoftware\VS2022_Installer\
dir D:\DownloadedSoftware\Qt_6.9.2\6.9.2\
dir D:\DownloadedSoftware\CMake\
dir D:\DownloadedSoftware\Ninja\
dir D:\DownloadedSoftware\Project\
```

**All folders should have content!**

---

## TRANSFER TO OFFLINE PC

```powershell
# When all downloads complete:

# Copy entire folder to USB (if not already there)
# OR just safely eject USB if already saved there

# On offline PC:
# 1. Plug USB into offline PC
# 2. Copy D:\DownloadedSoftware to C:\OfflineSetup\
# 3. Eject USB

# Offline PC folder structure should now be:
# C:\OfflineSetup\
#   ├── VS2022_Installer\
#   ├── Qt_6.9.2\
#   ├── CMake\
#   ├── Ninja\
#   └── Project\
```

---

## AUTOMATED DOWNLOAD SCRIPT (PowerShell)

If you prefer a script that downloads everything at once:

**File: D:\download_all.ps1**

```powershell
# Auto-download everything for air-gapped setup
# Usage: cd D:\DownloadedSoftware\ && powershell -ExecutionPolicy Bypass -File ..\download_all.ps1

Write-Host "Downloading all dependencies for offline PC..."

# Create folders
mkdir -Force D:\DownloadedSoftware\VS2022_Installer | Out-Null
mkdir -Force D:\DownloadedSoftware\Qt_6.9.2 | Out-Null
mkdir -Force D:\DownloadedSoftware\CMake | Out-Null
mkdir -Force D:\DownloadedSoftware\Ninja | Out-Null

# Qt 6.9.2 using aqtinstall
Write-Host "Downloading Qt 6.9.2 (largest, ~3 GB)..."
cd D:\DownloadedSoftware\Qt_6.9.2\
aqt install-qt windows desktop 6.9.2 win64_msvc2022_64 -m serial

# CMake
Write-Host "Downloading CMake..."
cd D:\DownloadedSoftware\CMake\
$cmakeUrl = "https://github.com/Kitware/CMake/releases/download/v3.28.0/cmake-3.28.0-windows-x86_64.msi"
Invoke-WebRequest -Uri $cmakeUrl -OutFile "cmake-3.28.0-windows-x86_64.msi"

# Ninja
Write-Host "Downloading Ninja..."
cd D:\DownloadedSoftware\Ninja\
$ninjaUrl = "https://github.com/ninja-build/ninja/releases/download/v1.11.1/ninja-win.zip"
Invoke-WebRequest -Uri $ninjaUrl -OutFile "ninja-win.zip"

Write-Host "Downloads complete!"
Write-Host "VS2022 installer: Download manually from https://visualstudio.microsoft.com/vs/community/"
Write-Host "And save to: D:\DownloadedSoftware\VS2022_Installer\"
```

---

## DOWNLOAD SIZE ESTIMATES

| Software | Size | Time (10 Mbps) | Time (50 Mbps) |
|----------|------|----------------|----------------|
| Visual Studio 2022 | 5-6 GB | 1-2 hours | 15-25 min |
| Qt 6.9.2 | 2-3 GB | 30-60 min | 5-10 min |
| CMake | 100 MB | 2 min | 20 sec |
| Ninja | 500 KB | 5 sec | 1 sec |
| **TOTAL** | **~8-9 GB** | **1.5-2.5 hours** | **20-40 min** |

---

## TROUBLESHOOTING DOWNLOADS

### Issue: aqt command not found

**Fix:**
```powershell
pip install aqtinstall

# Or upgrade if old version:
pip install --upgrade aqtinstall

# Verify:
aqt --version
```

### Issue: Download interrupted

**Fix:**
```powershell
# Just run the command again, aqt can resume
cd D:\DownloadedSoftware\Qt_6.9.2\
aqt install-qt windows desktop 6.9.2 win64_msvc2022_64 -m serial
# It will resume where it left off
```

### Issue: VS2022 installer says "requires internet"

**Fix:**
- This is expected for VS2022
- Choose "Download all, then install later" option
- It will download complete offline package
- Takes 1-2 hours but worth it

### Issue: Not enough disk space on USB

**Fix:**
- Use larger USB drive (64 GB)
- Or download to PC then copy to USB
- Delete unnecessary files on USB
- Qt (3 GB) + VS2022 (5 GB) = minimum 8 GB

---

## VERIFICATION CHECKLIST (Connected PC After Downloads)

```
☐ VS2022_Installer/ folder exists (5-6 GB)
☐ Qt_6.9.2/6.9.2/bin/qmake.exe exists (2-3 GB)
☐ Qt_6.9.2/6.9.2/lib/cmake/Qt6SerialPort/ exists
☐ CMake/cmake-3.xx.x-windows-x86_64.msi exists (100 MB)
☐ Ninja/ninja-win.zip exists (500 KB)
☐ Project/velocity_radar.zip exists (21 KB)
☐ Total USB size used: ~8-9 GB
☐ Ready to transfer to offline PC
```

---

## NEXT STEPS

1. ✅ Download everything using above commands
2. ✅ Verify all files exist
3. ✅ Plug USB into offline PC
4. ✅ Follow **AIR-GAPPED_QUICK_CHECKLIST.md** on offline PC
5. ✅ Install everything in correct order
6. ✅ Build and run project!

---

**Good luck with your downloads!** 🚀

**Estimated total time: 1-2.5 hours (depending on internet speed)**

Once downloaded and transferred, **no internet needed on offline PC!** 🔌
