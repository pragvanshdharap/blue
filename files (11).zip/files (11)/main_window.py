"""
VELOCITY RADAR — Main Window (Layer 5)

Top-level GUI controller:
  • Loads mainwindow.ui from PySide6 Qt Designer
  • Wires all buttons to protocol command handlers
  • Manages GUI state machine: IDLE / MEASURING / SYSTEM_TEST
  • Handles all incoming responses (ACK, NACK, LAST_V, PARAMS, TEST_RESULTS)
  • Color-coded log panel
  • Connection status indicator
  • Auto-refresh COM port list
"""

import os
from datetime import datetime

from PySide6.QtWidgets import QDialog, QLabel, QPlainTextEdit, QPushButton, QComboBox, QTextBrowser
from PySide6.QtCore import QFile
from PySide6.QtGui import QTextCharFormat, QColor, QFont, QTextCursor
from PySide6.QtUiTools import QUiLoader

from protocol import *
from serial_comm import SerialComm
from message_builder import *
from message_parser import MessageParser, ParsedMessage
from expected_v_dialog import ExpectedVDialog


# =========================================================================
#  Log Color Constants
# =========================================================================
COLOR_SEND  = QColor("#2E86C1")   # Blue — outgoing commands
COLOR_RECV  = QColor("#27AE60")   # Green — incoming data
COLOR_ACK   = QColor("#1E8449")   # Dark green — acknowledgment
COLOR_NACK  = QColor("#C0392B")   # Dark red — rejection
COLOR_ERROR = QColor("#E74C3C")   # Red — timeouts, errors
COLOR_RAW   = QColor("#7F8C8D")   # Gray — raw hex bytes
COLOR_INFO  = QColor("#2C3E50")   # Dark gray — status info

LOG_COLORS = {
    "SEND":  COLOR_SEND,
    "RECV":  COLOR_RECV,
    "ACK":   COLOR_ACK,
    "NACK":  COLOR_NACK,
    "ERROR": COLOR_ERROR,
    "RAW":   COLOR_RAW,
    "INFO":  COLOR_INFO,
}


class MainWindow(QDialog):
    """Main application window for Velocity Radar."""

    def __init__(self, parent=None):
        super().__init__(parent)

        self._serial = SerialComm(self)
        self._system_state = SystemState.IDLE

        # Load UI
        self._load_ui()

        # Get widget references from loaded .ui
        self._find_widgets()

        # Setup programmatic additions
        self._setup_programmatic_widgets()

        # Wire signals
        self._setup_connections()

        # Initialize
        self._refresh_ports()
        self._update_button_states()
        self._update_connection_status(False)

        self._log("Application started", "INFO")
        self._log(f"Serial backend: {self._serial.backend_name}", "INFO")
        self._log(f"System state: {self._system_state.value}", "INFO")

    # =====================================================================
    #  UI Loading
    # =====================================================================

    def _load_ui(self):
        ui_path = os.path.join(os.path.dirname(__file__), "ui", "mainwindow.ui")

        if not os.path.exists(ui_path):
            raise FileNotFoundError(f"mainwindow.ui not found at {ui_path}")

        loader = QUiLoader()
        ui_file = QFile(ui_path)
        ui_file.open(QFile.ReadOnly)
        self._ui = loader.load(ui_file, self)
        ui_file.close()

        self.setWindowTitle("Velocity Radar")
        self.setFixedSize(self._ui.size())

        from PySide6.QtWidgets import QVBoxLayout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.addWidget(self._ui)

    def _find_widgets(self):
        """Find all widgets by their object names from the .ui file."""
        find = self._ui.findChild

        # Command buttons (exact names from your mainwindow.ui)
        self.btn_expected_value    = find(QPushButton, "pushButton")
        self.btn_enter_measure     = find(QPushButton, "enterMeasureMode")
        self.btn_stop_measure      = find(QPushButton, "stopMeasure")
        self.btn_transmit_last_v   = find(QPushButton, "transmitLastMode")
        self.btn_parallax          = find(QPushButton, "parallax")
        self.btn_transmit_params   = find(QPushButton, "transmitParameters")
        self.btn_enter_sys_test    = find(QPushButton, "enterSystemTestMode")
        self.btn_perform_sys_test  = find(QPushButton, "performSystemTest")
        self.btn_exit_sys_test     = find(QPushButton, "exitSystemTestMode")
        self.btn_perform_mvp       = find(QPushButton, "performMVPTest")
        self.btn_transmit_mvp_res  = find(QPushButton, "transmitTestResults")

        # Connection controls
        self.btn_connect    = find(QPushButton, "pushButton_2")
        self.btn_disconnect = find(QPushButton, "pushButton_3")
        self.combo_port     = find(QComboBox, "comboBox")
        self.combo_baud     = find(QComboBox, "comboBox_2")

        # Log display
        self.log_widget = find(QPlainTextEdit, "plainTextEdit")

        # Title and labels
        self.title_browser = find(QTextBrowser, "title")
        self.logs_label    = find(QTextBrowser, "textBrowser_3")

    def _setup_programmatic_widgets(self):
        """Add widgets not in the .ui file."""

        # Connection status indicator
        self._connection_label = QLabel(self._ui)
        self._connection_label.setGeometry(460, 75, 240, 20)
        self._connection_label.setText("⚫ Disconnected")
        self._connection_label.setStyleSheet("font-size: 10pt;")
        self._connection_label.show()

        # System state label
        self._state_label = QLabel(self._ui)
        self._state_label.setGeometry(40, 120, 350, 20)
        self._state_label.setText("State: IDLE")
        self._state_label.setStyleSheet(
            "font-weight: bold; font-size: 10pt; color: #2C3E50;")
        self._state_label.show()

        # Configure log widget
        if self.log_widget:
            self.log_widget.setReadOnly(True)
            self.log_widget.setMaximumBlockCount(2000)
            self.log_widget.setFont(QFont("Courier New", 9))

        # Hide old "logs" label
        if self.logs_label:
            self.logs_label.hide()

    # =====================================================================
    #  Signal/Slot Connections
    # =====================================================================

    def _setup_connections(self):
        # Command buttons
        self.btn_expected_value.clicked.connect(self._on_expected_value)
        self.btn_enter_measure.clicked.connect(self._on_enter_measure)
        self.btn_stop_measure.clicked.connect(self._on_stop_measure)
        self.btn_transmit_last_v.clicked.connect(self._on_transmit_last_v)
        self.btn_parallax.clicked.connect(self._on_parallax)
        self.btn_transmit_params.clicked.connect(self._on_transmit_params)
        self.btn_enter_sys_test.clicked.connect(self._on_enter_sys_test)
        self.btn_perform_sys_test.clicked.connect(self._on_perform_sys_test)
        self.btn_exit_sys_test.clicked.connect(self._on_exit_sys_test)
        self.btn_perform_mvp.clicked.connect(self._on_perform_mvp)
        self.btn_transmit_mvp_res.clicked.connect(self._on_transmit_mvp_results)

        # Connection controls
        self.btn_connect.clicked.connect(self._on_connect)
        self.btn_disconnect.clicked.connect(self._on_disconnect)

        # SerialComm signals
        self._serial.message_received.connect(self._on_message_received)
        self._serial.response_timeout.connect(self._on_response_timeout)
        self._serial.port_opened.connect(self._on_port_opened)
        self._serial.port_closed.connect(self._on_port_closed)
        self._serial.port_error.connect(self._on_port_error)
        self._serial.raw_data_sent.connect(self._on_raw_data_sent)
        self._serial.raw_data_received.connect(self._on_raw_data_received)
        self._serial.parse_error_sig.connect(self._on_parse_error)

    # =====================================================================
    #  Button Handlers
    # =====================================================================

    def _on_expected_value(self):
        dlg = ExpectedVDialog(self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            v = dlg.velocity()
            msg = build_expected_v(v)
            self._send_command(msg, CMD_EXPECTED_V, f"EXPECTED_V = {v}")

    def _on_enter_measure(self):
        msg = build_measure()
        self._send_command(msg, CMD_MEASURE, "MEASURE (enter measure mode)")

    def _on_stop_measure(self):
        msg = build_stop_measure()
        self._send_command(msg, CMD_STOP_MEASURE, "STOP_MEASURE (exit measure mode)")

    def _on_transmit_last_v(self):
        msg = build_txmt_last_v()
        self._send_command(msg, CMD_TXMT_LAST_V, "TXMT_LAST_V (request last velocity)")

    def _on_parallax(self):
        self._log("PARALLAX: Not yet implemented (hardware not ready)", "INFO")

    def _on_transmit_params(self):
        msg = build_txmt_params()
        self._send_command(msg, CMD_TXMT_PARAMS, "TXMT_PARAMS (request parameters)")

    def _on_enter_sys_test(self):
        msg = build_enter_system_test()
        self._send_command(msg, CMD_ENTER_SYSTEM_TEST, "ENTER_SYSTEM_TEST")

    def _on_perform_sys_test(self):
        msg = build_perform_system_test()
        self._send_command(msg, CMD_PERFORM_SYSTEM_TEST,
                           "PERFORM_SYSTEM_TEST (awaiting ~5s)")

    def _on_exit_sys_test(self):
        msg = build_exit_system_test()
        self._send_command(msg, CMD_EXIT_SYSTEM_TEST, "EXIT_SYSTEM_TEST")

    def _on_perform_mvp(self):
        msg = build_perform_mvp_test()
        self._send_command(msg, CMD_PERFORM_MVP_TEST, "PERFORM_MVP_TEST")

    def _on_transmit_mvp_results(self):
        msg = build_txmt_mvp_test_results()
        self._send_command(msg, CMD_TXMT_MVP_TEST_RESULTS, "TXMT_MVP_TEST_RESULTS")

    # =====================================================================
    #  Connection Control
    # =====================================================================

    def _on_connect(self):
        if self._serial.is_open():
            self._log("Already connected", "INFO")
            return

        port_name = self.combo_port.currentText()
        baud_text = self.combo_baud.currentText()

        if not port_name or port_name == "No ports found":
            self._log("No COM port selected", "ERROR")
            return

        try:
            baud_rate = int(baud_text)
        except ValueError:
            baud_rate = DEFAULT_BAUD_RATE

        self._log(f"Connecting to {port_name} @ {baud_rate}...", "INFO")
        self._serial.open_port(port_name, baud_rate)

    def _on_disconnect(self):
        if not self._serial.is_open():
            self._log("Not connected", "INFO")
            return
        self._serial.close_port()

    def _refresh_ports(self):
        current = self.combo_port.currentText()
        self.combo_port.clear()

        ports = SerialComm.available_ports()
        if not ports:
            self.combo_port.addItem("No ports found")
        else:
            self.combo_port.addItems(ports)
            idx = self.combo_port.findText(current)
            if idx >= 0:
                self.combo_port.setCurrentIndex(idx)

    # =====================================================================
    #  SerialComm Signal Handlers
    # =====================================================================

    def _on_message_received(self, msg):
        if msg.code == RSP_ACK:
            self._handle_ack(msg)
        elif msg.code == RSP_NACK:
            self._handle_nack(msg)
        elif msg.code == RSP_LAST_V:
            self._handle_last_v(msg)
        elif msg.code == RSP_PARAMS:
            self._handle_params(msg)
        elif msg.code == RSP_SYSTEM_TEST_RESULTS:
            self._handle_system_test_results(msg)
        else:
            self._log(f"Unknown response code: {msg.code}", "ERROR")

    def _on_response_timeout(self, command_code):
        timeout_s = response_timeout(command_code) / 1000.0
        self._log(
            f"TIMEOUT: No response to {command_name(command_code)} "
            f"(code {command_code}) after {timeout_s:.1f}s", "ERROR")

    def _on_port_opened(self, port_name, baud_rate):
        self._log(f"Connected to {port_name} @ {baud_rate} baud", "INFO")
        self._update_connection_status(True, f"{port_name} @ {baud_rate}")
        self._set_system_state(SystemState.IDLE)
        self._update_button_states()

    def _on_port_closed(self):
        self._log("Disconnected", "INFO")
        self._update_connection_status(False)
        self._update_button_states()

    def _on_port_error(self, error):
        self._log(f"PORT ERROR: {error}", "ERROR")

    def _on_raw_data_sent(self, data):
        self._log(f"TX: {self._bytes_to_hex(data)}", "RAW")

    def _on_raw_data_received(self, data):
        self._log(f"RX: {self._bytes_to_hex(data)}", "RAW")

    def _on_parse_error(self, error):
        self._log(f"PARSE ERROR: {error}", "ERROR")

    # =====================================================================
    #  Response Handlers
    # =====================================================================

    def _handle_ack(self, msg):
        ack = MessageParser.decode_ack(msg)
        if not ack.valid:
            self._log("Received ACK but failed to decode", "ERROR")
            return

        self._log(
            f"ACK for {command_name(ack.acknowledged_code)} "
            f"(code {ack.acknowledged_code})", "ACK")

        # Update state based on acknowledged command
        state_map = {
            CMD_MEASURE:           SystemState.MEASURING,
            CMD_STOP_MEASURE:      SystemState.IDLE,
            CMD_ENTER_SYSTEM_TEST: SystemState.SYSTEM_TEST,
            CMD_EXIT_SYSTEM_TEST:  SystemState.IDLE,
        }
        new_state = state_map.get(ack.acknowledged_code)
        if new_state:
            self._set_system_state(new_state)

    def _handle_nack(self, msg):
        nack = MessageParser.decode_nack(msg)
        if not nack.valid:
            self._log("Received NACK but failed to decode", "ERROR")
            return
        self._log(
            f"NACK: {command_name(nack.rejected_code)} "
            f"(code {nack.rejected_code}) was REJECTED", "NACK")

    def _handle_last_v(self, msg):
        last_v = MessageParser.decode_last_v(msg)
        if not last_v.valid:
            self._log("Received LAST_V but failed to decode", "ERROR")
            return
        if last_v.result == LAST_V_RESULT_OK:
            self._log(
                f"LAST_V: {last_v.real_velocity:.1f} m/s "
                f"(raw={last_v.raw_velocity})", "RECV")
        else:
            self._log("LAST_V: Measurement error (no valid velocity)", "ERROR")

    def _handle_params(self, msg):
        params = MessageParser.decode_params(msg)
        if not params.valid:
            self._log("Received PARAMS but failed to decode", "ERROR")
            return
        tripod_str = "Tripod" if params.tripod == TRIPOD_TRIPOD else "Bracket"
        self._log(
            f"PARAMS: Expected V={params.expected_v}, Mount={tripod_str}, "
            f"X={params.x/16.0:.2f}m, Y={params.y/16.0:.2f}m, "
            f"Z={params.z/16.0:.2f}m", "RECV")

    def _handle_system_test_results(self, msg):
        test = MessageParser.decode_system_test_results(msg)
        if not test.valid:
            self._log("Received SYSTEM_TEST_RESULTS but failed to decode", "ERROR")
            return

        flags_desc = decode_test_flags(test.flags)
        if test.flags == 0x0000:
            self._log(
                f"SYSTEM TEST: ALL PASSED (flags=0x{test.flags:04X})", "RECV")
        else:
            self._log(
                f"SYSTEM TEST: FAILURES DETECTED (flags=0x{test.flags:04X})",
                "ERROR")
            for flag in flags_desc:
                self._log(f"  - {flag}", "ERROR")

    # =====================================================================
    #  State Machine
    # =====================================================================

    def _set_system_state(self, new_state):
        self._system_state = new_state
        self._state_label.setText(f"State: {new_state.value}")
        self._log(f"State changed to {new_state.value}", "INFO")
        self._update_button_states()

    def _update_button_states(self):
        connected = self._serial.is_open()

        # Connection controls
        self.btn_connect.setEnabled(not connected)
        self.btn_disconnect.setEnabled(connected)
        self.combo_port.setEnabled(not connected)
        self.combo_baud.setEnabled(not connected)

        if not connected:
            # All command buttons disabled
            for btn in (self.btn_expected_value, self.btn_enter_measure,
                        self.btn_stop_measure, self.btn_transmit_last_v,
                        self.btn_parallax, self.btn_transmit_params,
                        self.btn_enter_sys_test, self.btn_perform_sys_test,
                        self.btn_exit_sys_test, self.btn_perform_mvp,
                        self.btn_transmit_mvp_res):
                btn.setEnabled(False)
            return

        state = self._system_state

        if state == SystemState.IDLE:
            self.btn_expected_value.setEnabled(True)
            self.btn_enter_measure.setEnabled(True)
            self.btn_stop_measure.setEnabled(False)
            self.btn_transmit_last_v.setEnabled(True)
            self.btn_parallax.setEnabled(True)
            self.btn_transmit_params.setEnabled(True)
            self.btn_enter_sys_test.setEnabled(True)
            self.btn_perform_sys_test.setEnabled(False)
            self.btn_exit_sys_test.setEnabled(False)
            self.btn_perform_mvp.setEnabled(True)
            self.btn_transmit_mvp_res.setEnabled(True)

        elif state == SystemState.MEASURING:
            # Only STOP_MEASURE allowed
            for btn in (self.btn_expected_value, self.btn_enter_measure,
                        self.btn_transmit_last_v, self.btn_parallax,
                        self.btn_transmit_params, self.btn_enter_sys_test,
                        self.btn_perform_sys_test, self.btn_exit_sys_test,
                        self.btn_perform_mvp, self.btn_transmit_mvp_res):
                btn.setEnabled(False)
            self.btn_stop_measure.setEnabled(True)

        elif state == SystemState.SYSTEM_TEST:
            # Only PERFORM_SYSTEM_TEST and EXIT_SYSTEM_TEST
            for btn in (self.btn_expected_value, self.btn_enter_measure,
                        self.btn_stop_measure, self.btn_transmit_last_v,
                        self.btn_parallax, self.btn_transmit_params,
                        self.btn_enter_sys_test, self.btn_perform_mvp,
                        self.btn_transmit_mvp_res):
                btn.setEnabled(False)
            self.btn_perform_sys_test.setEnabled(True)
            self.btn_exit_sys_test.setEnabled(True)

    # =====================================================================
    #  Logging
    # =====================================================================

    def _log(self, message: str, log_type: str):
        if not self.log_widget:
            return

        color = LOG_COLORS.get(log_type, COLOR_INFO)
        timestamp = datetime.now().strftime("%H:%M:%S")
        full_msg = f"{timestamp} [{log_type}] {message}"

        cursor = self.log_widget.textCursor()
        cursor.movePosition(QTextCursor.MoveOperation.End)

        fmt = QTextCharFormat()
        fmt.setForeground(color)
        cursor.insertText(full_msg + "\n", fmt)

        self.log_widget.setTextCursor(cursor)
        self.log_widget.ensureCursorVisible()

    # =====================================================================
    #  Helpers
    # =====================================================================

    def _send_command(self, message: bytes, command_code: int, description: str):
        if not self._serial.is_open():
            self._log("Cannot send: not connected", "ERROR")
            return
        self._log(f"Sending {description} (code {command_code})", "SEND")
        self._serial.send_message(message, command_code)

    def _update_connection_status(self, connected: bool, detail: str = ""):
        if connected:
            self._connection_label.setText(f"🟢 Connected ({detail})")
            self._connection_label.setStyleSheet(
                "font-size: 10pt; color: #27AE60;")
        else:
            self._connection_label.setText("⚫ Disconnected")
            self._connection_label.setStyleSheet(
                "font-size: 10pt; color: #E74C3C;")

    @staticmethod
    def _bytes_to_hex(data: bytes) -> str:
        return " ".join(f"{b:02X}" for b in data)
