#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QDialog>
#include <QPlainTextEdit>
#include <QLabel>
#include <QPushButton>
#include <QComboBox>
#include <QDateTime>

#include "serialcomm.h"
#include "messagebuilder.h"
#include "messageparser.h"

// Forward-declare the auto-generated UI class
namespace Ui {
class Dialog;
}

/*
 * MainWindow
 *
 * Main application window (QDialog-based, matching your .ui).
 * Responsibilities:
 *   - Wire all button clicks to MessageBuilder → SerialComm
 *   - Handle incoming parsed messages and update UI
 *   - Track system state (IDLE / MEASURING / SYSTEM_TEST)
 *   - Enable/disable buttons per state
 *   - Color-coded log panel
 *   - Connection management (COM port selection, connect/disconnect)
 */
class MainWindow : public QDialog
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    // ─── Button Slots ────────────────────────────────────────────
    void onExpectedValueClicked();
    void onEnterMeasureModeClicked();
    void onStopMeasureClicked();
    void onTransmitLastVClicked();
    void onParallaxClicked();
    void onTransmitParametersClicked();
    void onEnterSystemTestModeClicked();
    void onPerformSystemTestClicked();
    void onExitSystemTestModeClicked();
    void onPerformMVPTestClicked();
    void onTransmitMVPTestResultsClicked();

    // ─── Connection Slots ────────────────────────────────────────
    void onConnectClicked();
    void onRefreshPortsClicked();

    // ─── Serial Event Handlers ───────────────────────────────────
    void onMessageReceived(const ParsedMessage &msg);
    void onPortOpened(const QString &portName);
    void onPortClosed();
    void onPortError(const QString &error);
    void onParseError(const QString &error);
    void onResponseTimeout(uint8_t cmdCode);
    void onRawDataSent(const QByteArray &data);
    void onRawDataReceived(const QByteArray &data);

private:
    // ─── System State ────────────────────────────────────────────
    enum class SystemState {
        IDLE,
        MEASURING,
        SYSTEM_TEST
    };

    void setSystemState(SystemState state);
    void updateButtonStates();

    // ─── Logging ─────────────────────────────────────────────────
    void addLog(const QString &message, const QString &type = "INFO");

    // ─── Helpers ─────────────────────────────────────────────────
    void sendCommand(const QByteArray &msg, uint8_t cmdCode);
    void setupConnections();
    void setupUiExtras();  // Adds widgets not in .ui (connect btn, status, etc.)
    void refreshComPorts();

    // ─── Members ─────────────────────────────────────────────────
    Ui::Dialog  *ui;
    SerialComm  *m_serial;
    SystemState  m_state;

    // Extra widgets (created programmatically, not in .ui)
    QPushButton    *m_connectBtn;
    QPushButton    *m_refreshBtn;
    QLabel         *m_connectionStatus;
    QLabel         *m_systemStateLabel;
    QPlainTextEdit *m_logWidget;
};

#endif // MAINWINDOW_H
