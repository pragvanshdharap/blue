#ifndef MESSAGEPARSER_H
#define MESSAGEPARSER_H

#include <QByteArray>
#include <QObject>
#include <QString>
#include <QStringList>
#include <cstdint>

// ─── Decoded Response Structures ────────────────────────────────────

struct AckResponse {
    uint8_t ackedCode;    // The command code being acknowledged
};

struct NackResponse {
    uint8_t nackedCode;   // The command code being NACKed
};

struct LastVResponse {
    int8_t   result;      // 0 = OK, -1 (0xFF) = error
    uint16_t velocity;    // Scaled by 16. Real velocity = velocity / 16.0
    bool isValid() const { return result == 0; }
    double realVelocity() const { return velocity / 16.0; }
};

struct ParamsResponse {
    uint16_t expectedV;   // 150–1500
    uint8_t  tripod;      // 0=bracket, 1=tripod
    uint8_t  x;           // meters * 16
    uint8_t  y;
    uint8_t  z;
    double realX() const { return x / 16.0; }
    double realY() const { return y / 16.0; }
    double realZ() const { return z / 16.0; }
};

struct SystemTestResultsResponse {
    uint16_t failureFlags;

    bool ramFailure()          const { return failureFlags & (1 << 0); }
    bool portsFailure()        const { return failureFlags & (1 << 1); }
    bool syntDoppFailure()     const { return failureFlags & (1 << 2); }
    bool rfTestFailure()       const { return failureFlags & (1 << 3); }
    bool accelerometerFailure()const { return failureFlags & (1 << 4); }
    bool rfNoiseFailure()      const { return failureFlags & (1 << 5); }
    bool allPassed()           const { return failureFlags == 0; }

    QStringList failureList() const {
        QStringList list;
        if (ramFailure())           list << "RAM";
        if (portsFailure())         list << "PORTS";
        if (syntDoppFailure())      list << "Synt Dopp";
        if (rfTestFailure())        list << "RF Test";
        if (accelerometerFailure()) list << "Accelerometer";
        if (rfNoiseFailure())       list << "RF Noise";
        return list;
    }
};

// ─── Parsed Message Envelope ────────────────────────────────────────

struct ParsedMessage {
    uint8_t    code;
    QByteArray data;    // Raw data bytes (excludes SIZE, CODE, CHECKSUM)
    bool       valid;   // Checksum passed and format correct

    ParsedMessage() : code(0), valid(false) {}
};

// ─── MessageParser ──────────────────────────────────────────────────
//
// Accumulates incoming bytes from serial port.
// Searches for 'A','B' header, reads SIZE, collects remaining bytes,
// validates checksum, and emits parsed messages.
//
class MessageParser : public QObject
{
    Q_OBJECT

public:
    explicit MessageParser(QObject *parent = nullptr);

    // Feed raw bytes from serial port. May emit messageReceived()
    // zero or more times per call.
    void processBytes(const QByteArray &bytes);

    // Reset parser state (e.g., after port reconnect)
    void reset();

    // ─── Decode helpers (call after receiving ParsedMessage) ────
    static AckResponse                 decodeAck(const ParsedMessage &msg);
    static NackResponse                decodeNack(const ParsedMessage &msg);
    static LastVResponse               decodeLastV(const ParsedMessage &msg);
    static ParamsResponse              decodeParams(const ParsedMessage &msg);
    static SystemTestResultsResponse   decodeSystemTestResults(const ParsedMessage &msg);

signals:
    void messageReceived(const ParsedMessage &msg);
    void parseError(const QString &errorDescription);

private:
    enum class State {
        WAIT_HEADER_1,   // Looking for 'A'
        WAIT_HEADER_2,   // Looking for 'B'
        WAIT_SIZE,       // Next byte is SIZE
        COLLECTING       // Collecting SIZE-1 remaining bytes (CODE + DATA + CHECKSUM)
    };

    State      m_state;
    uint8_t    m_expectedSize;    // SIZE field value
    QByteArray m_buffer;          // Collects bytes after SIZE

    bool validateChecksum(uint8_t size, const QByteArray &body) const;
    void processByte(uint8_t byte);
};

#endif // MESSAGEPARSER_H
