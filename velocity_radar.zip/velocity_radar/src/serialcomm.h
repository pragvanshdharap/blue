#ifndef SERIALCOMM_H
#define SERIALCOMM_H

#include <QObject>
#include <QSerialPort>
#include <QSerialPortInfo>
#include <QTimer>
#include <QString>
#include <QByteArray>

#include "messageparser.h"

/*
 * SerialComm
 *
 * Manages the RS-422 serial port connection.
 * - Opens/closes port with specified settings (9600, 8N1 default)
 * - Sends raw byte arrays (built by MessageBuilder)
 * - Reads incoming bytes asynchronously via QSerialPort::readyRead
 * - Feeds bytes into MessageParser for protocol decoding
 * - Emits signals for parsed messages, errors, and connection state
 * - Handles response timeout (2s normal, 5s for system test)
 */
class SerialComm : public QObject
{
    Q_OBJECT

public:
    explicit SerialComm(QObject *parent = nullptr);
    ~SerialComm();

    // ─── Port Management ─────────────────────────────────────────
    bool openPort(const QString &portName, int baudRate = 9600);
    void closePort();
    bool isOpen() const;
    QString currentPortName() const;

    // ─── Static: Enumerate available COM ports ───────────────────
    static QStringList availablePorts();

    // ─── Send ────────────────────────────────────────────────────
    // Send a pre-built message (from MessageBuilder).
    // cmdCode is used for timeout tracking and logging.
    bool sendMessage(const QByteArray &message, uint8_t cmdCode);

    // ─── Parser Access ───────────────────────────────────────────
    MessageParser* parser() { return &m_parser; }

signals:
    // ─── Connection Signals ──────────────────────────────────────
    void portOpened(const QString &portName);
    void portClosed();
    void portError(const QString &errorDescription);

    // ─── Protocol Signals (forwarded from parser) ────────────────
    void messageReceived(const ParsedMessage &msg);
    void parseError(const QString &errorDescription);

    // ─── Timeout ─────────────────────────────────────────────────
    void responseTimeout(uint8_t pendingCmdCode);

    // ─── Raw Data (for hex logging) ──────────────────────────────
    void rawDataSent(const QByteArray &data);
    void rawDataReceived(const QByteArray &data);

private slots:
    void onReadyRead();
    void onSerialError(QSerialPort::SerialPortError error);
    void onResponseTimeout();

private:
    QSerialPort  m_serial;
    MessageParser m_parser;
    QTimer       m_responseTimer;
    uint8_t      m_pendingCmdCode;  // Code of the command awaiting response
};

#endif // SERIALCOMM_H
