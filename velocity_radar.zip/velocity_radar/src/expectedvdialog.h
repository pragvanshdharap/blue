#ifndef EXPECTEDVDIALOG_H
#define EXPECTEDVDIALOG_H

#include <QDialog>
#include <cstdint>

namespace Ui {
class ExpectedVDialog;
}

/*
 * ExpectedVDialog
 *
 * Modal dialog for entering the expected velocity value (150–1500).
 * Launched when user clicks "Expected Value" button in main window.
 * Validates input range before accepting.
 */
class ExpectedVDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ExpectedVDialog(QWidget *parent = nullptr);
    ~ExpectedVDialog();

    uint16_t getExpectedValue() const;

private slots:
    void onOkClicked();
    void onCancelClicked();

private:
    uint16_t m_value;

    // We manually create the UI from the .ui widgets rather than
    // using the auto-generated Ui class, since the .ui uses generic
    // "Dialog" class name that conflicts with mainwindow's Ui::Dialog.
    class QLineEdit *m_inputField;
    class QLabel    *m_label;
    class QLabel    *m_rangeLabel;
};

#endif // EXPECTEDVDIALOG_H
