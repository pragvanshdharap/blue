#ifndef MESSAGEBUILDER_H
#define MESSAGEBUILDER_H

#include <QByteArray>
#include <cstdint>

/*
 * MessageBuilder
 *
 * Builds complete byte-level messages per the interface specification.
 * Every build function returns a ready-to-send QByteArray:
 *   [HEADER_1='A'] [HEADER_2='B'] [SIZE] [CODE] [DATA...] [CHECKSUM]
 *
 * CHECKSUM = two's complement of (sum of bytes 3..N) mod 256
 *            i.e. sum of bytes 3..N+1 == 0 mod 256
 */
class MessageBuilder
{
public:
    // ─── Commands to System ──────────────────────────────────────

    // CMD 102: Set expected velocity (150–1500), uint16 LE
    static QByteArray buildExpectedV(uint16_t expectedV);

    // CMD 103: Enter measure mode
    static QByteArray buildMeasure();

    // CMD 104: Stop measure mode
    static QByteArray buildStopMeasure();

    // CMD 105: Request last measured velocity
    static QByteArray buildTxmtLastV();

    // CMD 106: Set parallax parameters
    //   tripod: 0=bracket, 1=tripod
    //   x,y,z: offset in meters*16 (0–160), meaningful only if tripod=1
    static QByteArray buildParallax(uint8_t tripod, uint8_t x, uint8_t y, uint8_t z);

    // CMD 107: Request current parameters
    static QByteArray buildTxmtParams();

    // CMD 108: Enter system test mode
    static QByteArray buildEnterSystemTest();

    // CMD 109: Perform system test
    static QByteArray buildPerformSystemTest();

    // CMD 110: Exit system test mode
    static QByteArray buildExitSystemTest();

    // CMD 111: Perform MVP test
    static QByteArray buildPerformMvpTest();

    // CMD 112: Request MVP test results
    static QByteArray buildTxmtMvpTestResults();

private:
    // Wraps payload (SIZE + CODE + DATA) with headers and checksum
    static QByteArray wrapMessage(const QByteArray &payload);

    // Computes checksum: two's complement of sum mod 256
    static uint8_t computeChecksum(const QByteArray &payload);
};

#endif // MESSAGEBUILDER_H
