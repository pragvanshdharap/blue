#include "messagebuilder.h"
#include "protocol.h"

// ─── Private: Checksum Calculation ──────────────────────────────────
//
// CHECKSUM = two's complement of (sum of bytes 3..N) mod 256
// "bytes 3..N" = the payload (SIZE, CODE, DATA bytes)
// So: sum(payload) + CHECKSUM ≡ 0 (mod 256)
// Therefore: CHECKSUM = (-sum) & 0xFF
//
uint8_t MessageBuilder::computeChecksum(const QByteArray &payload)
{
    uint8_t sum = 0;
    for (int i = 0; i < payload.size(); i++) {
        sum += static_cast<uint8_t>(payload[i]);
    }
    return static_cast<uint8_t>((-sum) & 0xFF);
}

// ─── Private: Wrap with Headers + Checksum ──────────────────────────
//
// Input:  payload = [SIZE] [CODE] [DATA_1 ... DATA_N]
// Output: [0x41] [0x42] [SIZE] [CODE] [DATA...] [CHECKSUM]
//
QByteArray MessageBuilder::wrapMessage(const QByteArray &payload)
{
    QByteArray msg;
    msg.reserve(2 + payload.size() + 1);

    msg.append(Protocol::HEADER_1);       // 'A'
    msg.append(Protocol::HEADER_2);       // 'B'
    msg.append(payload);                  // SIZE + CODE + DATA
    msg.append(computeChecksum(payload)); // CHECKSUM

    return msg;
}

// ─── CMD 102: EXPECTED_V ────────────────────────────────────────────
// [SIZE=5] [CODE=102] [V_LO] [V_HI]
// SIZE includes: SIZE(1) + CODE(1) + DATA(2) + CHECKSUM(1) = 5
QByteArray MessageBuilder::buildExpectedV(uint16_t expectedV)
{
    QByteArray payload;
    payload.append(static_cast<char>(5));                           // SIZE
    payload.append(static_cast<char>(Protocol::CMD_EXPECTED_V));   // CODE
    payload.append(static_cast<char>(expectedV & 0xFF));           // V low byte (LE)
    payload.append(static_cast<char>((expectedV >> 8) & 0xFF));    // V high byte (LE)
    return wrapMessage(payload);
}

// ─── CMD 103: MEASURE ───────────────────────────────────────────────
// [SIZE=3] [CODE=103]
// SIZE includes: SIZE(1) + CODE(1) + CHECKSUM(1) = 3
QByteArray MessageBuilder::buildMeasure()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_MEASURE));
    return wrapMessage(payload);
}

// ─── CMD 104: STOP_MEASURE ──────────────────────────────────────────
QByteArray MessageBuilder::buildStopMeasure()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_STOP_MEASURE));
    return wrapMessage(payload);
}

// ─── CMD 105: TXMT_LAST_V ──────────────────────────────────────────
// [SIZE=2] [CODE=105]   <-- spec says SIZE=2
QByteArray MessageBuilder::buildTxmtLastV()
{
    QByteArray payload;
    payload.append(static_cast<char>(2));
    payload.append(static_cast<char>(Protocol::CMD_TXMT_LAST_V));
    return wrapMessage(payload);
}

// ─── CMD 106: PARALLAX ─────────────────────────────────────────────
// [SIZE=7] [CODE=106] [TRIPOD] [X] [Y] [Z]
// SIZE includes: SIZE(1) + CODE(1) + DATA(4) + CHECKSUM(1) = 7
QByteArray MessageBuilder::buildParallax(uint8_t tripod, uint8_t x, uint8_t y, uint8_t z)
{
    QByteArray payload;
    payload.append(static_cast<char>(7));
    payload.append(static_cast<char>(Protocol::CMD_PARALLAX));
    payload.append(static_cast<char>(tripod));
    payload.append(static_cast<char>(x));
    payload.append(static_cast<char>(y));
    payload.append(static_cast<char>(z));
    return wrapMessage(payload);
}

// ─── CMD 107: TXMT_PARAMS ──────────────────────────────────────────
QByteArray MessageBuilder::buildTxmtParams()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_TXMT_PARAMS));
    return wrapMessage(payload);
}

// ─── CMD 108: ENTER_SYSTEM_TEST ─────────────────────────────────────
QByteArray MessageBuilder::buildEnterSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_ENTER_SYSTEM_TEST));
    return wrapMessage(payload);
}

// ─── CMD 109: PERFORM_SYSTEM_TEST ───────────────────────────────────
QByteArray MessageBuilder::buildPerformSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_PERFORM_SYSTEM_TEST));
    return wrapMessage(payload);
}

// ─── CMD 110: EXIT_SYSTEM_TEST ──────────────────────────────────────
QByteArray MessageBuilder::buildExitSystemTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_EXIT_SYSTEM_TEST));
    return wrapMessage(payload);
}

// ─── CMD 111: PERFORM_MVP_TEST ──────────────────────────────────────
QByteArray MessageBuilder::buildPerformMvpTest()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_PERFORM_MVP_TEST));
    return wrapMessage(payload);
}

// ─── CMD 112: TXMT_MVP_TEST_RESULTS ─────────────────────────────────
QByteArray MessageBuilder::buildTxmtMvpTestResults()
{
    QByteArray payload;
    payload.append(static_cast<char>(3));
    payload.append(static_cast<char>(Protocol::CMD_TXMT_MVP_TEST_RESULTS));
    return wrapMessage(payload);
}
