#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "expectedvdialog.h"
#include "protocol.h"

#include <QMessageBox>
#include <QScrollBar>
#include <QTextCharFormat>
#include <QTextCursor>
#include <QFont>

// ─────────────────────────────────────────────────────────────────────
// Construction
// ─────────────────────────────────────────────────────────────────────

MainWindow::MainWindow(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
    , m_serial(new SerialComm(this))
    , m_state(SystemState::IDLE)
{
    ui->setupUi(this);
    setWindowTitle("Velocity Radar Control");

    setupUiExtras();
    setupConnections();
    refreshComPorts();
    updateButtonStates();

    addLog("Application started. Select a COM port and click Connect.", "INFO");
}

MainWindow::~MainWindow()
{
    delete ui;
}

// ─────────────────────────────────────────────────────────────────────
// Setup: Extra UI widgets (not in .ui file)
// ─────────────────────────────────────────────────────────────────────

void MainWindow::setupUiExtras()
{
    // ─── Replace the QTextBrowser "log" with QPlainTextEdit ──────
    // Hide the original log widget from .ui
    ui->log->hide();
    ui->textBrowser_3->hide(); // "logs" label

    // Create QPlainTextEdit in the same position
    m_logWidget = new QPlainTextEdit(this);
    m_logWidget->setGeometry(ui->log->geometry());
    m_logWidget->setReadOnly(true);
    m_logWidget->setFont(QFont("Consolas", 8));
    m_logWidget->setPlaceholderText("Logs will appear here...");

    // Logs label above the log widget
    auto *logsLabel = new QLabel("Logs", this);
    logsLabel->setGeometry(ui->textBrowser_3->geometry());
    logsLabel->setAlignment(Qt::AlignCenter);
    logsLabel->setStyleSheet("font-weight: bold; font-size: 10pt;");

    // ─── Connect Button (right of baud rate combo) ───────────────
    m_connectBtn = new QPushButton("Connect", this);
    m_connectBtn->setGeometry(275, 118, 80, 28);

    // ─── Refresh Ports Button ────────────────────────────────────
    m_refreshBtn = new QPushButton("↻", this);
    m_refreshBtn->setGeometry(42, 118, 28, 28);
    m_refreshBtn->setToolTip("Refresh COM ports");

    // ─── Connection Status Label (below title) ──────────────────
    m_connectionStatus = new QLabel("⚫ Disconnected", this);
    m_connectionStatus->setGeometry(240, 55, 256, 20);
    m_connectionStatus->setAlignment(Qt::AlignCenter);
    m_connectionStatus->setStyleSheet("color: red; font-size: 9pt;");

    // ─── System State Label (below connection status) ────────────
    m_systemStateLabel = new QLabel("State: IDLE", this);
    m_systemStateLabel->setGeometry(50, 155, 200, 20);
    m_systemStateLabel->setStyleSheet("font-weight: bold; font-size: 9pt; color: #333;");
}

// ─────────────────────────────────────────────────────────────────────
// Setup: Signal/Slot Connections
// ─────────────────────────────────────────────────────────────────────

void MainWindow::setupConnections()
{
    // ─── Button → Slot connections ───────────────────────────────
    connect(ui->pushButton,          &QPushButton::clicked, this, &MainWindow::onExpectedValueClicked);
    connect(ui->enterMeasureMode,    &QPushButton::clicked, this, &MainWindow::onEnterMeasureModeClicked);
    connect(ui->stopMeasure,         &QPushButton::clicked, this, &MainWindow::onStopMeasureClicked);
    connect(ui->transmitLastMode,    &QPushButton::clicked, this, &MainWindow::onTransmitLastVClicked);
    connect(ui->parallax,            &QPushButton::clicked, this, &MainWindow::onParallaxClicked);
    connect(ui->transmitParameters,  &QPushButton::clicked, this, &MainWindow::onTransmitParametersClicked);
    connect(ui->enterSystemTestMode, &QPushButton::clicked, this, &MainWindow::onEnterSystemTestModeClicked);
    connect(ui->performSystemTest,   &QPushButton::clicked, this, &MainWindow::onPerformSystemTestClicked);
    connect(ui->exitSystemTestMode,  &QPushButton::clicked, this, &MainWindow::onExitSystemTestModeClicked);
    connect(ui->performMVPTest,      &QPushButton::clicked, this, &MainWindow::onPerformMVPTestClicked);
    connect(ui->transmitTestResults, &QPushButton::clicked, this, &MainWindow::onTransmitMVPTestResultsClicked);

    // ─── Connect / Refresh buttons ───────────────────────────────
    connect(m_connectBtn, &QPushButton::clicked, this, &MainWindow::onConnectClicked);
    connect(m_refreshBtn, &QPushButton::clicked, this, &MainWindow::onRefreshPortsClicked);

    // ─── Serial signals ──────────────────────────────────────────
    connect(m_serial, &SerialComm::messageReceived,  this, &MainWindow::onMessageReceived);
    connect(m_serial, &SerialComm::portOpened,        this, &MainWindow::onPortOpened);
    connect(m_serial, &SerialComm::portClosed,        this, &MainWindow::onPortClosed);
    connect(m_serial, &SerialComm::portError,         this, &MainWindow::onPortError);
    connect(m_serial, &SerialComm::parseError,        this, &MainWindow::onParseError);
    connect(m_serial, &SerialComm::responseTimeout,   this, &MainWindow::onResponseTimeout);
    connect(m_serial, &SerialComm::rawDataSent,       this, &MainWindow::onRawDataSent);
    connect(m_serial, &SerialComm::rawDataReceived,   this, &MainWindow::onRawDataReceived);
}

// ─────────────────────────────────────────────────────────────────────
// COM Port Management
// ─────────────────────────────────────────────────────────────────────

void MainWindow::refreshComPorts()
{
    ui->comboBox->clear();
    QStringList ports = SerialComm::availablePorts();
    if (ports.isEmpty()) {
        ui->comboBox->addItem("No ports found");
    } else {
        ui->comboBox->addItems(ports);
    }
}

void MainWindow::onRefreshPortsClicked()
{
    refreshComPorts();
    addLog("COM ports refreshed", "INFO");
}

void MainWindow::onConnectClicked()
{
    if (m_serial->isOpen()) {
        m_serial->closePort();
    } else {
        QString portName = ui->comboBox->currentText();
        if (portName.isEmpty() || portName == "No ports found") {
            addLog("No valid COM port selected", "ERROR");
            return;
        }
        int baudRate = ui->comboBox_2->currentText().toInt();
        m_serial->openPort(portName, baudRate);
    }
}

// ─────────────────────────────────────────────────────────────────────
// Serial Event Handlers
// ─────────────────────────────────────────────────────────────────────

void MainWindow::onPortOpened(const QString &portName)
{
    m_connectionStatus->setText(QString("🟢 Connected (%1 @ %2)")
        .arg(portName, ui->comboBox_2->currentText()));
    m_connectionStatus->setStyleSheet("color: green; font-size: 9pt;");
    m_connectBtn->setText("Disconnect");
    addLog(QString("Port %1 opened").arg(portName), "INFO");
    updateButtonStates();
}

void MainWindow::onPortClosed()
{
    m_connectionStatus->setText("⚫ Disconnected");
    m_connectionStatus->setStyleSheet("color: red; font-size: 9pt;");
    m_connectBtn->setText("Connect");
    setSystemState(SystemState::IDLE);
    addLog("Port closed", "INFO");
    updateButtonStates();
}

void MainWindow::onPortError(const QString &error)
{
    addLog(error, "ERROR");
}

void MainWindow::onParseError(const QString &error)
{
    addLog(QString("Parse: %1").arg(error), "ERROR");
}

void MainWindow::onResponseTimeout(uint8_t cmdCode)
{
    addLog(QString("TIMEOUT waiting for response to %1 (code %2)")
           .arg(Protocol::commandName(cmdCode))
           .arg(cmdCode), "ERROR");
}

void MainWindow::onRawDataSent(const QByteArray &data)
{
    addLog(QString("TX [%1 bytes]: %2")
           .arg(data.size())
           .arg(QString(data.toHex(' ').toUpper())), "RAW");
}

void MainWindow::onRawDataReceived(const QByteArray &data)
{
    addLog(QString("RX [%1 bytes]: %2")
           .arg(data.size())
           .arg(QString(data.toHex(' ').toUpper())), "RAW");
}

// ─────────────────────────────────────────────────────────────────────
// Incoming Message Dispatcher
// ─────────────────────────────────────────────────────────────────────

void MainWindow::onMessageReceived(const ParsedMessage &msg)
{
    if (!msg.valid) {
        addLog("Received invalid message (checksum failed)", "ERROR");
        return;
    }

    switch (msg.code) {

    case Protocol::RSP_ACK: {
        AckResponse ack = MessageParser::decodeAck(msg);
        addLog(QString("ACK for %1 (code %2)")
               .arg(Protocol::commandName(ack.ackedCode))
               .arg(ack.ackedCode), "ACK");

        // Update state based on which command was ACKed
        if (ack.ackedCode == Protocol::CMD_MEASURE) {
            setSystemState(SystemState::MEASURING);
        } else if (ack.ackedCode == Protocol::CMD_STOP_MEASURE) {
            setSystemState(SystemState::IDLE);
        } else if (ack.ackedCode == Protocol::CMD_ENTER_SYSTEM_TEST) {
            setSystemState(SystemState::SYSTEM_TEST);
        } else if (ack.ackedCode == Protocol::CMD_EXIT_SYSTEM_TEST) {
            setSystemState(SystemState::IDLE);
        }
        break;
    }

    case Protocol::RSP_NACK: {
        NackResponse nack = MessageParser::decodeNack(msg);
        addLog(QString("NACK for %1 (code %2) — command rejected")
               .arg(Protocol::commandName(nack.nackedCode))
               .arg(nack.nackedCode), "NACK");
        break;
    }

    case Protocol::RSP_LAST_V: {
        LastVResponse v = MessageParser::decodeLastV(msg);
        if (v.isValid()) {
            addLog(QString("LAST_V: %.1f  (raw=%2, scaled/16)")
                   .arg(v.realVelocity())
                   .arg(v.velocity), "RECV");
        } else {
            addLog("LAST_V: MEASUREMENT ERROR (result=-1)", "ERROR");
        }
        break;
    }

    case Protocol::RSP_PARAMS: {
        ParamsResponse p = MessageParser::decodeParams(msg);
        QString tripodStr = (p.tripod == 1) ? "Tripod" : "Bracket";
        addLog(QString("PARAMS: ExpV=%1, Mount=%2, X=%.1f Y=%.1f Z=%.1f")
               .arg(p.expectedV)
               .arg(tripodStr)
               .arg(p.realX())
               .arg(p.realY())
               .arg(p.realZ()), "RECV");
        break;
    }

    case Protocol::RSP_SYSTEM_TEST_RESULTS: {
        SystemTestResultsResponse r = MessageParser::decodeSystemTestResults(msg);
        if (r.allPassed()) {
            addLog("SYSTEM TEST: ALL PASSED (flags=0x0000)", "RECV");
        } else {
            QStringList failures = r.failureList();
            addLog(QString("SYSTEM TEST: FAILURES — %1 (flags=0x%2)")
                   .arg(failures.join(", "))
                   .arg(r.failureFlags, 4, 16, QChar('0')), "ERROR");
        }
        // After test completes, system exits test mode
        setSystemState(SystemState::IDLE);
        break;
    }

    default:
        addLog(QString("Unknown response code: %1").arg(msg.code), "ERROR");
        break;
    }
}

// ─────────────────────────────────────────────────────────────────────
// Button Click Handlers
// ─────────────────────────────────────────────────────────────────────

void MainWindow::sendCommand(const QByteArray &msg, uint8_t cmdCode)
{
    if (!m_serial->isOpen()) {
        addLog("Cannot send: not connected", "ERROR");
        return;
    }
    addLog(QString("Sending %1 (code %2)")
           .arg(Protocol::commandName(cmdCode))
           .arg(cmdCode), "SEND");
    m_serial->sendMessage(msg, cmdCode);
}

void MainWindow::onExpectedValueClicked()
{
    ExpectedVDialog dlg(this);
    if (dlg.exec() == QDialog::Accepted) {
        uint16_t val = dlg.getExpectedValue();
        sendCommand(MessageBuilder::buildExpectedV(val),
                    Protocol::CMD_EXPECTED_V);
    }
}

void MainWindow::onEnterMeasureModeClicked()
{
    sendCommand(MessageBuilder::buildMeasure(),
                Protocol::CMD_MEASURE);
}

void MainWindow::onStopMeasureClicked()
{
    sendCommand(MessageBuilder::buildStopMeasure(),
                Protocol::CMD_STOP_MEASURE);
}

void MainWindow::onTransmitLastVClicked()
{
    sendCommand(MessageBuilder::buildTxmtLastV(),
                Protocol::CMD_TXMT_LAST_V);
}

void MainWindow::onParallaxClicked()
{
    // TODO: Implement parallax dialog later
    addLog("Parallax dialog not yet implemented", "INFO");
}

void MainWindow::onTransmitParametersClicked()
{
    sendCommand(MessageBuilder::buildTxmtParams(),
                Protocol::CMD_TXMT_PARAMS);
}

void MainWindow::onEnterSystemTestModeClicked()
{
    sendCommand(MessageBuilder::buildEnterSystemTest(),
                Protocol::CMD_ENTER_SYSTEM_TEST);
}

void MainWindow::onPerformSystemTestClicked()
{
    sendCommand(MessageBuilder::buildPerformSystemTest(),
                Protocol::CMD_PERFORM_SYSTEM_TEST);
}

void MainWindow::onExitSystemTestModeClicked()
{
    sendCommand(MessageBuilder::buildExitSystemTest(),
                Protocol::CMD_EXIT_SYSTEM_TEST);
}

void MainWindow::onPerformMVPTestClicked()
{
    sendCommand(MessageBuilder::buildPerformMvpTest(),
                Protocol::CMD_PERFORM_MVP_TEST);
}

void MainWindow::onTransmitMVPTestResultsClicked()
{
    sendCommand(MessageBuilder::buildTxmtMvpTestResults(),
                Protocol::CMD_TXMT_MVP_TEST_RESULTS);
}

// ─────────────────────────────────────────────────────────────────────
// System State Machine
// ─────────────────────────────────────────────────────────────────────

void MainWindow::setSystemState(SystemState state)
{
    m_state = state;

    switch (state) {
    case SystemState::IDLE:
        m_systemStateLabel->setText("State: IDLE");
        m_systemStateLabel->setStyleSheet("font-weight: bold; font-size: 9pt; color: #333;");
        break;
    case SystemState::MEASURING:
        m_systemStateLabel->setText("State: MEASURING");
        m_systemStateLabel->setStyleSheet("font-weight: bold; font-size: 9pt; color: #D35400;");
        break;
    case SystemState::SYSTEM_TEST:
        m_systemStateLabel->setText("State: SYSTEM TEST");
        m_systemStateLabel->setStyleSheet("font-weight: bold; font-size: 9pt; color: #2E86C1;");
        break;
    }

    updateButtonStates();
}

void MainWindow::updateButtonStates()
{
    bool connected = m_serial->isOpen();
    bool idle      = (m_state == SystemState::IDLE);
    bool measuring = (m_state == SystemState::MEASURING);
    bool inTest    = (m_state == SystemState::SYSTEM_TEST);

    // ─── Connection controls ─────────────────────────────────────
    ui->comboBox->setEnabled(!connected);
    ui->comboBox_2->setEnabled(!connected);

    // ─── Command buttons: require connection ─────────────────────
    // In MEASURING mode: only STOP_MEASURE is allowed
    // In SYSTEM_TEST mode: only PERFORM_SYSTEM_TEST and EXIT_SYSTEM_TEST
    // In IDLE: all commands allowed

    ui->pushButton->setEnabled(connected && idle);           // Expected V
    ui->enterMeasureMode->setEnabled(connected && idle);     // Enter Measure
    ui->stopMeasure->setEnabled(connected && measuring);     // Stop Measure
    ui->transmitLastMode->setEnabled(connected && idle);     // Transmit Last V
    ui->parallax->setEnabled(connected && idle);             // Parallax
    ui->transmitParameters->setEnabled(connected && idle);   // Transmit Params

    ui->enterSystemTestMode->setEnabled(connected && idle);  // Enter System Test
    ui->performSystemTest->setEnabled(connected && inTest);  // Perform System Test
    ui->exitSystemTestMode->setEnabled(connected && inTest); // Exit System Test

    ui->performMVPTest->setEnabled(connected && idle);       // Perform MVP Test
    ui->transmitTestResults->setEnabled(connected && idle);  // Transmit MVP Results
}

// ─────────────────────────────────────────────────────────────────────
// Log System
// ─────────────────────────────────────────────────────────────────────

void MainWindow::addLog(const QString &message, const QString &type)
{
    QString timestamp = QDateTime::currentDateTime().toString("hh:mm:ss.zzz");
    QString formatted = QString("[%1] <%2> %3").arg(timestamp, type, message);

    QTextCursor cursor = m_logWidget->textCursor();
    cursor.movePosition(QTextCursor::End);

    QTextCharFormat fmt;

    // Color code by log type
    if (type == "SEND") {
        fmt.setForeground(QColor("#2E86C1"));  // Blue
    } else if (type == "RECV") {
        fmt.setForeground(QColor("#27AE60"));  // Green
    } else if (type == "ACK") {
        fmt.setForeground(QColor("#1E8449"));  // Dark green
    } else if (type == "NACK") {
        fmt.setForeground(QColor("#C0392B"));  // Dark red
    } else if (type == "ERROR") {
        fmt.setForeground(QColor("#E74C3C"));  // Red
    } else if (type == "RAW") {
        fmt.setForeground(QColor("#7F8C8D"));  // Gray
    } else {
        fmt.setForeground(QColor("#2C3E50"));  // Dark gray (INFO)
    }

    cursor.setCharFormat(fmt);
    cursor.insertText(formatted + "\n");

    // Auto-scroll to bottom
    m_logWidget->verticalScrollBar()->setValue(
        m_logWidget->verticalScrollBar()->maximum());
}
