#include "messageparser.h"
#include "protocol.h"

MessageParser::MessageParser(QObject *parent)
    : QObject(parent)
    , m_state(State::WAIT_HEADER_1)
    , m_expectedSize(0)
{
}

void MessageParser::reset()
{
    m_state = State::WAIT_HEADER_1;
    m_expectedSize = 0;
    m_buffer.clear();
}

// ─── Feed raw bytes from serial, run state machine per byte ─────────
void MessageParser::processBytes(const QByteArray &bytes)
{
    for (int i = 0; i < bytes.size(); i++) {
        processByte(static_cast<uint8_t>(bytes[i]));
    }
}

// ─── State Machine: one byte at a time ──────────────────────────────
//
// Frame: [H1='A'] [H2='B'] [SIZE] [CODE] [DATA...] [CHECKSUM]
//
// After SIZE is received, we need (SIZE - 1) more bytes:
//   SIZE counts everything from SIZE itself to CHECKSUM, inclusive,
//   but excludes the two headers.
//   So after SIZE byte, remaining = SIZE - 1 bytes (CODE + DATA + CHECKSUM).
//
void MessageParser::processByte(uint8_t byte)
{
    switch (m_state) {

    case State::WAIT_HEADER_1:
        if (byte == Protocol::HEADER_1) {
            m_state = State::WAIT_HEADER_2;
        }
        // else: discard, keep waiting
        break;

    case State::WAIT_HEADER_2:
        if (byte == Protocol::HEADER_2) {
            m_state = State::WAIT_SIZE;
        } else if (byte == Protocol::HEADER_1) {
            // Stay in WAIT_HEADER_2 — could be 'A','A','B' sequence
            m_state = State::WAIT_HEADER_2;
        } else {
            // Not 'B' after 'A' — reset
            m_state = State::WAIT_HEADER_1;
        }
        break;

    case State::WAIT_SIZE:
        if (byte < Protocol::MIN_SIZE) {
            emit parseError(QString("Invalid SIZE byte: %1 (min is %2)")
                            .arg(byte).arg(Protocol::MIN_SIZE));
            m_state = State::WAIT_HEADER_1;
        } else {
            m_expectedSize = byte;
            m_buffer.clear();
            m_buffer.reserve(m_expectedSize - 1);
            m_state = State::COLLECTING;
        }
        break;

    case State::COLLECTING:
        m_buffer.append(static_cast<char>(byte));

        // We need (SIZE - 1) bytes after SIZE: CODE + DATA + CHECKSUM
        if (m_buffer.size() >= (m_expectedSize - 1)) {
            // Validate checksum
            if (validateChecksum(m_expectedSize, m_buffer)) {
                ParsedMessage msg;
                msg.valid = true;
                msg.code = static_cast<uint8_t>(m_buffer[0]); // CODE is first byte

                // DATA bytes are between CODE and CHECKSUM
                // m_buffer = [CODE] [DATA_1 ... DATA_N] [CHECKSUM]
                // data = m_buffer[1 .. size-2]
                int dataLen = m_buffer.size() - 2; // exclude CODE and CHECKSUM
                if (dataLen > 0) {
                    msg.data = m_buffer.mid(1, dataLen);
                }

                emit messageReceived(msg);
            } else {
                emit parseError("Checksum validation failed");
            }

            // Reset for next message
            m_state = State::WAIT_HEADER_1;
            m_buffer.clear();
        }
        break;
    }
}

// ─── Checksum Validation ────────────────────────────────────────────
//
// Spec: sum of bytes 3 through N+1 == 0 mod 256
// Byte 3 = SIZE, bytes 4..N = CODE+DATA, byte N+1 = CHECKSUM
//
// We have: size (the SIZE byte) and body (CODE + DATA + CHECKSUM).
// So: sum(size_byte, all_body_bytes) should == 0 mod 256.
//
bool MessageParser::validateChecksum(uint8_t size, const QByteArray &body) const
{
    uint8_t sum = size;
    for (int i = 0; i < body.size(); i++) {
        sum += static_cast<uint8_t>(body[i]);
    }
    return (sum == 0);
}

// ─── Decode: ACK (CODE=254) ─────────────────────────────────────────
// Data: [MESSAGE] — the code being acknowledged
AckResponse MessageParser::decodeAck(const ParsedMessage &msg)
{
    AckResponse r;
    r.ackedCode = (msg.data.size() >= 1) ? static_cast<uint8_t>(msg.data[0]) : 0;
    return r;
}

// ─── Decode: NACK (CODE=255) ────────────────────────────────────────
// Data: [MESSAGE] — the code being NACKed
NackResponse MessageParser::decodeNack(const ParsedMessage &msg)
{
    NackResponse r;
    r.nackedCode = (msg.data.size() >= 1) ? static_cast<uint8_t>(msg.data[0]) : 0;
    return r;
}

// ─── Decode: LAST_V (CODE=200) ──────────────────────────────────────
// Data: [RESULT] [V_LO] [V_HI]
//   RESULT: 0 = OK, 0xFF = error
//   V: uint16 LE, scaled by 16. Ignore if RESULT = -1.
LastVResponse MessageParser::decodeLastV(const ParsedMessage &msg)
{
    LastVResponse r;
    r.result = 0;
    r.velocity = 0;

    if (msg.data.size() >= 1) {
        r.result = static_cast<int8_t>(msg.data[0]);
    }
    if (msg.data.size() >= 3) {
        uint8_t lo = static_cast<uint8_t>(msg.data[1]);
        uint8_t hi = static_cast<uint8_t>(msg.data[2]);
        r.velocity = static_cast<uint16_t>(lo | (hi << 8));
    }
    return r;
}

// ─── Decode: PARAMS (CODE=201) ──────────────────────────────────────
// Data: [V_LO] [V_HI] [TRIPOD] [X] [Y] [Z]
ParamsResponse MessageParser::decodeParams(const ParsedMessage &msg)
{
    ParamsResponse r;
    r.expectedV = 0;
    r.tripod = 0;
    r.x = r.y = r.z = 0;

    if (msg.data.size() >= 2) {
        uint8_t lo = static_cast<uint8_t>(msg.data[0]);
        uint8_t hi = static_cast<uint8_t>(msg.data[1]);
        r.expectedV = static_cast<uint16_t>(lo | (hi << 8));
    }
    if (msg.data.size() >= 3) r.tripod = static_cast<uint8_t>(msg.data[2]);
    if (msg.data.size() >= 4) r.x = static_cast<uint8_t>(msg.data[3]);
    if (msg.data.size() >= 5) r.y = static_cast<uint8_t>(msg.data[4]);
    if (msg.data.size() >= 6) r.z = static_cast<uint8_t>(msg.data[5]);

    return r;
}

// ─── Decode: SYSTEM_TEST_RESULTS (CODE=212) ─────────────────────────
// Data: [FLAGS_LO] [FLAGS_HI]
//   Bit 0 = RAM, Bit 1 = PORTS, ..., Bit 5 = RF Noise
SystemTestResultsResponse MessageParser::decodeSystemTestResults(const ParsedMessage &msg)
{
    SystemTestResultsResponse r;
    r.failureFlags = 0;

    if (msg.data.size() >= 2) {
        uint8_t lo = static_cast<uint8_t>(msg.data[0]);
        uint8_t hi = static_cast<uint8_t>(msg.data[1]);
        r.failureFlags = static_cast<uint16_t>(lo | (hi << 8));
    }
    return r;
}
