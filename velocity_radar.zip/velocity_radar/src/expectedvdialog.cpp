#include "expectedvdialog.h"
#include "protocol.h"

#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QIntValidator>
#include <QMessageBox>

ExpectedVDialog::ExpectedVDialog(QWidget *parent)
    : QDialog(parent)
    , m_value(0)
{
    setWindowTitle("Expected Velocity");
    setFixedSize(350, 180);

    // ─── Build UI programmatically ───────────────────────────────
    // (Avoids Ui::Dialog name collision with mainwindow.ui)

    auto *mainLayout = new QVBoxLayout(this);

    m_label = new QLabel("Enter Expected Velocity:", this);
    mainLayout->addWidget(m_label);

    m_inputField = new QLineEdit(this);
    m_inputField->setPlaceholderText("150 - 1500");
    m_inputField->setValidator(new QIntValidator(0, 99999, this)); // Basic int filter
    mainLayout->addWidget(m_inputField);

    m_rangeLabel = new QLabel(
        QString("Valid range: %1 – %2")
            .arg(Protocol::EXPECTED_V_MIN)
            .arg(Protocol::EXPECTED_V_MAX),
        this);
    m_rangeLabel->setStyleSheet("color: gray; font-size: 9pt;");
    mainLayout->addWidget(m_rangeLabel);

    mainLayout->addStretch();

    // Buttons
    auto *btnLayout = new QHBoxLayout();
    auto *okBtn = new QPushButton("OK", this);
    auto *cancelBtn = new QPushButton("Cancel", this);
    btnLayout->addStretch();
    btnLayout->addWidget(okBtn);
    btnLayout->addWidget(cancelBtn);
    mainLayout->addLayout(btnLayout);

    // ─── Connections ─────────────────────────────────────────────
    connect(okBtn, &QPushButton::clicked, this, &ExpectedVDialog::onOkClicked);
    connect(cancelBtn, &QPushButton::clicked, this, &ExpectedVDialog::onCancelClicked);

    // Allow Enter key to submit
    connect(m_inputField, &QLineEdit::returnPressed, this, &ExpectedVDialog::onOkClicked);
}

ExpectedVDialog::~ExpectedVDialog()
{
}

uint16_t ExpectedVDialog::getExpectedValue() const
{
    return m_value;
}

void ExpectedVDialog::onOkClicked()
{
    bool ok;
    int val = m_inputField->text().toInt(&ok);

    if (!ok || val < Protocol::EXPECTED_V_MIN || val > Protocol::EXPECTED_V_MAX) {
        QMessageBox::warning(this, "Invalid Input",
            QString("Expected Velocity must be between %1 and %2.")
                .arg(Protocol::EXPECTED_V_MIN)
                .arg(Protocol::EXPECTED_V_MAX));
        m_inputField->setFocus();
        m_inputField->selectAll();
        return;
    }

    m_value = static_cast<uint16_t>(val);
    accept();
}

void ExpectedVDialog::onCancelClicked()
{
    reject();
}
