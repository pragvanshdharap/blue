#ifndef PROTOCOL_H
#define PROTOCOL_H

#include <cstdint>

namespace Protocol {

// ─── Frame Constants ───────────────────────────────────────────────
constexpr uint8_t  HEADER_1       = 'A';  // 0x41
constexpr uint8_t  HEADER_2       = 'B';  // 0x42
constexpr uint8_t  MIN_SIZE       = 2;    // Minimum SIZE field value
constexpr uint8_t  MAX_SIZE       = 255;
constexpr uint16_t MAX_DATA_BYTES = 253;  // SIZE - 1 (CODE) - 1 (CHECKSUM) = 253

// ─── Command Codes (PC → System) ──────────────────────────────────
constexpr uint8_t CMD_EXPECTED_V            = 102;
constexpr uint8_t CMD_MEASURE               = 103;
constexpr uint8_t CMD_STOP_MEASURE          = 104;
constexpr uint8_t CMD_TXMT_LAST_V           = 105;
constexpr uint8_t CMD_PARALLAX              = 106;
constexpr uint8_t CMD_TXMT_PARAMS           = 107;
constexpr uint8_t CMD_ENTER_SYSTEM_TEST     = 108;
constexpr uint8_t CMD_PERFORM_SYSTEM_TEST   = 109;
constexpr uint8_t CMD_EXIT_SYSTEM_TEST      = 110;
constexpr uint8_t CMD_PERFORM_MVP_TEST      = 111;
constexpr uint8_t CMD_TXMT_MVP_TEST_RESULTS = 112;

// ─── Response Codes (System → PC) ─────────────────────────────────
constexpr uint8_t RSP_ACK                   = 254;
constexpr uint8_t RSP_NACK                  = 255;
constexpr uint8_t RSP_LAST_V                = 200;
constexpr uint8_t RSP_PARAMS                = 201;
constexpr uint8_t RSP_SYSTEM_TEST_RESULTS   = 212;

// ─── Data Ranges ──────────────────────────────────────────────────
constexpr uint16_t EXPECTED_V_MIN = 150;
constexpr uint16_t EXPECTED_V_MAX = 1500;
constexpr uint16_t LAST_V_MAX     = 24000;
constexpr uint8_t  PARALLAX_XYZ_MAX = 160;
constexpr uint8_t  V_SCALE_FACTOR   = 16;

// ─── Timing (milliseconds) ───────────────────────────────────────
constexpr int TIMEOUT_RESPONSE_MS       = 2000;  // Normal response timeout
constexpr int TIMEOUT_SYSTEM_TEST_MS    = 5000;  // PERFORM_SYSTEM_TEST timeout
constexpr int TIMEOUT_BYTE_MS           = 1000;  // Inter-byte timeout

// ─── LAST_V Result Codes ─────────────────────────────────────────
constexpr int8_t RESULT_V_OK    = 0;
constexpr int8_t RESULT_V_ERROR = -1;  // 0xFF as signed

// ─── System Test Bit Flags ───────────────────────────────────────
constexpr uint16_t BIT_RAM_FAILURE          = (1 << 0);
constexpr uint16_t BIT_PORTS_FAILURE        = (1 << 1);
constexpr uint16_t BIT_SYNT_DOPP            = (1 << 2);
constexpr uint16_t BIT_RF_TEST              = (1 << 3);
constexpr uint16_t BIT_ACCELEROMETER        = (1 << 4);
constexpr uint16_t BIT_RF_NOISE             = (1 << 5);
// bits 6-15: spare (0)

// ─── Helper: readable name for a command code ────────────────────
inline const char* commandName(uint8_t code) {
    switch (code) {
        case CMD_EXPECTED_V:            return "EXPECTED_V";
        case CMD_MEASURE:               return "MEASURE";
        case CMD_STOP_MEASURE:          return "STOP_MEASURE";
        case CMD_TXMT_LAST_V:           return "TXMT_LAST_V";
        case CMD_PARALLAX:              return "PARALLAX";
        case CMD_TXMT_PARAMS:           return "TXMT_PARAMS";
        case CMD_ENTER_SYSTEM_TEST:     return "ENTER_SYSTEM_TEST";
        case CMD_PERFORM_SYSTEM_TEST:   return "PERFORM_SYSTEM_TEST";
        case CMD_EXIT_SYSTEM_TEST:      return "EXIT_SYSTEM_TEST";
        case CMD_PERFORM_MVP_TEST:      return "PERFORM_MVP_TEST";
        case CMD_TXMT_MVP_TEST_RESULTS: return "TXMT_MVP_TEST_RESULTS";
        case RSP_ACK:                   return "ACK";
        case RSP_NACK:                  return "NACK";
        case RSP_LAST_V:                return "LAST_V";
        case RSP_PARAMS:                return "PARAMS";
        case RSP_SYSTEM_TEST_RESULTS:   return "SYSTEM_TEST_RESULTS";
        default:                        return "UNKNOWN";
    }
}

// ─── Helper: does this command expect a data response (not ACK)? ─
inline bool expectsDataResponse(uint8_t cmdCode) {
    switch (cmdCode) {
        case CMD_TXMT_LAST_V:
        case CMD_TXMT_PARAMS:
        case CMD_PERFORM_SYSTEM_TEST:
        case CMD_PERFORM_MVP_TEST:
        case CMD_TXMT_MVP_TEST_RESULTS:
            return true;
        default:
            return false;
    }
}

// ─── Helper: timeout for a given command ─────────────────────────
inline int responseTimeout(uint8_t cmdCode) {
    if (cmdCode == CMD_PERFORM_SYSTEM_TEST)
        return TIMEOUT_SYSTEM_TEST_MS;
    return TIMEOUT_RESPONSE_MS;
}

} // namespace Protocol

#endif // PROTOCOL_H
