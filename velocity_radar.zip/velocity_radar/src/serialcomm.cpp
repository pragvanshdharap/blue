#include "serialcomm.h"
#include "protocol.h"

#include <QDebug>

SerialComm::SerialComm(QObject *parent)
    : QObject(parent)
    , m_pendingCmdCode(0)
{
    // ─── Wire QSerialPort signals ────────────────────────────────
    connect(&m_serial, &QSerialPort::readyRead,
            this, &SerialComm::onReadyRead);

    connect(&m_serial, &QSerialPort::errorOccurred,
            this, &SerialComm::onSerialError);

    // ─── Wire parser signals → our signals ───────────────────────
    connect(&m_parser, &MessageParser::messageReceived,
            this, [this](const ParsedMessage &msg) {
                // Stop timeout timer — we got a response
                m_responseTimer.stop();
                m_pendingCmdCode = 0;
                emit messageReceived(msg);
            });

    connect(&m_parser, &MessageParser::parseError,
            this, &SerialComm::parseError);

    // ─── Response timeout timer (single-shot) ────────────────────
    m_responseTimer.setSingleShot(true);
    connect(&m_responseTimer, &QTimer::timeout,
            this, &SerialComm::onResponseTimeout);
}

SerialComm::~SerialComm()
{
    closePort();
}

// ─── Enumerate COM Ports ────────────────────────────────────────────
QStringList SerialComm::availablePorts()
{
    QStringList ports;
    const auto infos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : infos) {
        ports << info.portName();
    }
    return ports;
}

// ─── Open Port ──────────────────────────────────────────────────────
bool SerialComm::openPort(const QString &portName, int baudRate)
{
    if (m_serial.isOpen()) {
        closePort();
    }

    m_serial.setPortName(portName);
    m_serial.setBaudRate(baudRate);
    m_serial.setDataBits(QSerialPort::Data8);
    m_serial.setParity(QSerialPort::NoParity);
    m_serial.setStopBits(QSerialPort::OneStop);
    m_serial.setFlowControl(QSerialPort::NoFlowControl);

    if (!m_serial.open(QIODevice::ReadWrite)) {
        emit portError(QString("Failed to open %1: %2")
                       .arg(portName, m_serial.errorString()));
        return false;
    }

    m_parser.reset();
    m_pendingCmdCode = 0;
    m_responseTimer.stop();

    emit portOpened(portName);
    return true;
}

// ─── Close Port ─────────────────────────────────────────────────────
void SerialComm::closePort()
{
    m_responseTimer.stop();
    m_pendingCmdCode = 0;

    if (m_serial.isOpen()) {
        m_serial.close();
    }

    m_parser.reset();
    emit portClosed();
}

bool SerialComm::isOpen() const
{
    return m_serial.isOpen();
}

QString SerialComm::currentPortName() const
{
    return m_serial.portName();
}

// ─── Send Message ───────────────────────────────────────────────────
bool SerialComm::sendMessage(const QByteArray &message, uint8_t cmdCode)
{
    if (!m_serial.isOpen()) {
        emit portError("Cannot send: port is not open");
        return false;
    }

    qint64 written = m_serial.write(message);
    if (written != message.size()) {
        emit portError(QString("Write error: wrote %1 of %2 bytes")
                       .arg(written).arg(message.size()));
        return false;
    }

    m_serial.flush();

    emit rawDataSent(message);

    // Start response timeout
    m_pendingCmdCode = cmdCode;
    int timeout = Protocol::responseTimeout(cmdCode);
    m_responseTimer.start(timeout);

    return true;
}

// ─── Incoming Data Handler ──────────────────────────────────────────
void SerialComm::onReadyRead()
{
    QByteArray data = m_serial.readAll();
    if (!data.isEmpty()) {
        emit rawDataReceived(data);
        m_parser.processBytes(data);
    }
}

// ─── Serial Port Error Handler ──────────────────────────────────────
void SerialComm::onSerialError(QSerialPort::SerialPortError error)
{
    if (error == QSerialPort::NoError)
        return;

    // ResourceError typically means cable unplugged
    if (error == QSerialPort::ResourceError) {
        emit portError("Serial port disconnected unexpectedly");
        closePort();
    } else {
        emit portError(QString("Serial error: %1").arg(m_serial.errorString()));
    }
}

// ─── Response Timeout ───────────────────────────────────────────────
void SerialComm::onResponseTimeout()
{
    uint8_t code = m_pendingCmdCode;
    m_pendingCmdCode = 0;
    emit responseTimeout(code);
}
